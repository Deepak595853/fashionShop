<?php
/**
 * New Section
 * 
 * slug: new-products
 * title: New Products Section
 * categories: thshopmania
 */

return array(
    'title'      =>__( 'New Products Section', 'th-shop-mania' ),
    'categories' => array( 'thshopmania' ),
    'content'    => '<!-- wp:woocommerce/product-new {"columns":4,"rows":2} /-->',
);