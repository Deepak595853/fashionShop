/*! elementor - v3.17.0 - 25-10-2023 */
/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "../app/assets/js/app.scss":
/*!*********************************!*\
  !*** ../app/assets/js/app.scss ***!
  \*********************************/
/***/ (() => {



/***/ }),

/***/ "../app/assets/js/molecules/collapse.scss":
/*!************************************************!*\
  !*** ../app/assets/js/molecules/collapse.scss ***!
  \************************************************/
/***/ (() => {



/***/ }),

/***/ "../app/assets/js/molecules/upload-file.scss":
/*!***************************************************!*\
  !*** ../app/assets/js/molecules/upload-file.scss ***!
  \***************************************************/
/***/ (() => {



/***/ }),

/***/ "../app/assets/js/organisms/drop-zone.scss":
/*!*************************************************!*\
  !*** ../app/assets/js/organisms/drop-zone.scss ***!
  \*************************************************/
/***/ (() => {



/***/ }),

/***/ "../app/assets/js/organisms/wizard-footer.scss":
/*!*****************************************************!*\
  !*** ../app/assets/js/organisms/wizard-footer.scss ***!
  \*****************************************************/
/***/ (() => {



/***/ }),

/***/ "../app/assets/js/ui/atoms/box.scss":
/*!******************************************!*\
  !*** ../app/assets/js/ui/atoms/box.scss ***!
  \******************************************/
/***/ (() => {



/***/ }),

/***/ "../app/assets/js/ui/atoms/checkbox.scss":
/*!***********************************************!*\
  !*** ../app/assets/js/ui/atoms/checkbox.scss ***!
  \***********************************************/
/***/ (() => {



/***/ }),

/***/ "../app/assets/js/ui/atoms/drag-drop.scss":
/*!************************************************!*\
  !*** ../app/assets/js/ui/atoms/drag-drop.scss ***!
  \************************************************/
/***/ (() => {



/***/ }),

/***/ "../app/assets/js/ui/atoms/text-field.scss":
/*!*************************************************!*\
  !*** ../app/assets/js/ui/atoms/text-field.scss ***!
  \*************************************************/
/***/ (() => {



/***/ }),

/***/ "../app/assets/js/ui/card/card.scss":
/*!******************************************!*\
  !*** ../app/assets/js/ui/card/card.scss ***!
  \******************************************/
/***/ (() => {



/***/ }),

/***/ "../app/assets/js/ui/dialog/dialog.scss":
/*!**********************************************!*\
  !*** ../app/assets/js/ui/dialog/dialog.scss ***!
  \**********************************************/
/***/ (() => {



/***/ }),

/***/ "../app/assets/js/ui/grid/grid.scss":
/*!******************************************!*\
  !*** ../app/assets/js/ui/grid/grid.scss ***!
  \******************************************/
/***/ (() => {



/***/ }),

/***/ "../app/assets/js/ui/modal/modal.scss":
/*!********************************************!*\
  !*** ../app/assets/js/ui/modal/modal.scss ***!
  \********************************************/
/***/ (() => {



/***/ }),

/***/ "../app/assets/js/ui/molecules/inline-link.scss":
/*!******************************************************!*\
  !*** ../app/assets/js/ui/molecules/inline-link.scss ***!
  \******************************************************/
/***/ (() => {



/***/ }),

/***/ "../app/assets/js/ui/molecules/list.scss":
/*!***********************************************!*\
  !*** ../app/assets/js/ui/molecules/list.scss ***!
  \***********************************************/
/***/ (() => {



/***/ }),

/***/ "../app/assets/js/ui/molecules/notice.scss":
/*!*************************************************!*\
  !*** ../app/assets/js/ui/molecules/notice.scss ***!
  \*************************************************/
/***/ (() => {



/***/ }),

/***/ "../app/assets/js/ui/molecules/select2.scss":
/*!**************************************************!*\
  !*** ../app/assets/js/ui/molecules/select2.scss ***!
  \**************************************************/
/***/ (() => {



/***/ }),

/***/ "../app/assets/js/ui/panel/panel.scss":
/*!********************************************!*\
  !*** ../app/assets/js/ui/panel/panel.scss ***!
  \********************************************/
/***/ (() => {



/***/ }),

/***/ "../app/assets/js/ui/table/table.scss":
/*!********************************************!*\
  !*** ../app/assets/js/ui/table/table.scss ***!
  \********************************************/
/***/ (() => {



/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/export/export-complete/export-complete.scss":
/*!************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/export/export-complete/export-complete.scss ***!
  \************************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/export/export-kit/export-kit.scss":
/*!**************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/export/export-kit/export-kit.scss ***!
  \**************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/export/export-plugins/export-plugins.scss":
/*!**********************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/export/export-plugins/export-plugins.scss ***!
  \**********************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/import/import-complete/components/connect-pro-notice/connect-pro-notice.scss":
/*!*********************************************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/import/import-complete/components/connect-pro-notice/connect-pro-notice.scss ***!
  \*********************************************************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/import/import-complete/components/failed-plugins-notice/failed-plugins-notice.scss":
/*!***************************************************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/import/import-complete/components/failed-plugins-notice/failed-plugins-notice.scss ***!
  \***************************************************************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/import/import-content/import-content.scss":
/*!**********************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/import/import-content/import-content.scss ***!
  \**********************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/import/import-kit/import-kit.scss":
/*!**************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/import/import-kit/import-kit.scss ***!
  \**************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/import/import-plugins-activation/import-plugins-activation.scss":
/*!********************************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/import/import-plugins-activation/import-plugins-activation.scss ***!
  \********************************************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/import/import-plugins/components/pro-banner/pro-banner.scss":
/*!****************************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/import/import-plugins/components/pro-banner/pro-banner.scss ***!
  \****************************************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/import/import-plugins/import-plugins.scss":
/*!**********************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/import/import-plugins/import-plugins.scss ***!
  \**********************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/import/import-resolver/import-resolver.scss":
/*!************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/import/import-resolver/import-resolver.scss ***!
  \************************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "../app/modules/import-export/assets/js/shared/content-layout/content-layout.scss":
/*!****************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/shared/content-layout/content-layout.scss ***!
  \****************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "../app/modules/import-export/assets/js/shared/info-modal/info-modal.scss":
/*!********************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/shared/info-modal/info-modal.scss ***!
  \********************************************************************************/
/***/ (() => {



/***/ }),

/***/ "../app/modules/import-export/assets/js/shared/kit-content/components/templates-features/templates-features.scss":
/*!***********************************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/shared/kit-content/components/templates-features/templates-features.scss ***!
  \***********************************************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "../app/modules/import-export/assets/js/shared/kit-content/kit-content.scss":
/*!**********************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/shared/kit-content/kit-content.scss ***!
  \**********************************************************************************/
/***/ (() => {



/***/ }),

/***/ "../app/modules/import-export/assets/js/shared/kit-data/kit-data.scss":
/*!****************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/shared/kit-data/kit-data.scss ***!
  \****************************************************************************/
/***/ (() => {



/***/ }),

/***/ "../app/modules/import-export/assets/js/shared/plugins-selection/components/plugins-table.scss":
/*!*****************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/shared/plugins-selection/components/plugins-table.scss ***!
  \*****************************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "../app/modules/import-export/assets/js/ui/loader/loader.scss":
/*!********************************************************************!*\
  !*** ../app/modules/import-export/assets/js/ui/loader/loader.scss ***!
  \********************************************************************/
/***/ (() => {



/***/ }),

/***/ "../app/modules/import-export/assets/js/ui/message-banner/message-banner.scss":
/*!************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/ui/message-banner/message-banner.scss ***!
  \************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "../app/modules/import-export/assets/js/ui/page-header/page-header.scss":
/*!******************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/ui/page-header/page-header.scss ***!
  \******************************************************************************/
/***/ (() => {



/***/ }),

/***/ "../app/modules/import-export/assets/js/ui/wizard-step/wizard-step.scss":
/*!******************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/ui/wizard-step/wizard-step.scss ***!
  \******************************************************************************/
/***/ (() => {



/***/ }),

/***/ "../node_modules/@emotion/is-prop-valid/dist/emotion-is-prop-valid.esm.js":
/*!********************************************************************************!*\
  !*** ../node_modules/@emotion/is-prop-valid/dist/emotion-is-prop-valid.esm.js ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ isPropValid)
/* harmony export */ });
/* harmony import */ var _emotion_memoize__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/memoize */ "../node_modules/@emotion/memoize/dist/emotion-memoize.esm.js");


var reactPropsRegex = /^((children|dangerouslySetInnerHTML|key|ref|autoFocus|defaultValue|defaultChecked|innerHTML|suppressContentEditableWarning|suppressHydrationWarning|valueLink|abbr|accept|acceptCharset|accessKey|action|allow|allowUserMedia|allowPaymentRequest|allowFullScreen|allowTransparency|alt|async|autoComplete|autoPlay|capture|cellPadding|cellSpacing|challenge|charSet|checked|cite|classID|className|cols|colSpan|content|contentEditable|contextMenu|controls|controlsList|coords|crossOrigin|data|dateTime|decoding|default|defer|dir|disabled|disablePictureInPicture|download|draggable|encType|enterKeyHint|form|formAction|formEncType|formMethod|formNoValidate|formTarget|frameBorder|headers|height|hidden|high|href|hrefLang|htmlFor|httpEquiv|id|inputMode|integrity|is|keyParams|keyType|kind|label|lang|list|loading|loop|low|marginHeight|marginWidth|max|maxLength|media|mediaGroup|method|min|minLength|multiple|muted|name|nonce|noValidate|open|optimum|pattern|placeholder|playsInline|poster|preload|profile|radioGroup|readOnly|referrerPolicy|rel|required|reversed|role|rows|rowSpan|sandbox|scope|scoped|scrolling|seamless|selected|shape|size|sizes|slot|span|spellCheck|src|srcDoc|srcLang|srcSet|start|step|style|summary|tabIndex|target|title|translate|type|useMap|value|width|wmode|wrap|about|datatype|inlist|prefix|property|resource|typeof|vocab|autoCapitalize|autoCorrect|autoSave|color|incremental|fallback|inert|itemProp|itemScope|itemType|itemID|itemRef|on|option|results|security|unselectable|accentHeight|accumulate|additive|alignmentBaseline|allowReorder|alphabetic|amplitude|arabicForm|ascent|attributeName|attributeType|autoReverse|azimuth|baseFrequency|baselineShift|baseProfile|bbox|begin|bias|by|calcMode|capHeight|clip|clipPathUnits|clipPath|clipRule|colorInterpolation|colorInterpolationFilters|colorProfile|colorRendering|contentScriptType|contentStyleType|cursor|cx|cy|d|decelerate|descent|diffuseConstant|direction|display|divisor|dominantBaseline|dur|dx|dy|edgeMode|elevation|enableBackground|end|exponent|externalResourcesRequired|fill|fillOpacity|fillRule|filter|filterRes|filterUnits|floodColor|floodOpacity|focusable|fontFamily|fontSize|fontSizeAdjust|fontStretch|fontStyle|fontVariant|fontWeight|format|from|fr|fx|fy|g1|g2|glyphName|glyphOrientationHorizontal|glyphOrientationVertical|glyphRef|gradientTransform|gradientUnits|hanging|horizAdvX|horizOriginX|ideographic|imageRendering|in|in2|intercept|k|k1|k2|k3|k4|kernelMatrix|kernelUnitLength|kerning|keyPoints|keySplines|keyTimes|lengthAdjust|letterSpacing|lightingColor|limitingConeAngle|local|markerEnd|markerMid|markerStart|markerHeight|markerUnits|markerWidth|mask|maskContentUnits|maskUnits|mathematical|mode|numOctaves|offset|opacity|operator|order|orient|orientation|origin|overflow|overlinePosition|overlineThickness|panose1|paintOrder|pathLength|patternContentUnits|patternTransform|patternUnits|pointerEvents|points|pointsAtX|pointsAtY|pointsAtZ|preserveAlpha|preserveAspectRatio|primitiveUnits|r|radius|refX|refY|renderingIntent|repeatCount|repeatDur|requiredExtensions|requiredFeatures|restart|result|rotate|rx|ry|scale|seed|shapeRendering|slope|spacing|specularConstant|specularExponent|speed|spreadMethod|startOffset|stdDeviation|stemh|stemv|stitchTiles|stopColor|stopOpacity|strikethroughPosition|strikethroughThickness|string|stroke|strokeDasharray|strokeDashoffset|strokeLinecap|strokeLinejoin|strokeMiterlimit|strokeOpacity|strokeWidth|surfaceScale|systemLanguage|tableValues|targetX|targetY|textAnchor|textDecoration|textRendering|textLength|to|transform|u1|u2|underlinePosition|underlineThickness|unicode|unicodeBidi|unicodeRange|unitsPerEm|vAlphabetic|vHanging|vIdeographic|vMathematical|values|vectorEffect|version|vertAdvY|vertOriginX|vertOriginY|viewBox|viewTarget|visibility|widths|wordSpacing|writingMode|x|xHeight|x1|x2|xChannelSelector|xlinkActuate|xlinkArcrole|xlinkHref|xlinkRole|xlinkShow|xlinkTitle|xlinkType|xmlBase|xmlns|xmlnsXlink|xmlLang|xmlSpace|y|y1|y2|yChannelSelector|z|zoomAndPan|for|class|autofocus)|(([Dd][Aa][Tt][Aa]|[Aa][Rr][Ii][Aa]|x)-.*))$/; // https://esbench.com/bench/5bfee68a4cd7e6009ef61d23

var isPropValid = /* #__PURE__ */(0,_emotion_memoize__WEBPACK_IMPORTED_MODULE_0__["default"])(function (prop) {
  return reactPropsRegex.test(prop) || prop.charCodeAt(0) === 111
  /* o */
  && prop.charCodeAt(1) === 110
  /* n */
  && prop.charCodeAt(2) < 91;
}
/* Z+1 */
);




/***/ }),

/***/ "../node_modules/@emotion/memoize/dist/emotion-memoize.esm.js":
/*!********************************************************************!*\
  !*** ../node_modules/@emotion/memoize/dist/emotion-memoize.esm.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ memoize)
/* harmony export */ });
function memoize(fn) {
  var cache = Object.create(null);
  return function (arg) {
    if (cache[arg] === undefined) cache[arg] = fn(arg);
    return cache[arg];
  };
}




/***/ }),

/***/ "../node_modules/@emotion/stylis/dist/stylis.browser.esm.js":
/*!******************************************************************!*\
  !*** ../node_modules/@emotion/stylis/dist/stylis.browser.esm.js ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
function stylis_min (W) {
  function M(d, c, e, h, a) {
    for (var m = 0, b = 0, v = 0, n = 0, q, g, x = 0, K = 0, k, u = k = q = 0, l = 0, r = 0, I = 0, t = 0, B = e.length, J = B - 1, y, f = '', p = '', F = '', G = '', C; l < B;) {
      g = e.charCodeAt(l);
      l === J && 0 !== b + n + v + m && (0 !== b && (g = 47 === b ? 10 : 47), n = v = m = 0, B++, J++);

      if (0 === b + n + v + m) {
        if (l === J && (0 < r && (f = f.replace(N, '')), 0 < f.trim().length)) {
          switch (g) {
            case 32:
            case 9:
            case 59:
            case 13:
            case 10:
              break;

            default:
              f += e.charAt(l);
          }

          g = 59;
        }

        switch (g) {
          case 123:
            f = f.trim();
            q = f.charCodeAt(0);
            k = 1;

            for (t = ++l; l < B;) {
              switch (g = e.charCodeAt(l)) {
                case 123:
                  k++;
                  break;

                case 125:
                  k--;
                  break;

                case 47:
                  switch (g = e.charCodeAt(l + 1)) {
                    case 42:
                    case 47:
                      a: {
                        for (u = l + 1; u < J; ++u) {
                          switch (e.charCodeAt(u)) {
                            case 47:
                              if (42 === g && 42 === e.charCodeAt(u - 1) && l + 2 !== u) {
                                l = u + 1;
                                break a;
                              }

                              break;

                            case 10:
                              if (47 === g) {
                                l = u + 1;
                                break a;
                              }

                          }
                        }

                        l = u;
                      }

                  }

                  break;

                case 91:
                  g++;

                case 40:
                  g++;

                case 34:
                case 39:
                  for (; l++ < J && e.charCodeAt(l) !== g;) {
                  }

              }

              if (0 === k) break;
              l++;
            }

            k = e.substring(t, l);
            0 === q && (q = (f = f.replace(ca, '').trim()).charCodeAt(0));

            switch (q) {
              case 64:
                0 < r && (f = f.replace(N, ''));
                g = f.charCodeAt(1);

                switch (g) {
                  case 100:
                  case 109:
                  case 115:
                  case 45:
                    r = c;
                    break;

                  default:
                    r = O;
                }

                k = M(c, r, k, g, a + 1);
                t = k.length;
                0 < A && (r = X(O, f, I), C = H(3, k, r, c, D, z, t, g, a, h), f = r.join(''), void 0 !== C && 0 === (t = (k = C.trim()).length) && (g = 0, k = ''));
                if (0 < t) switch (g) {
                  case 115:
                    f = f.replace(da, ea);

                  case 100:
                  case 109:
                  case 45:
                    k = f + '{' + k + '}';
                    break;

                  case 107:
                    f = f.replace(fa, '$1 $2');
                    k = f + '{' + k + '}';
                    k = 1 === w || 2 === w && L('@' + k, 3) ? '@-webkit-' + k + '@' + k : '@' + k;
                    break;

                  default:
                    k = f + k, 112 === h && (k = (p += k, ''));
                } else k = '';
                break;

              default:
                k = M(c, X(c, f, I), k, h, a + 1);
            }

            F += k;
            k = I = r = u = q = 0;
            f = '';
            g = e.charCodeAt(++l);
            break;

          case 125:
          case 59:
            f = (0 < r ? f.replace(N, '') : f).trim();
            if (1 < (t = f.length)) switch (0 === u && (q = f.charCodeAt(0), 45 === q || 96 < q && 123 > q) && (t = (f = f.replace(' ', ':')).length), 0 < A && void 0 !== (C = H(1, f, c, d, D, z, p.length, h, a, h)) && 0 === (t = (f = C.trim()).length) && (f = '\x00\x00'), q = f.charCodeAt(0), g = f.charCodeAt(1), q) {
              case 0:
                break;

              case 64:
                if (105 === g || 99 === g) {
                  G += f + e.charAt(l);
                  break;
                }

              default:
                58 !== f.charCodeAt(t - 1) && (p += P(f, q, g, f.charCodeAt(2)));
            }
            I = r = u = q = 0;
            f = '';
            g = e.charCodeAt(++l);
        }
      }

      switch (g) {
        case 13:
        case 10:
          47 === b ? b = 0 : 0 === 1 + q && 107 !== h && 0 < f.length && (r = 1, f += '\x00');
          0 < A * Y && H(0, f, c, d, D, z, p.length, h, a, h);
          z = 1;
          D++;
          break;

        case 59:
        case 125:
          if (0 === b + n + v + m) {
            z++;
            break;
          }

        default:
          z++;
          y = e.charAt(l);

          switch (g) {
            case 9:
            case 32:
              if (0 === n + m + b) switch (x) {
                case 44:
                case 58:
                case 9:
                case 32:
                  y = '';
                  break;

                default:
                  32 !== g && (y = ' ');
              }
              break;

            case 0:
              y = '\\0';
              break;

            case 12:
              y = '\\f';
              break;

            case 11:
              y = '\\v';
              break;

            case 38:
              0 === n + b + m && (r = I = 1, y = '\f' + y);
              break;

            case 108:
              if (0 === n + b + m + E && 0 < u) switch (l - u) {
                case 2:
                  112 === x && 58 === e.charCodeAt(l - 3) && (E = x);

                case 8:
                  111 === K && (E = K);
              }
              break;

            case 58:
              0 === n + b + m && (u = l);
              break;

            case 44:
              0 === b + v + n + m && (r = 1, y += '\r');
              break;

            case 34:
            case 39:
              0 === b && (n = n === g ? 0 : 0 === n ? g : n);
              break;

            case 91:
              0 === n + b + v && m++;
              break;

            case 93:
              0 === n + b + v && m--;
              break;

            case 41:
              0 === n + b + m && v--;
              break;

            case 40:
              if (0 === n + b + m) {
                if (0 === q) switch (2 * x + 3 * K) {
                  case 533:
                    break;

                  default:
                    q = 1;
                }
                v++;
              }

              break;

            case 64:
              0 === b + v + n + m + u + k && (k = 1);
              break;

            case 42:
            case 47:
              if (!(0 < n + m + v)) switch (b) {
                case 0:
                  switch (2 * g + 3 * e.charCodeAt(l + 1)) {
                    case 235:
                      b = 47;
                      break;

                    case 220:
                      t = l, b = 42;
                  }

                  break;

                case 42:
                  47 === g && 42 === x && t + 2 !== l && (33 === e.charCodeAt(t + 2) && (p += e.substring(t, l + 1)), y = '', b = 0);
              }
          }

          0 === b && (f += y);
      }

      K = x;
      x = g;
      l++;
    }

    t = p.length;

    if (0 < t) {
      r = c;
      if (0 < A && (C = H(2, p, r, d, D, z, t, h, a, h), void 0 !== C && 0 === (p = C).length)) return G + p + F;
      p = r.join(',') + '{' + p + '}';

      if (0 !== w * E) {
        2 !== w || L(p, 2) || (E = 0);

        switch (E) {
          case 111:
            p = p.replace(ha, ':-moz-$1') + p;
            break;

          case 112:
            p = p.replace(Q, '::-webkit-input-$1') + p.replace(Q, '::-moz-$1') + p.replace(Q, ':-ms-input-$1') + p;
        }

        E = 0;
      }
    }

    return G + p + F;
  }

  function X(d, c, e) {
    var h = c.trim().split(ia);
    c = h;
    var a = h.length,
        m = d.length;

    switch (m) {
      case 0:
      case 1:
        var b = 0;

        for (d = 0 === m ? '' : d[0] + ' '; b < a; ++b) {
          c[b] = Z(d, c[b], e).trim();
        }

        break;

      default:
        var v = b = 0;

        for (c = []; b < a; ++b) {
          for (var n = 0; n < m; ++n) {
            c[v++] = Z(d[n] + ' ', h[b], e).trim();
          }
        }

    }

    return c;
  }

  function Z(d, c, e) {
    var h = c.charCodeAt(0);
    33 > h && (h = (c = c.trim()).charCodeAt(0));

    switch (h) {
      case 38:
        return c.replace(F, '$1' + d.trim());

      case 58:
        return d.trim() + c.replace(F, '$1' + d.trim());

      default:
        if (0 < 1 * e && 0 < c.indexOf('\f')) return c.replace(F, (58 === d.charCodeAt(0) ? '' : '$1') + d.trim());
    }

    return d + c;
  }

  function P(d, c, e, h) {
    var a = d + ';',
        m = 2 * c + 3 * e + 4 * h;

    if (944 === m) {
      d = a.indexOf(':', 9) + 1;
      var b = a.substring(d, a.length - 1).trim();
      b = a.substring(0, d).trim() + b + ';';
      return 1 === w || 2 === w && L(b, 1) ? '-webkit-' + b + b : b;
    }

    if (0 === w || 2 === w && !L(a, 1)) return a;

    switch (m) {
      case 1015:
        return 97 === a.charCodeAt(10) ? '-webkit-' + a + a : a;

      case 951:
        return 116 === a.charCodeAt(3) ? '-webkit-' + a + a : a;

      case 963:
        return 110 === a.charCodeAt(5) ? '-webkit-' + a + a : a;

      case 1009:
        if (100 !== a.charCodeAt(4)) break;

      case 969:
      case 942:
        return '-webkit-' + a + a;

      case 978:
        return '-webkit-' + a + '-moz-' + a + a;

      case 1019:
      case 983:
        return '-webkit-' + a + '-moz-' + a + '-ms-' + a + a;

      case 883:
        if (45 === a.charCodeAt(8)) return '-webkit-' + a + a;
        if (0 < a.indexOf('image-set(', 11)) return a.replace(ja, '$1-webkit-$2') + a;
        break;

      case 932:
        if (45 === a.charCodeAt(4)) switch (a.charCodeAt(5)) {
          case 103:
            return '-webkit-box-' + a.replace('-grow', '') + '-webkit-' + a + '-ms-' + a.replace('grow', 'positive') + a;

          case 115:
            return '-webkit-' + a + '-ms-' + a.replace('shrink', 'negative') + a;

          case 98:
            return '-webkit-' + a + '-ms-' + a.replace('basis', 'preferred-size') + a;
        }
        return '-webkit-' + a + '-ms-' + a + a;

      case 964:
        return '-webkit-' + a + '-ms-flex-' + a + a;

      case 1023:
        if (99 !== a.charCodeAt(8)) break;
        b = a.substring(a.indexOf(':', 15)).replace('flex-', '').replace('space-between', 'justify');
        return '-webkit-box-pack' + b + '-webkit-' + a + '-ms-flex-pack' + b + a;

      case 1005:
        return ka.test(a) ? a.replace(aa, ':-webkit-') + a.replace(aa, ':-moz-') + a : a;

      case 1e3:
        b = a.substring(13).trim();
        c = b.indexOf('-') + 1;

        switch (b.charCodeAt(0) + b.charCodeAt(c)) {
          case 226:
            b = a.replace(G, 'tb');
            break;

          case 232:
            b = a.replace(G, 'tb-rl');
            break;

          case 220:
            b = a.replace(G, 'lr');
            break;

          default:
            return a;
        }

        return '-webkit-' + a + '-ms-' + b + a;

      case 1017:
        if (-1 === a.indexOf('sticky', 9)) break;

      case 975:
        c = (a = d).length - 10;
        b = (33 === a.charCodeAt(c) ? a.substring(0, c) : a).substring(d.indexOf(':', 7) + 1).trim();

        switch (m = b.charCodeAt(0) + (b.charCodeAt(7) | 0)) {
          case 203:
            if (111 > b.charCodeAt(8)) break;

          case 115:
            a = a.replace(b, '-webkit-' + b) + ';' + a;
            break;

          case 207:
          case 102:
            a = a.replace(b, '-webkit-' + (102 < m ? 'inline-' : '') + 'box') + ';' + a.replace(b, '-webkit-' + b) + ';' + a.replace(b, '-ms-' + b + 'box') + ';' + a;
        }

        return a + ';';

      case 938:
        if (45 === a.charCodeAt(5)) switch (a.charCodeAt(6)) {
          case 105:
            return b = a.replace('-items', ''), '-webkit-' + a + '-webkit-box-' + b + '-ms-flex-' + b + a;

          case 115:
            return '-webkit-' + a + '-ms-flex-item-' + a.replace(ba, '') + a;

          default:
            return '-webkit-' + a + '-ms-flex-line-pack' + a.replace('align-content', '').replace(ba, '') + a;
        }
        break;

      case 973:
      case 989:
        if (45 !== a.charCodeAt(3) || 122 === a.charCodeAt(4)) break;

      case 931:
      case 953:
        if (!0 === la.test(d)) return 115 === (b = d.substring(d.indexOf(':') + 1)).charCodeAt(0) ? P(d.replace('stretch', 'fill-available'), c, e, h).replace(':fill-available', ':stretch') : a.replace(b, '-webkit-' + b) + a.replace(b, '-moz-' + b.replace('fill-', '')) + a;
        break;

      case 962:
        if (a = '-webkit-' + a + (102 === a.charCodeAt(5) ? '-ms-' + a : '') + a, 211 === e + h && 105 === a.charCodeAt(13) && 0 < a.indexOf('transform', 10)) return a.substring(0, a.indexOf(';', 27) + 1).replace(ma, '$1-webkit-$2') + a;
    }

    return a;
  }

  function L(d, c) {
    var e = d.indexOf(1 === c ? ':' : '{'),
        h = d.substring(0, 3 !== c ? e : 10);
    e = d.substring(e + 1, d.length - 1);
    return R(2 !== c ? h : h.replace(na, '$1'), e, c);
  }

  function ea(d, c) {
    var e = P(c, c.charCodeAt(0), c.charCodeAt(1), c.charCodeAt(2));
    return e !== c + ';' ? e.replace(oa, ' or ($1)').substring(4) : '(' + c + ')';
  }

  function H(d, c, e, h, a, m, b, v, n, q) {
    for (var g = 0, x = c, w; g < A; ++g) {
      switch (w = S[g].call(B, d, x, e, h, a, m, b, v, n, q)) {
        case void 0:
        case !1:
        case !0:
        case null:
          break;

        default:
          x = w;
      }
    }

    if (x !== c) return x;
  }

  function T(d) {
    switch (d) {
      case void 0:
      case null:
        A = S.length = 0;
        break;

      default:
        if ('function' === typeof d) S[A++] = d;else if ('object' === typeof d) for (var c = 0, e = d.length; c < e; ++c) {
          T(d[c]);
        } else Y = !!d | 0;
    }

    return T;
  }

  function U(d) {
    d = d.prefix;
    void 0 !== d && (R = null, d ? 'function' !== typeof d ? w = 1 : (w = 2, R = d) : w = 0);
    return U;
  }

  function B(d, c) {
    var e = d;
    33 > e.charCodeAt(0) && (e = e.trim());
    V = e;
    e = [V];

    if (0 < A) {
      var h = H(-1, c, e, e, D, z, 0, 0, 0, 0);
      void 0 !== h && 'string' === typeof h && (c = h);
    }

    var a = M(O, e, c, 0, 0);
    0 < A && (h = H(-2, a, e, e, D, z, a.length, 0, 0, 0), void 0 !== h && (a = h));
    V = '';
    E = 0;
    z = D = 1;
    return a;
  }

  var ca = /^\0+/g,
      N = /[\0\r\f]/g,
      aa = /: */g,
      ka = /zoo|gra/,
      ma = /([,: ])(transform)/g,
      ia = /,\r+?/g,
      F = /([\t\r\n ])*\f?&/g,
      fa = /@(k\w+)\s*(\S*)\s*/,
      Q = /::(place)/g,
      ha = /:(read-only)/g,
      G = /[svh]\w+-[tblr]{2}/,
      da = /\(\s*(.*)\s*\)/g,
      oa = /([\s\S]*?);/g,
      ba = /-self|flex-/g,
      na = /[^]*?(:[rp][el]a[\w-]+)[^]*/,
      la = /stretch|:\s*\w+\-(?:conte|avail)/,
      ja = /([^-])(image-set\()/,
      z = 1,
      D = 1,
      E = 0,
      w = 1,
      O = [],
      S = [],
      A = 0,
      R = null,
      Y = 0,
      V = '';
  B.use = T;
  B.set = U;
  void 0 !== W && U(W);
  return B;
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (stylis_min);


/***/ }),

/***/ "../node_modules/@reach/router/es/index.js":
/*!*************************************************!*\
  !*** ../node_modules/@reach/router/es/index.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Link: () => (/* binding */ Link),
/* harmony export */   Location: () => (/* binding */ Location),
/* harmony export */   LocationProvider: () => (/* binding */ LocationProvider),
/* harmony export */   Match: () => (/* binding */ Match),
/* harmony export */   Redirect: () => (/* binding */ Redirect),
/* harmony export */   Router: () => (/* binding */ Router),
/* harmony export */   ServerLocation: () => (/* binding */ ServerLocation),
/* harmony export */   createHistory: () => (/* reexport safe */ _lib_history__WEBPACK_IMPORTED_MODULE_5__.createHistory),
/* harmony export */   createMemorySource: () => (/* reexport safe */ _lib_history__WEBPACK_IMPORTED_MODULE_5__.createMemorySource),
/* harmony export */   globalHistory: () => (/* reexport safe */ _lib_history__WEBPACK_IMPORTED_MODULE_5__.globalHistory),
/* harmony export */   isRedirect: () => (/* binding */ isRedirect),
/* harmony export */   matchPath: () => (/* reexport safe */ _lib_utils__WEBPACK_IMPORTED_MODULE_4__.match),
/* harmony export */   navigate: () => (/* reexport safe */ _lib_history__WEBPACK_IMPORTED_MODULE_5__.navigate),
/* harmony export */   redirectTo: () => (/* binding */ redirectTo),
/* harmony export */   useLocation: () => (/* binding */ useLocation),
/* harmony export */   useMatch: () => (/* binding */ useMatch),
/* harmony export */   useNavigate: () => (/* binding */ useNavigate),
/* harmony export */   useParams: () => (/* binding */ useParams)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var invariant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! invariant */ "../node_modules/invariant/browser.js");
/* harmony import */ var invariant__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(invariant__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var create_react_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! create-react-context */ "../node_modules/create-react-context/lib/index.js");
/* harmony import */ var create_react_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(create_react_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_lifecycles_compat__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-lifecycles-compat */ "../node_modules/react-lifecycles-compat/react-lifecycles-compat.es.js");
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./lib/utils */ "../node_modules/@reach/router/es/lib/utils.js");
/* harmony import */ var _lib_history__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./lib/history */ "../node_modules/@reach/router/es/lib/history.js");
var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

function _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/* eslint-disable jsx-a11y/anchor-has-content */








////////////////////////////////////////////////////////////////////////////////

var createNamedContext = function createNamedContext(name, defaultValue) {
  var Ctx = create_react_context__WEBPACK_IMPORTED_MODULE_2___default()(defaultValue);
  Ctx.displayName = name;
  return Ctx;
};

////////////////////////////////////////////////////////////////////////////////
// Location Context/Provider
var LocationContext = createNamedContext("Location");

// sets up a listener if there isn't one already so apps don't need to be
// wrapped in some top level provider
var Location = function Location(_ref) {
  var children = _ref.children;
  return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(
    LocationContext.Consumer,
    null,
    function (context) {
      return context ? children(context) : react__WEBPACK_IMPORTED_MODULE_0___default().createElement(
        LocationProvider,
        null,
        children
      );
    }
  );
};

var LocationProvider = function (_React$Component) {
  _inherits(LocationProvider, _React$Component);

  function LocationProvider() {
    var _temp, _this, _ret;

    _classCallCheck(this, LocationProvider);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, _React$Component.call.apply(_React$Component, [this].concat(args))), _this), _this.state = {
      context: _this.getContext(),
      refs: { unlisten: null }
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  LocationProvider.prototype.getContext = function getContext() {
    var _props$history = this.props.history,
        navigate = _props$history.navigate,
        location = _props$history.location;

    return { navigate: navigate, location: location };
  };

  LocationProvider.prototype.componentDidCatch = function componentDidCatch(error, info) {
    if (isRedirect(error)) {
      var _navigate = this.props.history.navigate;

      _navigate(error.uri, { replace: true });
    } else {
      throw error;
    }
  };

  LocationProvider.prototype.componentDidUpdate = function componentDidUpdate(prevProps, prevState) {
    if (prevState.context.location !== this.state.context.location) {
      this.props.history._onTransitionComplete();
    }
  };

  LocationProvider.prototype.componentDidMount = function componentDidMount() {
    var _this2 = this;

    var refs = this.state.refs,
        history = this.props.history;

    history._onTransitionComplete();
    refs.unlisten = history.listen(function () {
      Promise.resolve().then(function () {
        // TODO: replace rAF with react deferred update API when it's ready https://github.com/facebook/react/issues/13306
        requestAnimationFrame(function () {
          if (!_this2.unmounted) {
            _this2.setState(function () {
              return { context: _this2.getContext() };
            });
          }
        });
      });
    });
  };

  LocationProvider.prototype.componentWillUnmount = function componentWillUnmount() {
    var refs = this.state.refs;

    this.unmounted = true;
    refs.unlisten();
  };

  LocationProvider.prototype.render = function render() {
    var context = this.state.context,
        children = this.props.children;

    return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(
      LocationContext.Provider,
      { value: context },
      typeof children === "function" ? children(context) : children || null
    );
  };

  return LocationProvider;
}((react__WEBPACK_IMPORTED_MODULE_0___default().Component));

////////////////////////////////////////////////////////////////////////////////


LocationProvider.defaultProps = {
  history: _lib_history__WEBPACK_IMPORTED_MODULE_5__.globalHistory
};
 true ? LocationProvider.propTypes = {
  history: (prop_types__WEBPACK_IMPORTED_MODULE_6___default().object).isRequired
} : 0;
var ServerLocation = function ServerLocation(_ref2) {
  var url = _ref2.url,
      children = _ref2.children;

  var searchIndex = url.indexOf("?");
  var searchExists = searchIndex > -1;
  var pathname = void 0;
  var search = "";
  var hash = "";

  if (searchExists) {
    pathname = url.substring(0, searchIndex);
    search = url.substring(searchIndex);
  } else {
    pathname = url;
  }

  return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(
    LocationContext.Provider,
    {
      value: {
        location: {
          pathname: pathname,
          search: search,
          hash: hash
        },
        navigate: function navigate() {
          throw new Error("You can't call navigate on the server.");
        }
      }
    },
    children
  );
};
////////////////////////////////////////////////////////////////////////////////
// Sets baseuri and basepath for nested routers and links
var BaseContext = createNamedContext("Base", { baseuri: "/", basepath: "/" });

////////////////////////////////////////////////////////////////////////////////
// The main event, welcome to the show everybody.
var Router = function Router(props) {
  return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(
    BaseContext.Consumer,
    null,
    function (baseContext) {
      return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(
        Location,
        null,
        function (locationContext) {
          return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(RouterImpl, _extends({}, baseContext, locationContext, props));
        }
      );
    }
  );
};

var RouterImpl = function (_React$PureComponent) {
  _inherits(RouterImpl, _React$PureComponent);

  function RouterImpl() {
    _classCallCheck(this, RouterImpl);

    return _possibleConstructorReturn(this, _React$PureComponent.apply(this, arguments));
  }

  RouterImpl.prototype.render = function render() {
    var _props = this.props,
        location = _props.location,
        _navigate2 = _props.navigate,
        basepath = _props.basepath,
        primary = _props.primary,
        children = _props.children,
        baseuri = _props.baseuri,
        _props$component = _props.component,
        component = _props$component === undefined ? "div" : _props$component,
        domProps = _objectWithoutProperties(_props, ["location", "navigate", "basepath", "primary", "children", "baseuri", "component"]);

    var routes = react__WEBPACK_IMPORTED_MODULE_0___default().Children.toArray(children).reduce(function (array, child) {
      var routes = createRoute(basepath)(child);
      return array.concat(routes);
    }, []);
    var pathname = location.pathname;


    var match = (0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__.pick)(routes, pathname);

    if (match) {
      var params = match.params,
          uri = match.uri,
          route = match.route,
          element = match.route.value;

      // remove the /* from the end for child routes relative paths

      basepath = route.default ? basepath : route.path.replace(/\*$/, "");

      var props = _extends({}, params, {
        uri: uri,
        location: location,
        navigate: function navigate(to, options) {
          return _navigate2((0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__.resolve)(to, uri), options);
        }
      });

      var clone = react__WEBPACK_IMPORTED_MODULE_0___default().cloneElement(element, props, element.props.children ? react__WEBPACK_IMPORTED_MODULE_0___default().createElement(
        Router,
        { location: location, primary: primary },
        element.props.children
      ) : undefined);

      // using 'div' for < 16.3 support
      var FocusWrapper = primary ? FocusHandler : component;
      // don't pass any props to 'div'
      var wrapperProps = primary ? _extends({ uri: uri, location: location, component: component }, domProps) : domProps;

      return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(
        BaseContext.Provider,
        { value: { baseuri: uri, basepath: basepath } },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(
          FocusWrapper,
          wrapperProps,
          clone
        )
      );
    } else {
      // Not sure if we want this, would require index routes at every level
      // warning(
      //   false,
      //   `<Router basepath="${basepath}">\n\nNothing matched:\n\t${
      //     location.pathname
      //   }\n\nPaths checked: \n\t${routes
      //     .map(route => route.path)
      //     .join(
      //       "\n\t"
      //     )}\n\nTo get rid of this warning, add a default NotFound component as child of Router:
      //   \n\tlet NotFound = () => <div>Not Found!</div>
      //   \n\t<Router>\n\t  <NotFound default/>\n\t  {/* ... */}\n\t</Router>`
      // );
      return null;
    }
  };

  return RouterImpl;
}((react__WEBPACK_IMPORTED_MODULE_0___default().PureComponent));

RouterImpl.defaultProps = {
  primary: true
};


var FocusContext = createNamedContext("Focus");

var FocusHandler = function FocusHandler(_ref3) {
  var uri = _ref3.uri,
      location = _ref3.location,
      component = _ref3.component,
      domProps = _objectWithoutProperties(_ref3, ["uri", "location", "component"]);

  return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(
    FocusContext.Consumer,
    null,
    function (requestFocus) {
      return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(FocusHandlerImpl, _extends({}, domProps, {
        component: component,
        requestFocus: requestFocus,
        uri: uri,
        location: location
      }));
    }
  );
};

// don't focus on initial render
var initialRender = true;
var focusHandlerCount = 0;

var FocusHandlerImpl = function (_React$Component2) {
  _inherits(FocusHandlerImpl, _React$Component2);

  function FocusHandlerImpl() {
    var _temp2, _this4, _ret2;

    _classCallCheck(this, FocusHandlerImpl);

    for (var _len2 = arguments.length, args = Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
      args[_key2] = arguments[_key2];
    }

    return _ret2 = (_temp2 = (_this4 = _possibleConstructorReturn(this, _React$Component2.call.apply(_React$Component2, [this].concat(args))), _this4), _this4.state = {}, _this4.requestFocus = function (node) {
      if (!_this4.state.shouldFocus && node) {
        node.focus();
      }
    }, _temp2), _possibleConstructorReturn(_this4, _ret2);
  }

  FocusHandlerImpl.getDerivedStateFromProps = function getDerivedStateFromProps(nextProps, prevState) {
    var initial = prevState.uri == null;
    if (initial) {
      return _extends({
        shouldFocus: true
      }, nextProps);
    } else {
      var myURIChanged = nextProps.uri !== prevState.uri;
      var navigatedUpToMe = prevState.location.pathname !== nextProps.location.pathname && nextProps.location.pathname === nextProps.uri;
      return _extends({
        shouldFocus: myURIChanged || navigatedUpToMe
      }, nextProps);
    }
  };

  FocusHandlerImpl.prototype.componentDidMount = function componentDidMount() {
    focusHandlerCount++;
    this.focus();
  };

  FocusHandlerImpl.prototype.componentWillUnmount = function componentWillUnmount() {
    focusHandlerCount--;
    if (focusHandlerCount === 0) {
      initialRender = true;
    }
  };

  FocusHandlerImpl.prototype.componentDidUpdate = function componentDidUpdate(prevProps, prevState) {
    if (prevProps.location !== this.props.location && this.state.shouldFocus) {
      this.focus();
    }
  };

  FocusHandlerImpl.prototype.focus = function focus() {
    if (false) {}

    var requestFocus = this.props.requestFocus;


    if (requestFocus) {
      requestFocus(this.node);
    } else {
      if (initialRender) {
        initialRender = false;
      } else if (this.node) {
        // React polyfills [autofocus] and it fires earlier than cDM,
        // so we were stealing focus away, this line prevents that.
        if (!this.node.contains(document.activeElement)) {
          this.node.focus();
        }
      }
    }
  };

  FocusHandlerImpl.prototype.render = function render() {
    var _this5 = this;

    var _props2 = this.props,
        children = _props2.children,
        style = _props2.style,
        requestFocus = _props2.requestFocus,
        _props2$component = _props2.component,
        Comp = _props2$component === undefined ? "div" : _props2$component,
        uri = _props2.uri,
        location = _props2.location,
        domProps = _objectWithoutProperties(_props2, ["children", "style", "requestFocus", "component", "uri", "location"]);

    return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(
      Comp,
      _extends({
        style: _extends({ outline: "none" }, style),
        tabIndex: "-1",
        ref: function ref(n) {
          return _this5.node = n;
        }
      }, domProps),
      react__WEBPACK_IMPORTED_MODULE_0___default().createElement(
        FocusContext.Provider,
        { value: this.requestFocus },
        this.props.children
      )
    );
  };

  return FocusHandlerImpl;
}((react__WEBPACK_IMPORTED_MODULE_0___default().Component));

(0,react_lifecycles_compat__WEBPACK_IMPORTED_MODULE_3__.polyfill)(FocusHandlerImpl);

var k = function k() {};

////////////////////////////////////////////////////////////////////////////////
var forwardRef = (react__WEBPACK_IMPORTED_MODULE_0___default().forwardRef);

if (typeof forwardRef === "undefined") {
  forwardRef = function forwardRef(C) {
    return C;
  };
}

var Link = forwardRef(function (_ref4, ref) {
  var innerRef = _ref4.innerRef,
      props = _objectWithoutProperties(_ref4, ["innerRef"]);

  return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(
    BaseContext.Consumer,
    null,
    function (_ref5) {
      var basepath = _ref5.basepath,
          baseuri = _ref5.baseuri;
      return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(
        Location,
        null,
        function (_ref6) {
          var location = _ref6.location,
              navigate = _ref6.navigate;

          var to = props.to,
              state = props.state,
              replace = props.replace,
              _props$getProps = props.getProps,
              getProps = _props$getProps === undefined ? k : _props$getProps,
              anchorProps = _objectWithoutProperties(props, ["to", "state", "replace", "getProps"]);

          var href = (0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__.resolve)(to, baseuri);
          var encodedHref = encodeURI(href);
          var isCurrent = location.pathname === encodedHref;
          var isPartiallyCurrent = (0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__.startsWith)(location.pathname, encodedHref);

          return react__WEBPACK_IMPORTED_MODULE_0___default().createElement("a", _extends({
            ref: ref || innerRef,
            "aria-current": isCurrent ? "page" : undefined
          }, anchorProps, getProps({ isCurrent: isCurrent, isPartiallyCurrent: isPartiallyCurrent, href: href, location: location }), {
            href: href,
            onClick: function onClick(event) {
              if (anchorProps.onClick) anchorProps.onClick(event);
              if (shouldNavigate(event)) {
                event.preventDefault();
                var shouldReplace = replace;
                if (typeof replace !== "boolean" && isCurrent) {
                  var _location$state = _extends({}, location.state),
                      key = _location$state.key,
                      restState = _objectWithoutProperties(_location$state, ["key"]);

                  shouldReplace = (0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__.shallowCompare)(_extends({}, state), restState);
                }
                navigate(href, {
                  state: state,
                  replace: shouldReplace
                });
              }
            }
          }));
        }
      );
    }
  );
});

Link.displayName = "Link";

 true ? Link.propTypes = {
  to: (prop_types__WEBPACK_IMPORTED_MODULE_6___default().string).isRequired
} : 0;

////////////////////////////////////////////////////////////////////////////////
function RedirectRequest(uri) {
  this.uri = uri;
}

var isRedirect = function isRedirect(o) {
  return o instanceof RedirectRequest;
};

var redirectTo = function redirectTo(to) {
  throw new RedirectRequest(to);
};

var RedirectImpl = function (_React$Component3) {
  _inherits(RedirectImpl, _React$Component3);

  function RedirectImpl() {
    _classCallCheck(this, RedirectImpl);

    return _possibleConstructorReturn(this, _React$Component3.apply(this, arguments));
  }

  // Support React < 16 with this hook
  RedirectImpl.prototype.componentDidMount = function componentDidMount() {
    var _props3 = this.props,
        navigate = _props3.navigate,
        to = _props3.to,
        from = _props3.from,
        _props3$replace = _props3.replace,
        replace = _props3$replace === undefined ? true : _props3$replace,
        state = _props3.state,
        noThrow = _props3.noThrow,
        baseuri = _props3.baseuri,
        props = _objectWithoutProperties(_props3, ["navigate", "to", "from", "replace", "state", "noThrow", "baseuri"]);

    Promise.resolve().then(function () {
      var resolvedTo = (0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__.resolve)(to, baseuri);
      navigate((0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__.insertParams)(resolvedTo, props), { replace: replace, state: state });
    });
  };

  RedirectImpl.prototype.render = function render() {
    var _props4 = this.props,
        navigate = _props4.navigate,
        to = _props4.to,
        from = _props4.from,
        replace = _props4.replace,
        state = _props4.state,
        noThrow = _props4.noThrow,
        baseuri = _props4.baseuri,
        props = _objectWithoutProperties(_props4, ["navigate", "to", "from", "replace", "state", "noThrow", "baseuri"]);

    var resolvedTo = (0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__.resolve)(to, baseuri);
    if (!noThrow) redirectTo((0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__.insertParams)(resolvedTo, props));
    return null;
  };

  return RedirectImpl;
}((react__WEBPACK_IMPORTED_MODULE_0___default().Component));

var Redirect = function Redirect(props) {
  return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(
    BaseContext.Consumer,
    null,
    function (_ref7) {
      var baseuri = _ref7.baseuri;
      return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(
        Location,
        null,
        function (locationContext) {
          return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(RedirectImpl, _extends({}, locationContext, { baseuri: baseuri }, props));
        }
      );
    }
  );
};

 true ? Redirect.propTypes = {
  from: (prop_types__WEBPACK_IMPORTED_MODULE_6___default().string),
  to: (prop_types__WEBPACK_IMPORTED_MODULE_6___default().string).isRequired
} : 0;

////////////////////////////////////////////////////////////////////////////////
var Match = function Match(_ref8) {
  var path = _ref8.path,
      children = _ref8.children;
  return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(
    BaseContext.Consumer,
    null,
    function (_ref9) {
      var baseuri = _ref9.baseuri;
      return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(
        Location,
        null,
        function (_ref10) {
          var navigate = _ref10.navigate,
              location = _ref10.location;

          var resolvedPath = (0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__.resolve)(path, baseuri);
          var result = (0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__.match)(resolvedPath, location.pathname);
          return children({
            navigate: navigate,
            location: location,
            match: result ? _extends({}, result.params, {
              uri: result.uri,
              path: path
            }) : null
          });
        }
      );
    }
  );
};

////////////////////////////////////////////////////////////////////////////////
// Hooks

var useLocation = function useLocation() {
  var context = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(LocationContext);

  if (!context) {
    throw new Error("useLocation hook was used but a LocationContext.Provider was not found in the parent tree. Make sure this is used in a component that is a child of Router");
  }

  return context.location;
};

var useNavigate = function useNavigate() {
  var context = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(LocationContext);

  if (!context) {
    throw new Error("useNavigate hook was used but a LocationContext.Provider was not found in the parent tree. Make sure this is used in a component that is a child of Router");
  }

  return context.navigate;
};

var useParams = function useParams() {
  var context = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(BaseContext);

  if (!context) {
    throw new Error("useParams hook was used but a LocationContext.Provider was not found in the parent tree. Make sure this is used in a component that is a child of Router");
  }

  var location = useLocation();

  var results = (0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__.match)(context.basepath, location.pathname);

  return results ? results.params : null;
};

var useMatch = function useMatch(path) {
  if (!path) {
    throw new Error("useMatch(path: string) requires an argument of a string to match against");
  }
  var context = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(BaseContext);

  if (!context) {
    throw new Error("useMatch hook was used but a LocationContext.Provider was not found in the parent tree. Make sure this is used in a component that is a child of Router");
  }

  var location = useLocation();

  var resolvedPath = (0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__.resolve)(path, context.baseuri);
  var result = (0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__.match)(resolvedPath, location.pathname);
  return result ? _extends({}, result.params, {
    uri: result.uri,
    path: path
  }) : null;
};

////////////////////////////////////////////////////////////////////////////////
// Junk
var stripSlashes = function stripSlashes(str) {
  return str.replace(/(^\/+|\/+$)/g, "");
};

var createRoute = function createRoute(basepath) {
  return function (element) {
    if (!element) {
      return null;
    }

    if (element.type === (react__WEBPACK_IMPORTED_MODULE_0___default().Fragment) && element.props.children) {
      return react__WEBPACK_IMPORTED_MODULE_0___default().Children.map(element.props.children, createRoute(basepath));
    }
    !(element.props.path || element.props.default || element.type === Redirect) ?  true ? invariant__WEBPACK_IMPORTED_MODULE_1___default()(false, "<Router>: Children of <Router> must have a `path` or `default` prop, or be a `<Redirect>`. None found on element type `" + element.type + "`") : 0 : void 0;

    !!(element.type === Redirect && (!element.props.from || !element.props.to)) ?  true ? invariant__WEBPACK_IMPORTED_MODULE_1___default()(false, "<Redirect from=\"" + element.props.from + "\" to=\"" + element.props.to + "\"/> requires both \"from\" and \"to\" props when inside a <Router>.") : 0 : void 0;

    !!(element.type === Redirect && !(0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__.validateRedirect)(element.props.from, element.props.to)) ?  true ? invariant__WEBPACK_IMPORTED_MODULE_1___default()(false, "<Redirect from=\"" + element.props.from + " to=\"" + element.props.to + "\"/> has mismatched dynamic segments, ensure both paths have the exact same dynamic segments.") : 0 : void 0;

    if (element.props.default) {
      return { value: element, default: true };
    }

    var elementPath = element.type === Redirect ? element.props.from : element.props.path;

    var path = elementPath === "/" ? basepath : stripSlashes(basepath) + "/" + stripSlashes(elementPath);

    return {
      value: element,
      default: element.props.default,
      path: element.props.children ? stripSlashes(path) + "/*" : path
    };
  };
};

var shouldNavigate = function shouldNavigate(event) {
  return !event.defaultPrevented && event.button === 0 && !(event.metaKey || event.altKey || event.ctrlKey || event.shiftKey);
};

////////////////////////////////////////////////////////////////////////


/***/ }),

/***/ "../node_modules/@reach/router/es/lib/history.js":
/*!*******************************************************!*\
  !*** ../node_modules/@reach/router/es/lib/history.js ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   createHistory: () => (/* binding */ createHistory),
/* harmony export */   createMemorySource: () => (/* binding */ createMemorySource),
/* harmony export */   globalHistory: () => (/* binding */ globalHistory),
/* harmony export */   navigate: () => (/* binding */ navigate)
/* harmony export */ });
var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var getLocation = function getLocation(source) {
  var _source$location = source.location,
      search = _source$location.search,
      hash = _source$location.hash,
      href = _source$location.href,
      origin = _source$location.origin,
      protocol = _source$location.protocol,
      host = _source$location.host,
      hostname = _source$location.hostname,
      port = _source$location.port;
  var pathname = source.location.pathname;


  if (!pathname && href && canUseDOM) {
    var url = new URL(href);
    pathname = url.pathname;
  }

  return {
    pathname: encodeURI(decodeURI(pathname)),
    search: search,
    hash: hash,
    href: href,
    origin: origin,
    protocol: protocol,
    host: host,
    hostname: hostname,
    port: port,
    state: source.history.state,
    key: source.history.state && source.history.state.key || "initial"
  };
};

var createHistory = function createHistory(source, options) {
  var listeners = [];
  var location = getLocation(source);
  var transitioning = false;
  var resolveTransition = function resolveTransition() {};

  return {
    get location() {
      return location;
    },

    get transitioning() {
      return transitioning;
    },

    _onTransitionComplete: function _onTransitionComplete() {
      transitioning = false;
      resolveTransition();
    },
    listen: function listen(listener) {
      listeners.push(listener);

      var popstateListener = function popstateListener() {
        location = getLocation(source);
        listener({ location: location, action: "POP" });
      };

      source.addEventListener("popstate", popstateListener);

      return function () {
        source.removeEventListener("popstate", popstateListener);
        listeners = listeners.filter(function (fn) {
          return fn !== listener;
        });
      };
    },
    navigate: function navigate(to) {
      var _ref = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {},
          state = _ref.state,
          _ref$replace = _ref.replace,
          replace = _ref$replace === undefined ? false : _ref$replace;

      if (typeof to === "number") {
        source.history.go(to);
      } else {
        state = _extends({}, state, { key: Date.now() + "" });
        // try...catch iOS Safari limits to 100 pushState calls
        try {
          if (transitioning || replace) {
            source.history.replaceState(state, null, to);
          } else {
            source.history.pushState(state, null, to);
          }
        } catch (e) {
          source.location[replace ? "replace" : "assign"](to);
        }
      }

      location = getLocation(source);
      transitioning = true;
      var transition = new Promise(function (res) {
        return resolveTransition = res;
      });
      listeners.forEach(function (listener) {
        return listener({ location: location, action: "PUSH" });
      });
      return transition;
    }
  };
};

////////////////////////////////////////////////////////////////////////////////
// Stores history entries in memory for testing or other platforms like Native
var createMemorySource = function createMemorySource() {
  var initialPath = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "/";

  var searchIndex = initialPath.indexOf("?");
  var initialLocation = {
    pathname: searchIndex > -1 ? initialPath.substr(0, searchIndex) : initialPath,
    search: searchIndex > -1 ? initialPath.substr(searchIndex) : ""
  };
  var index = 0;
  var stack = [initialLocation];
  var states = [null];

  return {
    get location() {
      return stack[index];
    },
    addEventListener: function addEventListener(name, fn) {},
    removeEventListener: function removeEventListener(name, fn) {},

    history: {
      get entries() {
        return stack;
      },
      get index() {
        return index;
      },
      get state() {
        return states[index];
      },
      pushState: function pushState(state, _, uri) {
        var _uri$split = uri.split("?"),
            pathname = _uri$split[0],
            _uri$split$ = _uri$split[1],
            search = _uri$split$ === undefined ? "" : _uri$split$;

        index++;
        stack.push({ pathname: pathname, search: search.length ? "?" + search : search });
        states.push(state);
      },
      replaceState: function replaceState(state, _, uri) {
        var _uri$split2 = uri.split("?"),
            pathname = _uri$split2[0],
            _uri$split2$ = _uri$split2[1],
            search = _uri$split2$ === undefined ? "" : _uri$split2$;

        stack[index] = { pathname: pathname, search: search };
        states[index] = state;
      },
      go: function go(to) {
        var newIndex = index + to;

        if (newIndex < 0 || newIndex > states.length - 1) {
          return;
        }

        index = newIndex;
      }
    }
  };
};

////////////////////////////////////////////////////////////////////////////////
// global history - uses window.history as the source if available, otherwise a
// memory history
var canUseDOM = !!(typeof window !== "undefined" && window.document && window.document.createElement);
var getSource = function getSource() {
  return canUseDOM ? window : createMemorySource();
};

var globalHistory = createHistory(getSource());
var navigate = globalHistory.navigate;

////////////////////////////////////////////////////////////////////////////////



/***/ }),

/***/ "../node_modules/@reach/router/es/lib/utils.js":
/*!*****************************************************!*\
  !*** ../node_modules/@reach/router/es/lib/utils.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   insertParams: () => (/* binding */ insertParams),
/* harmony export */   match: () => (/* binding */ match),
/* harmony export */   pick: () => (/* binding */ pick),
/* harmony export */   resolve: () => (/* binding */ resolve),
/* harmony export */   shallowCompare: () => (/* binding */ shallowCompare),
/* harmony export */   startsWith: () => (/* binding */ startsWith),
/* harmony export */   validateRedirect: () => (/* binding */ validateRedirect)
/* harmony export */ });
/* harmony import */ var invariant__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! invariant */ "../node_modules/invariant/browser.js");
/* harmony import */ var invariant__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(invariant__WEBPACK_IMPORTED_MODULE_0__);


////////////////////////////////////////////////////////////////////////////////
// startsWith(string, search) - Check if `string` starts with `search`
var startsWith = function startsWith(string, search) {
  return string.substr(0, search.length) === search;
};

////////////////////////////////////////////////////////////////////////////////
// pick(routes, uri)
//
// Ranks and picks the best route to match. Each segment gets the highest
// amount of points, then the type of segment gets an additional amount of
// points where
//
//     static > dynamic > splat > root
//
// This way we don't have to worry about the order of our routes, let the
// computers do it.
//
// A route looks like this
//
//     { path, default, value }
//
// And a returned match looks like:
//
//     { route, params, uri }
//
// I know, I should use TypeScript not comments for these types.
var pick = function pick(routes, uri) {
  var match = void 0;
  var default_ = void 0;

  var _uri$split = uri.split("?"),
      uriPathname = _uri$split[0];

  var uriSegments = segmentize(uriPathname);
  var isRootUri = uriSegments[0] === "";
  var ranked = rankRoutes(routes);

  for (var i = 0, l = ranked.length; i < l; i++) {
    var missed = false;
    var route = ranked[i].route;

    if (route.default) {
      default_ = {
        route: route,
        params: {},
        uri: uri
      };
      continue;
    }

    var routeSegments = segmentize(route.path);
    var params = {};
    var max = Math.max(uriSegments.length, routeSegments.length);
    var index = 0;

    for (; index < max; index++) {
      var routeSegment = routeSegments[index];
      var uriSegment = uriSegments[index];

      if (isSplat(routeSegment)) {
        // Hit a splat, just grab the rest, and return a match
        // uri:   /files/documents/work
        // route: /files/*
        var param = routeSegment.slice(1) || "*";
        params[param] = uriSegments.slice(index).map(decodeURIComponent).join("/");
        break;
      }

      if (uriSegment === undefined) {
        // URI is shorter than the route, no match
        // uri:   /users
        // route: /users/:userId
        missed = true;
        break;
      }

      var dynamicMatch = paramRe.exec(routeSegment);

      if (dynamicMatch && !isRootUri) {
        var matchIsNotReserved = reservedNames.indexOf(dynamicMatch[1]) === -1;
        !matchIsNotReserved ?  true ? invariant__WEBPACK_IMPORTED_MODULE_0___default()(false, "<Router> dynamic segment \"" + dynamicMatch[1] + "\" is a reserved name. Please use a different name in path \"" + route.path + "\".") : 0 : void 0;
        var value = decodeURIComponent(uriSegment);
        params[dynamicMatch[1]] = value;
      } else if (routeSegment !== uriSegment) {
        // Current segments don't match, not dynamic, not splat, so no match
        // uri:   /users/123/settings
        // route: /users/:id/profile
        missed = true;
        break;
      }
    }

    if (!missed) {
      match = {
        route: route,
        params: params,
        uri: "/" + uriSegments.slice(0, index).join("/")
      };
      break;
    }
  }

  return match || default_ || null;
};

////////////////////////////////////////////////////////////////////////////////
// match(path, uri) - Matches just one path to a uri, also lol
var match = function match(path, uri) {
  return pick([{ path: path }], uri);
};

////////////////////////////////////////////////////////////////////////////////
// resolve(to, basepath)
//
// Resolves URIs as though every path is a directory, no files.  Relative URIs
// in the browser can feel awkward because not only can you be "in a directory"
// you can be "at a file", too. For example
//
//     browserSpecResolve('foo', '/bar/') => /bar/foo
//     browserSpecResolve('foo', '/bar') => /foo
//
// But on the command line of a file system, it's not as complicated, you can't
// `cd` from a file, only directories.  This way, links have to know less about
// their current path. To go deeper you can do this:
//
//     <Link to="deeper"/>
//     // instead of
//     <Link to=`{${props.uri}/deeper}`/>
//
// Just like `cd`, if you want to go deeper from the command line, you do this:
//
//     cd deeper
//     # not
//     cd $(pwd)/deeper
//
// By treating every path as a directory, linking to relative paths should
// require less contextual information and (fingers crossed) be more intuitive.
var resolve = function resolve(to, base) {
  // /foo/bar, /baz/qux => /foo/bar
  if (startsWith(to, "/")) {
    return to;
  }

  var _to$split = to.split("?"),
      toPathname = _to$split[0],
      toQuery = _to$split[1];

  var _base$split = base.split("?"),
      basePathname = _base$split[0];

  var toSegments = segmentize(toPathname);
  var baseSegments = segmentize(basePathname);

  // ?a=b, /users?b=c => /users?a=b
  if (toSegments[0] === "") {
    return addQuery(basePathname, toQuery);
  }

  // profile, /users/789 => /users/789/profile
  if (!startsWith(toSegments[0], ".")) {
    var pathname = baseSegments.concat(toSegments).join("/");
    return addQuery((basePathname === "/" ? "" : "/") + pathname, toQuery);
  }

  // ./         /users/123  =>  /users/123
  // ../        /users/123  =>  /users
  // ../..      /users/123  =>  /
  // ../../one  /a/b/c/d    =>  /a/b/one
  // .././one   /a/b/c/d    =>  /a/b/c/one
  var allSegments = baseSegments.concat(toSegments);
  var segments = [];
  for (var i = 0, l = allSegments.length; i < l; i++) {
    var segment = allSegments[i];
    if (segment === "..") segments.pop();else if (segment !== ".") segments.push(segment);
  }

  return addQuery("/" + segments.join("/"), toQuery);
};

////////////////////////////////////////////////////////////////////////////////
// insertParams(path, params)

var insertParams = function insertParams(path, params) {
  var _path$split = path.split("?"),
      pathBase = _path$split[0],
      _path$split$ = _path$split[1],
      query = _path$split$ === undefined ? "" : _path$split$;

  var segments = segmentize(pathBase);
  var constructedPath = "/" + segments.map(function (segment) {
    var match = paramRe.exec(segment);
    return match ? params[match[1]] : segment;
  }).join("/");
  var _params$location = params.location;
  _params$location = _params$location === undefined ? {} : _params$location;
  var _params$location$sear = _params$location.search,
      search = _params$location$sear === undefined ? "" : _params$location$sear;

  var searchSplit = search.split("?")[1] || "";
  constructedPath = addQuery(constructedPath, query, searchSplit);
  return constructedPath;
};

var validateRedirect = function validateRedirect(from, to) {
  var filter = function filter(segment) {
    return isDynamic(segment);
  };
  var fromString = segmentize(from).filter(filter).sort().join("/");
  var toString = segmentize(to).filter(filter).sort().join("/");
  return fromString === toString;
};

////////////////////////////////////////////////////////////////////////////////
// Junk
var paramRe = /^:(.+)/;

var SEGMENT_POINTS = 4;
var STATIC_POINTS = 3;
var DYNAMIC_POINTS = 2;
var SPLAT_PENALTY = 1;
var ROOT_POINTS = 1;

var isRootSegment = function isRootSegment(segment) {
  return segment === "";
};
var isDynamic = function isDynamic(segment) {
  return paramRe.test(segment);
};
var isSplat = function isSplat(segment) {
  return segment && segment[0] === "*";
};

var rankRoute = function rankRoute(route, index) {
  var score = route.default ? 0 : segmentize(route.path).reduce(function (score, segment) {
    score += SEGMENT_POINTS;
    if (isRootSegment(segment)) score += ROOT_POINTS;else if (isDynamic(segment)) score += DYNAMIC_POINTS;else if (isSplat(segment)) score -= SEGMENT_POINTS + SPLAT_PENALTY;else score += STATIC_POINTS;
    return score;
  }, 0);
  return { route: route, score: score, index: index };
};

var rankRoutes = function rankRoutes(routes) {
  return routes.map(rankRoute).sort(function (a, b) {
    return a.score < b.score ? 1 : a.score > b.score ? -1 : a.index - b.index;
  });
};

var segmentize = function segmentize(uri) {
  return uri
  // strip starting/ending slashes
  .replace(/(^\/+|\/+$)/g, "").split("/");
};

var addQuery = function addQuery(pathname) {
  for (var _len = arguments.length, query = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
    query[_key - 1] = arguments[_key];
  }

  query = query.filter(function (q) {
    return q && q.length > 0;
  });
  return pathname + (query && query.length > 0 ? "?" + query.join("&") : "");
};

var reservedNames = ["uri", "path"];

/**
 * Shallow compares two objects.
 * @param {Object} obj1 The first object to compare.
 * @param {Object} obj2 The second object to compare.
 */
var shallowCompare = function shallowCompare(obj1, obj2) {
  var obj1Keys = Object.keys(obj1);
  return obj1Keys.length === Object.keys(obj2).length && obj1Keys.every(function (key) {
    return obj2.hasOwnProperty(key) && obj1[key] === obj2[key];
  });
};

////////////////////////////////////////////////////////////////////////////////


/***/ }),

/***/ "../app/assets/js/app-context.js":
/*!***************************************!*\
  !*** ../app/assets/js/app-context.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.AppContext = void 0;
exports["default"] = AppProvider;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _slicedToArray2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "../node_modules/@babel/runtime/helpers/slicedToArray.js"));
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
var AppContext = _react.default.createContext();
exports.AppContext = AppContext;
function AppProvider(props) {
  var initialState = {
      isDarkMode: document.body.classList.contains("eps-theme-dark")
    },
    _useState = (0, _react.useState)(initialState),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    state = _useState2[0],
    setState = _useState2[1];
  return /*#__PURE__*/_react.default.createElement(AppContext.Provider, {
    value: {
      state: state,
      setState: setState
    }
  }, props.children);
}
AppProvider.propTypes = {
  children: PropTypes.object.isRequired
};

/***/ }),

/***/ "../app/assets/js/app.js":
/*!*******************************!*\
  !*** ../app/assets/js/app.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = App;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _router = _interopRequireDefault(__webpack_require__(/*! @elementor/router */ "@elementor/router"));
var _router2 = __webpack_require__(/*! @reach/router */ "../node_modules/@reach/router/es/index.js");
var _reachRouterHashHistory = __webpack_require__(/*! reach-router-hash-history */ "../node_modules/reach-router-hash-history/index.js");
var _notFound = _interopRequireDefault(__webpack_require__(/*! elementor-app/pages/not-found */ "../app/assets/js/pages/not-found.js"));
var _index = _interopRequireDefault(__webpack_require__(/*! elementor-app/pages/index */ "../app/assets/js/pages/index.js"));
var _errorBoundary = _interopRequireDefault(__webpack_require__(/*! elementor-app/organisms/error-boundary */ "../app/assets/js/organisms/error-boundary.js"));
__webpack_require__(/*! ./app.scss */ "../app/assets/js/app.scss");
var _appContext = __webpack_require__(/*! elementor-app/app-context */ "../app/assets/js/app-context.js");
var _styledComponents = __webpack_require__(/*! styled-components */ "../node_modules/styled-components/dist/styled-components.browser.esm.js");
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
/**
 * Elementor App
 */

var _React = _react.default,
  Suspense = _React.Suspense;
function App() {
  var appContext = (0, _react.useContext)(_appContext.AppContext),
    isDarkMode = appContext.state.isDarkMode,
    theme = {
      config: {
        variants: {
          light: !isDarkMode,
          dark: isDarkMode
        }
      }
    };

  // Use hash route because it's actually rendered on a WP Admin page.
  // Make it public for external uses.
  _router.default.appHistory = (0, _router2.createHistory)((0, _reachRouterHashHistory.createHashSource)());
  return /*#__PURE__*/_react.default.createElement(_errorBoundary.default, null, /*#__PURE__*/_react.default.createElement(_router2.LocationProvider, {
    history: _router.default.appHistory
  }, /*#__PURE__*/_react.default.createElement(_styledComponents.ThemeProvider, {
    theme: theme
  }, /*#__PURE__*/_react.default.createElement(Suspense, {
    fallback: null
  }, /*#__PURE__*/_react.default.createElement(_router2.Router, null, _router.default.getRoutes(), /*#__PURE__*/_react.default.createElement(_index.default, {
    path: "/"
  }), /*#__PURE__*/_react.default.createElement(_notFound.default, {
    default: true
  }))))));
}

/***/ }),

/***/ "../app/assets/js/event-track/apps-event-tracking.js":
/*!***********************************************************!*\
  !*** ../app/assets/js/event-track/apps-event-tracking.js ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.appsEventTrackingDispatch = void 0;
function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it.return != null) it.return(); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
var appsEventTrackingDispatch = function appsEventTrackingDispatch(command, eventParams) {
  // Add existing eventParams key value pair to the data/details object.
  var objectCreator = function objectCreator(array, obj) {
    var _iterator = _createForOfIteratorHelper(array),
      _step;
    try {
      for (_iterator.s(); !(_step = _iterator.n()).done;) {
        var key = _step.value;
        if (eventParams.hasOwnProperty(key) && eventParams[key] !== null) {
          obj[key] = eventParams[key];
        }
      }
    } catch (err) {
      _iterator.e(err);
    } finally {
      _iterator.f();
    }
    return obj;
  };
  var dataKeys = [];
  var detailsKeys = ['layout', 'site_part', 'error', 'document_name', 'document_type', 'view_type_clicked', 'tag', 'sort_direction', 'sort_type', 'action', 'grid_location', 'kit_name', 'page_source', 'element_position', 'element', 'event_type', 'modal_type', 'method', 'status', 'step', 'item', 'category', 'element_location', 'search_term', 'section', 'site_area'];
  var data = {};
  var details = {};
  var init = function init() {
    objectCreator(detailsKeys, details);
    objectCreator(dataKeys, data);
    var commandSplit = command.split('/');
    data.placement = commandSplit[0];
    data.event = commandSplit[1];

    // If 'details' is not empty, add the details object to the data object.
    if (Object.keys(details).length) {
      data.details = details;
    }
  };
  init();
  $e.run(command, data);
};
exports.appsEventTrackingDispatch = appsEventTrackingDispatch;

/***/ }),

/***/ "../app/assets/js/hooks/use-action.js":
/*!********************************************!*\
  !*** ../app/assets/js/hooks/use-action.js ***!
  \********************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = useAction;
function useAction() {
  return {
    backToDashboard: function backToDashboard() {
      if (window.top === window) {
        window.top.location = elementorAppConfig.admin_url;
      } else {
        // Iframe.
        window.top.$e.run('app/close');
      }
    },
    backToReferrer: function backToReferrer() {
      if (window.top === window) {
        // Directly - in case that the return_url is the login-page, the target should be the admin-page and not the login-page again.
        window.top.location = elementorAppConfig.return_url.includes(elementorAppConfig.login_url) ? elementorAppConfig.admin_url : elementorAppConfig.return_url;
      } else {
        // Iframe.
        window.top.$e.run('app/close');
      }
    }
  };
}

/***/ }),

/***/ "../app/assets/js/hooks/use-ajax.js":
/*!******************************************!*\
  !*** ../app/assets/js/hooks/use-ajax.js ***!
  \******************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = useAjax;
var _regenerator = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/regenerator */ "../node_modules/@babel/runtime/regenerator/index.js"));
var _defineProperty2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "../node_modules/@babel/runtime/helpers/defineProperty.js"));
var _asyncToGenerator2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/asyncToGenerator */ "../node_modules/@babel/runtime/helpers/asyncToGenerator.js"));
var _slicedToArray2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "../node_modules/@babel/runtime/helpers/slicedToArray.js"));
var _react = __webpack_require__(/*! react */ "react");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { (0, _defineProperty2.default)(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function useAjax() {
  var _useState = (0, _react.useState)(null),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    ajax = _useState2[0],
    setAjax = _useState2[1],
    initialStatusKey = 'initial',
    uploadInitialState = {
      status: initialStatusKey,
      isComplete: false,
      response: null
    },
    _useState3 = (0, _react.useState)(uploadInitialState),
    _useState4 = (0, _slicedToArray2.default)(_useState3, 2),
    ajaxState = _useState4[0],
    setAjaxState = _useState4[1],
    ajaxActions = {
      reset: function reset() {
        return setAjaxState(initialStatusKey);
      }
    };
  var runRequest = /*#__PURE__*/function () {
    var _ref = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee(config) {
      return _regenerator.default.wrap(function _callee$(_context) {
        while (1) switch (_context.prev = _context.next) {
          case 0:
            return _context.abrupt("return", new Promise(function (resolve, reject) {
              var formData = new FormData();
              if (config.data) {
                for (var key in config.data) {
                  formData.append(key, config.data[key]);
                }
                if (!config.data.nonce) {
                  formData.append('_nonce', elementorCommon.config.ajax.nonce);
                }
              }
              var options = _objectSpread(_objectSpread({
                type: 'post',
                url: elementorCommon.config.ajax.url,
                headers: {},
                cache: false,
                contentType: false,
                processData: false
              }, config), {}, {
                data: formData,
                success: function success(response) {
                  resolve(response);
                },
                error: function error(_error) {
                  reject(_error);
                }
              });
              jQuery.ajax(options);
            }));
          case 1:
          case "end":
            return _context.stop();
        }
      }, _callee);
    }));
    return function runRequest(_x) {
      return _ref.apply(this, arguments);
    };
  }();
  (0, _react.useEffect)(function () {
    if (ajax) {
      runRequest(ajax).then(function (response) {
        var status = response.success ? 'success' : 'error';
        setAjaxState(function (prevState) {
          return _objectSpread(_objectSpread({}, prevState), {}, {
            status: status,
            response: response === null || response === void 0 ? void 0 : response.data
          });
        });
      }).catch(function (error) {
        var _error$responseJSON;
        var response = 408 === error.status ? 'timeout' : (_error$responseJSON = error.responseJSON) === null || _error$responseJSON === void 0 ? void 0 : _error$responseJSON.data;
        setAjaxState(function (prevState) {
          return _objectSpread(_objectSpread({}, prevState), {}, {
            status: 'error',
            response: response
          });
        });
      }).finally(function () {
        setAjaxState(function (prevState) {
          return _objectSpread(_objectSpread({}, prevState), {}, {
            isComplete: true
          });
        });
      });
    }
  }, [ajax]);
  return {
    ajax: ajax,
    setAjax: setAjax,
    ajaxState: ajaxState,
    ajaxActions: ajaxActions,
    runRequest: runRequest
  };
}

/***/ }),

/***/ "../app/assets/js/hooks/use-page-title.js":
/*!************************************************!*\
  !*** ../app/assets/js/hooks/use-page-title.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = usePageTitle;
var _react = __webpack_require__(/*! react */ "react");
function usePageTitle(_ref) {
  var title = _ref.title,
    prefix = _ref.prefix;
  (0, _react.useEffect)(function () {
    if (!prefix) {
      prefix = __('Elementor', 'elementor');
    }
    document.title = "".concat(prefix, " | ").concat(title);
  }, [title, prefix]);
}

/***/ }),

/***/ "../app/assets/js/hooks/use-query-params.js":
/*!**************************************************!*\
  !*** ../app/assets/js/hooks/use-query-params.js ***!
  \**************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = useQueryParams;
var _defineProperty2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "../node_modules/@babel/runtime/helpers/defineProperty.js"));
var _slicedToArray2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "../node_modules/@babel/runtime/helpers/slicedToArray.js"));
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { (0, _defineProperty2.default)(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function useQueryParams() {
  var _location$hash$match;
  var urlSearchParams = new URLSearchParams(window.location.search),
    urlParams = Object.fromEntries(urlSearchParams.entries()),
    hashValue = (_location$hash$match = location.hash.match(/\?(.+)/)) === null || _location$hash$match === void 0 ? void 0 : _location$hash$match[1],
    hashParams = {};
  if (hashValue) {
    hashValue.split('&').forEach(function (pair) {
      var _pair$split = pair.split('='),
        _pair$split2 = (0, _slicedToArray2.default)(_pair$split, 2),
        key = _pair$split2[0],
        value = _pair$split2[1];
      hashParams[key] = value;
    });
  }

  // Merging the URL params with the hash params.
  var queryParams = _objectSpread(_objectSpread({}, urlParams), hashParams);
  return {
    getAll: function getAll() {
      return queryParams;
    }
  };
}

/***/ }),

/***/ "../app/assets/js/layout/content.js":
/*!******************************************!*\
  !*** ../app/assets/js/layout/content.js ***!
  \******************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = Content;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
function Content(props) {
  return /*#__PURE__*/_react.default.createElement("main", {
    className: "eps-app__content ".concat(props.className)
  }, props.children);
}
Content.propTypes = {
  children: PropTypes.any,
  className: PropTypes.string
};
Content.defaultProps = {
  className: ''
};

/***/ }),

/***/ "../app/assets/js/layout/footer.js":
/*!*****************************************!*\
  !*** ../app/assets/js/layout/footer.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = Footer;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
function Footer(props) {
  return /*#__PURE__*/_react.default.createElement("footer", {
    className: "eps-app__footer"
  }, props.children);
}
Footer.propTypes = {
  children: PropTypes.object
};

/***/ }),

/***/ "../app/assets/js/layout/header-button.js":
/*!************************************************!*\
  !*** ../app/assets/js/layout/header-button.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _classCallCheck2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "../node_modules/@babel/runtime/helpers/classCallCheck.js"));
var _createClass2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/createClass */ "../node_modules/@babel/runtime/helpers/createClass.js"));
var _get2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/get */ "../node_modules/@babel/runtime/helpers/get.js"));
var _inherits2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/inherits */ "../node_modules/@babel/runtime/helpers/inherits.js"));
var _possibleConstructorReturn2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/possibleConstructorReturn */ "../node_modules/@babel/runtime/helpers/possibleConstructorReturn.js"));
var _getPrototypeOf2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/getPrototypeOf */ "../node_modules/@babel/runtime/helpers/getPrototypeOf.js"));
var _defineProperty2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "../node_modules/@babel/runtime/helpers/defineProperty.js"));
var _button = _interopRequireDefault(__webpack_require__(/*! ../ui/molecules/button */ "../app/assets/js/ui/molecules/button.js"));
function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0, _getPrototypeOf2.default)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0, _getPrototypeOf2.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0, _possibleConstructorReturn2.default)(this, result); }; }
function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var Button = /*#__PURE__*/function (_BaseButton) {
  (0, _inherits2.default)(Button, _BaseButton);
  var _super = _createSuper(Button);
  function Button() {
    (0, _classCallCheck2.default)(this, Button);
    return _super.apply(this, arguments);
  }
  (0, _createClass2.default)(Button, [{
    key: "getCssId",
    value: function getCssId() {
      return "eps-app-header-btn-" + (0, _get2.default)((0, _getPrototypeOf2.default)(Button.prototype), "getCssId", this).call(this);
    }
  }, {
    key: "getClassName",
    value: function getClassName() {
      // Avoid using the 'eps-app__header-btn' class to make sure it is not override custom styles.
      if (!this.props.includeHeaderBtnClass) {
        return (0, _get2.default)((0, _getPrototypeOf2.default)(Button.prototype), "getClassName", this).call(this);
      }
      return "eps-app__header-btn " + (0, _get2.default)((0, _getPrototypeOf2.default)(Button.prototype), "getClassName", this).call(this);
    }
  }]);
  return Button;
}(_button.default);
exports["default"] = Button;
(0, _defineProperty2.default)(Button, "defaultProps", Object.assign({} /* Clone */, _button.default.defaultProps, {
  hideText: true,
  includeHeaderBtnClass: true
}));

/***/ }),

/***/ "../app/assets/js/layout/header-buttons.js":
/*!*************************************************!*\
  !*** ../app/assets/js/layout/header-buttons.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = HeaderButtons;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _extends2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/extends */ "../node_modules/@babel/runtime/helpers/extends.js"));
var _useAction = _interopRequireDefault(__webpack_require__(/*! elementor-app/hooks/use-action */ "../app/assets/js/hooks/use-action.js"));
var _headerButton = _interopRequireDefault(__webpack_require__(/*! ./header-button */ "../app/assets/js/layout/header-button.js"));
function HeaderButtons(props) {
  var action = (0, _useAction.default)();
  var actionOnClose = function actionOnClose() {
    if (props.onClose) {
      props.onClose();
    } else {
      action.backToDashboard();
    }
  };
  var tools = '';
  if (props.buttons.length) {
    var buttons = props.buttons.map(function (button) {
      return /*#__PURE__*/_react.default.createElement(_headerButton.default, (0, _extends2.default)({
        key: button.id
      }, button));
    });
    tools = /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, buttons);
  }
  return /*#__PURE__*/_react.default.createElement("div", {
    className: "eps-app__header-buttons"
  }, /*#__PURE__*/_react.default.createElement(_headerButton.default, {
    text: __('Close', 'elementor'),
    icon: "eicon-close",
    className: "eps-app__close-button",
    onClick: actionOnClose
  }), tools);
}
HeaderButtons.propTypes = {
  buttons: PropTypes.arrayOf(PropTypes.object),
  onClose: PropTypes.func
};
HeaderButtons.defaultProps = {
  buttons: []
};

/***/ }),

/***/ "../app/assets/js/layout/header.js":
/*!*****************************************!*\
  !*** ../app/assets/js/layout/header.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = Header;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _extends2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/extends */ "../node_modules/@babel/runtime/helpers/extends.js"));
var _grid = _interopRequireDefault(__webpack_require__(/*! ../ui/grid/grid */ "../app/assets/js/ui/grid/grid.js"));
var _headerButtons = _interopRequireDefault(__webpack_require__(/*! ./header-buttons */ "../app/assets/js/layout/header-buttons.js"));
var _usePageTitle = _interopRequireDefault(__webpack_require__(/*! elementor-app/hooks/use-page-title */ "../app/assets/js/hooks/use-page-title.js"));
function Header(props) {
  (0, _usePageTitle.default)({
    title: props.title
  });
  var TitleTag = 'span',
    titleAttrs = {};
  if (props.titleRedirectRoute) {
    TitleTag = 'a';
    titleAttrs = {
      href: "#".concat(props.titleRedirectRoute),
      target: '_self'
    };
  }
  return /*#__PURE__*/_react.default.createElement(_grid.default, {
    container: true,
    alignItems: "center",
    justify: "space-between",
    className: "eps-app__header"
  }, /*#__PURE__*/_react.default.createElement(TitleTag, (0, _extends2.default)({
    className: "eps-app__logo-title-wrapper"
  }, titleAttrs), /*#__PURE__*/_react.default.createElement("i", {
    className: "eps-app__logo eicon-elementor"
  }), /*#__PURE__*/_react.default.createElement("h1", {
    className: "eps-app__title"
  }, props.title)), /*#__PURE__*/_react.default.createElement(_headerButtons.default, {
    buttons: props.buttons
  }));
}
Header.propTypes = {
  title: PropTypes.string,
  titleRedirectRoute: PropTypes.string,
  buttons: PropTypes.arrayOf(PropTypes.object),
  onClose: PropTypes.func
};
Header.defaultProps = {
  buttons: []
};

/***/ }),

/***/ "../app/assets/js/layout/page.js":
/*!***************************************!*\
  !*** ../app/assets/js/layout/page.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = Page;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _header = _interopRequireDefault(__webpack_require__(/*! ./header */ "../app/assets/js/layout/header.js"));
var _sidebar = _interopRequireDefault(__webpack_require__(/*! ./sidebar */ "../app/assets/js/layout/sidebar.js"));
var _content = _interopRequireDefault(__webpack_require__(/*! ./content */ "../app/assets/js/layout/content.js"));
var _footer = _interopRequireDefault(__webpack_require__(/*! ./footer */ "../app/assets/js/layout/footer.js"));
function Page(props) {
  var AppSidebar = function AppSidebar() {
      if (!props.sidebar) {
        return;
      }
      return /*#__PURE__*/_react.default.createElement(_sidebar.default, null, props.sidebar);
    },
    AppFooter = function AppFooter() {
      if (!props.footer) {
        return;
      }
      return /*#__PURE__*/_react.default.createElement(_footer.default, null, props.footer);
    };
  return /*#__PURE__*/_react.default.createElement("div", {
    className: "eps-app__lightbox ".concat(props.className)
  }, /*#__PURE__*/_react.default.createElement("div", {
    className: "eps-app"
  }, /*#__PURE__*/_react.default.createElement(_header.default, {
    title: props.title,
    buttons: props.headerButtons,
    titleRedirectRoute: props.titleRedirectRoute,
    onClose: function onClose() {
      var _props$onClose;
      return (_props$onClose = props.onClose) === null || _props$onClose === void 0 ? void 0 : _props$onClose.call(props);
    }
  }), /*#__PURE__*/_react.default.createElement("div", {
    className: "eps-app__main"
  }, AppSidebar(), /*#__PURE__*/_react.default.createElement(_content.default, null, props.content)), AppFooter()));
}
Page.propTypes = {
  title: PropTypes.string,
  titleRedirectRoute: PropTypes.string,
  className: PropTypes.string,
  headerButtons: PropTypes.arrayOf(PropTypes.object),
  sidebar: PropTypes.object,
  content: PropTypes.object.isRequired,
  footer: PropTypes.object,
  onClose: PropTypes.func
};
Page.defaultProps = {
  className: ''
};

/***/ }),

/***/ "../app/assets/js/layout/sidebar.js":
/*!******************************************!*\
  !*** ../app/assets/js/layout/sidebar.js ***!
  \******************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = Sidebar;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
function Sidebar(props) {
  return /*#__PURE__*/_react.default.createElement("div", {
    className: "eps-app__sidebar"
  }, props.children);
}
Sidebar.propTypes = {
  children: PropTypes.object
};

/***/ }),

/***/ "../app/assets/js/molecules/collapse-content.js":
/*!******************************************************!*\
  !*** ../app/assets/js/molecules/collapse-content.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = CollapseContent;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
function CollapseContent(props) {
  return /*#__PURE__*/_react.default.createElement("div", {
    className: "e-app-collapse-content"
  }, props.children);
}
CollapseContent.propTypes = {
  className: PropTypes.string,
  children: PropTypes.any
};
CollapseContent.defaultProps = {
  className: ''
};

/***/ }),

/***/ "../app/assets/js/molecules/collapse-context.js":
/*!******************************************************!*\
  !*** ../app/assets/js/molecules/collapse-context.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.CollapseContext = void 0;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var CollapseContext = _react.default.createContext();
exports.CollapseContext = CollapseContext;

/***/ }),

/***/ "../app/assets/js/molecules/collapse-toggle.js":
/*!*****************************************************!*\
  !*** ../app/assets/js/molecules/collapse-toggle.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = CollapseToggle;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _defineProperty2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "../node_modules/@babel/runtime/helpers/defineProperty.js"));
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
var _collapseContext = __webpack_require__(/*! ./collapse-context */ "../app/assets/js/molecules/collapse-context.js");
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function CollapseToggle(props) {
  var context = (0, _react.useContext)(_collapseContext.CollapseContext),
    style = {
      '--e-app-collapse-toggle-icon-spacing': (0, _utils.pxToRem)(props.iconSpacing)
    },
    classNameBase = 'e-app-collapse-toggle',
    classes = [classNameBase, (0, _defineProperty2.default)({}, classNameBase + '--active', props.active)],
    attrs = {
      style: style,
      className: (0, _utils.arrayToClassName)(classes)
    };
  if (props.active) {
    attrs.onClick = function () {
      return context.toggle();
    };
  }
  return /*#__PURE__*/_react.default.createElement("div", attrs, props.children, props.active && props.showIcon && /*#__PURE__*/_react.default.createElement("i", {
    className: "eicon-caret-down e-app-collapse-toggle__icon"
  }));
}
CollapseToggle.propTypes = {
  className: PropTypes.string,
  iconSpacing: PropTypes.number,
  showIcon: PropTypes.bool,
  active: PropTypes.bool,
  children: PropTypes.any
};
CollapseToggle.defaultProps = {
  className: '',
  iconSpacing: 20,
  showIcon: true,
  active: true
};

/***/ }),

/***/ "../app/assets/js/molecules/collapse.js":
/*!**********************************************!*\
  !*** ../app/assets/js/molecules/collapse.js ***!
  \**********************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = Collapse;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _defineProperty2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "../node_modules/@babel/runtime/helpers/defineProperty.js"));
var _slicedToArray2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "../node_modules/@babel/runtime/helpers/slicedToArray.js"));
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
var _collapseContext = __webpack_require__(/*! ./collapse-context */ "../app/assets/js/molecules/collapse-context.js");
var _collapseToggle = _interopRequireDefault(__webpack_require__(/*! ./collapse-toggle */ "../app/assets/js/molecules/collapse-toggle.js"));
var _collapseContent = _interopRequireDefault(__webpack_require__(/*! ./collapse-content */ "../app/assets/js/molecules/collapse-content.js"));
__webpack_require__(/*! ./collapse.scss */ "../app/assets/js/molecules/collapse.scss");
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function Collapse(props) {
  var _useState = (0, _react.useState)(props.isOpened),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    isOpened = _useState2[0],
    setIsOpened = _useState2[1],
    classNameBase = 'e-app-collapse',
    classes = [classNameBase, props.className, (0, _defineProperty2.default)({}, classNameBase + '--opened', isOpened)],
    toggle = function toggle() {
      return setIsOpened(function (prevState) {
        return !prevState;
      });
    };
  (0, _react.useEffect)(function () {
    if (props.isOpened !== isOpened) {
      setIsOpened(props.isOpened);
    }
  }, [props.isOpened]);
  (0, _react.useEffect)(function () {
    if (props.onChange) {
      props.onChange(isOpened);
    }
  }, [isOpened]);
  return /*#__PURE__*/_react.default.createElement(_collapseContext.CollapseContext.Provider, {
    value: {
      toggle: toggle
    }
  }, /*#__PURE__*/_react.default.createElement("div", {
    className: (0, _utils.arrayToClassName)(classes)
  }, props.children));
}
Collapse.propTypes = {
  className: PropTypes.string,
  isOpened: PropTypes.bool,
  onChange: PropTypes.func,
  children: PropTypes.oneOfType([PropTypes.node, PropTypes.arrayOf(PropTypes.node)])
};
Collapse.defaultProps = {
  className: '',
  isOpened: false
};
Collapse.Toggle = _collapseToggle.default;
Collapse.Content = _collapseContent.default;

/***/ }),

/***/ "../app/assets/js/molecules/dashboard-button.js":
/*!******************************************************!*\
  !*** ../app/assets/js/molecules/dashboard-button.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = DashboardButton;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _extends2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/extends */ "../node_modules/@babel/runtime/helpers/extends.js"));
var _button = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/button */ "../app/assets/js/ui/molecules/button.js"));
var _useAction = _interopRequireDefault(__webpack_require__(/*! elementor-app/hooks/use-action */ "../app/assets/js/hooks/use-action.js"));
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
function DashboardButton(props) {
  var action = (0, _useAction.default)(),
    baseClassName = 'e-app-dashboard-button',
    classes = [baseClassName, props.className];
  return /*#__PURE__*/_react.default.createElement(_button.default, (0, _extends2.default)({}, props, {
    className: (0, _utils.arrayToClassName)(classes),
    text: props.text,
    onClick: action.backToDashboard
  }));
}
DashboardButton.propTypes = {
  className: PropTypes.string,
  text: PropTypes.string
};
DashboardButton.defaultProps = {
  className: '',
  variant: 'contained',
  color: 'primary',
  text: __('Back to dashboard', 'elementor')
};

/***/ }),

/***/ "../app/assets/js/molecules/data-table.js":
/*!************************************************!*\
  !*** ../app/assets/js/molecules/data-table.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = DataTable;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _utils = __webpack_require__(/*! ../utils/utils */ "../app/assets/js/utils/utils.js");
var _table = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/table/table */ "../app/assets/js/ui/table/table.js"));
function DataTable(_ref) {
  var className = _ref.className,
    onSelect = _ref.onSelect,
    initialSelected = _ref.initialSelected,
    initialDisabled = _ref.initialDisabled,
    headers = _ref.headers,
    layout = _ref.layout,
    rows = _ref.rows,
    selection = _ref.selection;
  return /*#__PURE__*/_react.default.createElement(_table.default, {
    selection: selection,
    onSelect: onSelect,
    initialSelected: initialSelected,
    initialDisabled: initialDisabled,
    className: (0, _utils.arrayToClassName)(['e-app-data-table', className])
  }, !!headers.length && /*#__PURE__*/_react.default.createElement(_table.default.Head, null, /*#__PURE__*/_react.default.createElement(_table.default.Row, null, selection && /*#__PURE__*/_react.default.createElement(_table.default.Cell, {
    tag: "th"
  }, /*#__PURE__*/_react.default.createElement(_table.default.Checkbox, {
    allSelectedCount: rows.length
  })), headers.map(function (header, index) {
    return /*#__PURE__*/_react.default.createElement(_table.default.Cell, {
      tag: "th",
      colSpan: layout && layout[index],
      key: index
    }, header);
  }))), /*#__PURE__*/_react.default.createElement(_table.default.Body, null, rows.map(function (row, rowIndex) {
    return /*#__PURE__*/_react.default.createElement(_table.default.Row, {
      key: rowIndex
    }, selection && /*#__PURE__*/_react.default.createElement(_table.default.Cell, {
      tag: "td"
    }, /*#__PURE__*/_react.default.createElement(_table.default.Checkbox, {
      index: rowIndex
    })), row.map(function (cell, cellIndex) {
      return /*#__PURE__*/_react.default.createElement(_table.default.Cell, {
        tag: "td",
        colSpan: layout && layout[cellIndex],
        key: cellIndex
      }, cell);
    }));
  })));
}
DataTable.propTypes = {
  className: PropTypes.string,
  headers: PropTypes.array,
  rows: PropTypes.array,
  initialDisabled: PropTypes.array,
  initialSelected: PropTypes.array,
  layout: PropTypes.array,
  onSelect: PropTypes.func,
  selection: PropTypes.bool,
  withHeader: PropTypes.bool
};
DataTable.defaultProps = {
  className: '',
  headers: [],
  rows: [],
  initialDisabled: [],
  initialSelected: [],
  selection: false
};

/***/ }),

/***/ "../app/assets/js/molecules/go-pro-button.js":
/*!***************************************************!*\
  !*** ../app/assets/js/molecules/go-pro-button.js ***!
  \***************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = GoProButton;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _extends2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/extends */ "../node_modules/@babel/runtime/helpers/extends.js"));
var _button = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/button */ "../app/assets/js/ui/molecules/button.js"));
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
function GoProButton(props) {
  var baseClassName = 'e-app-go-pro-button',
    classes = [baseClassName, props.className];
  return /*#__PURE__*/_react.default.createElement(_button.default, (0, _extends2.default)({}, props, {
    className: (0, _utils.arrayToClassName)(classes),
    text: props.text
  }));
}
GoProButton.propTypes = {
  className: PropTypes.string,
  text: PropTypes.string
};
GoProButton.defaultProps = {
  className: '',
  variant: 'outlined',
  size: 'sm',
  color: 'cta',
  target: '_blank',
  rel: 'noopener noreferrer',
  text: __('Upgrade Now', 'elementor')
};

/***/ }),

/***/ "../app/assets/js/molecules/tooltip.js":
/*!*********************************************!*\
  !*** ../app/assets/js/molecules/tooltip.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = Tooltip;
var _slicedToArray2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "../node_modules/@babel/runtime/helpers/slicedToArray.js"));
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _utils = __webpack_require__(/*! ../utils/utils */ "../app/assets/js/utils/utils.js");
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function Tooltip(props) {
  var baseClassName = 'e-app-tooltip',
    classes = [baseClassName, props.className],
    childRef = (0, _react.useRef)(null),
    isAborted = (0, _react.useRef)(false),
    isManualControl = Object.prototype.hasOwnProperty.call(props, 'show'),
    _useState = (0, _react.useState)(false),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    isLibraryLoaded = _useState2[0],
    setIsLibraryLoaded = _useState2[1],
    _useState3 = (0, _react.useState)(false),
    _useState4 = (0, _slicedToArray2.default)(_useState3, 2),
    showTooltip = _useState4[0],
    setShowTooltip = _useState4[1],
    directionsMap = {
      top: 's',
      right: 'w',
      down: 'n',
      left: 'e'
    },
    tipsyConfig = {
      trigger: isManualControl ? 'manual' : 'hover',
      gravity: directionsMap[props.direction],
      offset: props.offset,
      title: function title() {
        return props.title;
      }
    },
    setTipsy = function setTipsy() {
      var $tooltipContainer = jQuery(childRef.current);
      $tooltipContainer.tipsy(tipsyConfig);
      if (isManualControl) {
        var displayMode = showTooltip ? 'show' : 'hide';
        $tooltipContainer.tipsy(displayMode);
      }
    };
  (0, _react.useEffect)(function () {
    // In case that the component is disabled the tipsy library will not be loaded by default.
    if (!props.disabled) {
      isAborted.current = false;
      import( /* webpackIgnore: true */"".concat(elementorCommon.config.urls.assets, "lib/tipsy/tipsy.min.js?ver=1.0.0")).then(function () {
        if (!isAborted.current) {
          if (isLibraryLoaded) {
            setTipsy();
          } else {
            setIsLibraryLoaded(true);
          }
        }
      });
    }
    return function () {
      if (!props.disabled) {
        // Aborting the current dynamic-import state update in case of re-render.
        isAborted.current = true;

        // Cleanup of existing tipsy element in case of re-render.
        var nodes = document.querySelectorAll('.tipsy');
        if (!nodes.length) {
          return;
        }
        nodes[nodes.length - 1].remove();
      }
    };
  }, [props.disabled]);
  (0, _react.useEffect)(function () {
    if (isLibraryLoaded) {
      setTipsy();
    }
  }, [isLibraryLoaded, showTooltip]);
  (0, _react.useEffect)(function () {
    // The "show" state should not be changed while the component is disabled.
    if (!props.disabled && props.show !== showTooltip) {
      setShowTooltip(props.show);
    }
  }, [props.show]);
  return /*#__PURE__*/_react.default.createElement(props.tag, {
    className: (0, _utils.arrayToClassName)(classes),
    ref: childRef
  }, props.children);
}
Tooltip.propTypes = {
  className: PropTypes.string,
  offset: PropTypes.number,
  show: PropTypes.bool,
  direction: PropTypes.oneOf(['top', 'right', 'left', 'down']),
  tag: PropTypes.string.isRequired,
  title: PropTypes.string.isRequired,
  disabled: PropTypes.bool,
  children: PropTypes.any
};
Tooltip.defaultProps = {
  className: '',
  offset: 10,
  direction: 'top',
  disabled: false
};

/***/ }),

/***/ "../app/assets/js/molecules/upload-file.js":
/*!*************************************************!*\
  !*** ../app/assets/js/molecules/upload-file.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = UploadFile;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _button = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/button */ "../app/assets/js/ui/molecules/button.js"));
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
__webpack_require__(/*! ./upload-file.scss */ "../app/assets/js/molecules/upload-file.scss");
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function UploadFile(props) {
  var fileInput = (0, _react.useRef)(null),
    baseClassName = 'e-app-upload-file',
    classes = [baseClassName, props.className];

  // For 'wp-media' type.
  var frame;
  return /*#__PURE__*/_react.default.createElement("div", {
    className: (0, _utils.arrayToClassName)(classes)
  }, /*#__PURE__*/_react.default.createElement("input", {
    ref: fileInput,
    type: "file",
    accept: props.filetypes.map(function (type) {
      return '.' + type;
    }).join(', '),
    className: "e-app-upload-file__input",
    onChange: function onChange(event) {
      var file = event.target.files[0];
      if (file && (0, _utils.isOneOf)(file.type, props.filetypes)) {
        props.onFileSelect(file, event, 'browse');
      } else {
        fileInput.current.value = '';
        props.onError({
          id: 'file_not_allowed',
          message: __('This file type is not allowed', 'elementor')
        });
      }
    }
  }), /*#__PURE__*/_react.default.createElement(_button.default, {
    className: "e-app-upload-file__button",
    text: props.text,
    variant: props.variant,
    color: props.color,
    size: "lg",
    hideText: props.isLoading,
    icon: props.isLoading ? 'eicon-loading eicon-animation-spin' : '',
    onClick: function onClick() {
      if (props.onFileChoose) {
        props.onFileChoose();
      }
      if (!props.isLoading) {
        if (props.onButtonClick) {
          props.onButtonClick();
        }
        if ('file-explorer' === props.type) {
          fileInput.current.click();
        } else if ('wp-media' === props.type) {
          if (frame) {
            frame.open();
            return;
          }

          // Initialize the WP Media frame.
          frame = wp.media({
            multiple: false,
            library: {
              type: ['image', 'image/svg+xml']
            }
          });
          frame.on('select', function () {
            if (props.onWpMediaSelect) {
              props.onWpMediaSelect(frame);
            }
          });
          frame.open();
        }
      }
    }
  }));
}
UploadFile.propTypes = {
  className: PropTypes.string,
  type: PropTypes.string,
  onWpMediaSelect: PropTypes.func,
  text: PropTypes.string,
  onFileSelect: PropTypes.func,
  isLoading: PropTypes.bool,
  filetypes: PropTypes.array.isRequired,
  onError: PropTypes.func,
  variant: PropTypes.string,
  color: PropTypes.string,
  onButtonClick: PropTypes.func,
  onFileChoose: PropTypes.func
};
UploadFile.defaultProps = {
  className: '',
  type: 'file-explorer',
  text: __('Select File', 'elementor'),
  onError: function onError() {},
  variant: 'contained',
  color: 'primary'
};

/***/ }),

/***/ "../app/assets/js/organisms/drop-zone.js":
/*!***********************************************!*\
  !*** ../app/assets/js/organisms/drop-zone.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = DropZone;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _extends2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/extends */ "../node_modules/@babel/runtime/helpers/extends.js"));
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
var _uploadFile = _interopRequireDefault(__webpack_require__(/*! elementor-app/molecules/upload-file */ "../app/assets/js/molecules/upload-file.js"));
var _dragDrop = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/drag-drop */ "../app/assets/js/ui/atoms/drag-drop.js"));
var _icon = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/icon */ "../app/assets/js/ui/atoms/icon.js"));
var _heading = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/heading */ "../app/assets/js/ui/atoms/heading.js"));
var _text = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/text */ "../app/assets/js/ui/atoms/text.js"));
__webpack_require__(/*! ./drop-zone.scss */ "../app/assets/js/organisms/drop-zone.scss");
function DropZone(props) {
  var classes = ['e-app-drop-zone', props.className],
    dragDropEvents = {
      onDrop: function onDrop(event) {
        if (!props.isLoading) {
          var file = event.dataTransfer.files[0];
          if (file && (0, _utils.isOneOf)(file.type, props.filetypes)) {
            props.onFileSelect(file, event, 'drop');
          } else {
            props.onError({
              id: 'file_not_allowed',
              message: __('This file type is not allowed', 'elementor')
            });
          }
        }
      }
    };
  return /*#__PURE__*/_react.default.createElement("section", {
    className: (0, _utils.arrayToClassName)(classes)
  }, /*#__PURE__*/_react.default.createElement(_dragDrop.default, (0, _extends2.default)({}, dragDropEvents, {
    isLoading: props.isLoading
  }), props.icon && /*#__PURE__*/_react.default.createElement(_icon.default, {
    className: "e-app-drop-zone__icon ".concat(props.icon)
  }), props.heading && /*#__PURE__*/_react.default.createElement(_heading.default, {
    variant: "display-3"
  }, props.heading), props.text && /*#__PURE__*/_react.default.createElement(_text.default, {
    variant: "xl",
    className: "e-app-drop-zone__text"
  }, props.text), props.secondaryText && /*#__PURE__*/_react.default.createElement(_text.default, {
    variant: "xl",
    className: "e-app-drop-zone__secondary-text"
  }, props.secondaryText), props.showButton && /*#__PURE__*/_react.default.createElement(_uploadFile.default, {
    isLoading: props.isLoading,
    type: props.type,
    onButtonClick: props.onButtonClick,
    onFileSelect: props.onFileSelect,
    onWpMediaSelect: function onWpMediaSelect(frame) {
      return props.onWpMediaSelect(frame);
    },
    onError: function onError(error) {
      return props.onError(error);
    },
    text: props.buttonText,
    filetypes: props.filetypes,
    variant: props.buttonVariant,
    color: props.buttonColor,
    onFileChoose: props.onFileChoose
  }), props.description && /*#__PURE__*/_react.default.createElement(_text.default, {
    variant: "xl",
    className: "e-app-drop-zone__description"
  }, props.description)));
}
DropZone.propTypes = {
  className: PropTypes.string,
  children: PropTypes.any,
  type: PropTypes.string,
  onFileSelect: PropTypes.func.isRequired,
  onWpMediaSelect: PropTypes.func,
  heading: PropTypes.string,
  text: PropTypes.string,
  secondaryText: PropTypes.string,
  buttonText: PropTypes.string,
  buttonVariant: PropTypes.string,
  buttonColor: PropTypes.string,
  icon: PropTypes.string,
  showButton: PropTypes.bool,
  showIcon: PropTypes.bool,
  isLoading: PropTypes.bool,
  filetypes: PropTypes.array.isRequired,
  onError: PropTypes.func,
  description: PropTypes.string,
  onButtonClick: PropTypes.func,
  onFileChoose: PropTypes.func
};
DropZone.defaultProps = {
  className: '',
  type: 'file-explorer',
  icon: 'eicon-library-upload',
  showButton: true,
  showIcon: true,
  onError: function onError() {}
};

/***/ }),

/***/ "../app/assets/js/organisms/error-boundary.js":
/*!****************************************************!*\
  !*** ../app/assets/js/organisms/error-boundary.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _classCallCheck2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "../node_modules/@babel/runtime/helpers/classCallCheck.js"));
var _createClass2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/createClass */ "../node_modules/@babel/runtime/helpers/createClass.js"));
var _inherits2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/inherits */ "../node_modules/@babel/runtime/helpers/inherits.js"));
var _possibleConstructorReturn2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/possibleConstructorReturn */ "../node_modules/@babel/runtime/helpers/possibleConstructorReturn.js"));
var _getPrototypeOf2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/getPrototypeOf */ "../node_modules/@babel/runtime/helpers/getPrototypeOf.js"));
var _defineProperty2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "../node_modules/@babel/runtime/helpers/defineProperty.js"));
var _dialog = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/dialog/dialog */ "../app/assets/js/ui/dialog/dialog.js"));
function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0, _getPrototypeOf2.default)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0, _getPrototypeOf2.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0, _possibleConstructorReturn2.default)(this, result); }; }
function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
// In the current time there is no solution to use "getDerivedStateFromError" static method with functional component
// That is why this component is a class component.
// @link https://reactjs.org/docs/hooks-faq.html#do-hooks-cover-all-use-cases-for-classes
var ErrorBoundary = /*#__PURE__*/function (_React$Component) {
  (0, _inherits2.default)(ErrorBoundary, _React$Component);
  var _super = _createSuper(ErrorBoundary);
  function ErrorBoundary(props) {
    var _this;
    (0, _classCallCheck2.default)(this, ErrorBoundary);
    _this = _super.call(this, props);
    _this.state = {
      hasError: null
    };
    return _this;
  }
  (0, _createClass2.default)(ErrorBoundary, [{
    key: "goBack",
    value: function goBack() {
      // If the app was opened inside an iframe, it will close it,
      // if not, it will redirect to the last location.
      if (window.top !== window.self) {
        window.top.$e.run('app/close');
      }
      window.location = elementorAppConfig.return_url;
    }
  }, {
    key: "render",
    value: function render() {
      if (this.state.hasError) {
        return /*#__PURE__*/_react.default.createElement(_dialog.default, {
          title: this.props.title,
          text: this.props.text,
          approveButtonUrl: this.props.learnMoreUrl,
          approveButtonColor: "link",
          approveButtonTarget: "_blank",
          approveButtonText: __('Learn More', 'elementor'),
          dismissButtonText: __('Go Back', 'elementor'),
          dismissButtonOnClick: this.goBack
        });
      }
      return this.props.children;
    }
  }], [{
    key: "getDerivedStateFromError",
    value: function getDerivedStateFromError() {
      return {
        hasError: true
      };
    }
  }]);
  return ErrorBoundary;
}(_react.default.Component);
exports["default"] = ErrorBoundary;
(0, _defineProperty2.default)(ErrorBoundary, "propTypes", {
  children: PropTypes.any,
  title: PropTypes.string,
  text: PropTypes.string,
  learnMoreUrl: PropTypes.string
});
(0, _defineProperty2.default)(ErrorBoundary, "defaultProps", {
  title: __('App could not be loaded', 'elementor'),
  text: __('We’re sorry, but something went wrong. Click on ‘Learn more’ and follow each of the steps to quickly solve it.', 'elementor'),
  learnMoreUrl: 'https://go.elementor.com/app-general-load-issue/'
});

/***/ }),

/***/ "../app/assets/js/organisms/unfiltered-files-dialog.js":
/*!*************************************************************!*\
  !*** ../app/assets/js/organisms/unfiltered-files-dialog.js ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = UnfilteredFilesDialog;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _slicedToArray2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "../node_modules/@babel/runtime/helpers/slicedToArray.js"));
var _dialog = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/dialog/dialog */ "../app/assets/js/ui/dialog/dialog.js"));
var _useAjax2 = _interopRequireDefault(__webpack_require__(/*! elementor-app/hooks/use-ajax */ "../app/assets/js/hooks/use-ajax.js"));
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function UnfilteredFilesDialog(props) {
  var show = props.show,
    setShow = props.setShow,
    onReady = props.onReady,
    onCancel = props.onCancel,
    onDismiss = props.onDismiss,
    onLoad = props.onLoad,
    onEnable = props.onEnable,
    onClose = props.onClose,
    _useAjax = (0, _useAjax2.default)(),
    ajaxState = _useAjax.ajaxState,
    setAjax = _useAjax.setAjax,
    _useState = (0, _react.useState)(false),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    enableUnfilteredFiles = _useState2[0],
    setEnableUnfilteredFiles = _useState2[1],
    _useState3 = (0, _react.useState)(false),
    _useState4 = (0, _slicedToArray2.default)(_useState3, 2),
    isEnableError = _useState4[0],
    setIsEnableError = _useState4[1];

  // Sending the enable unfiltered files request.
  (0, _react.useEffect)(function () {
    if (enableUnfilteredFiles) {
      setShow(false);
      setAjax({
        data: {
          action: 'elementor_ajax',
          actions: JSON.stringify({
            enable_unfiltered_files_upload: {
              action: 'enable_unfiltered_files_upload'
            }
          })
        }
      });
      if (onEnable) {
        onEnable();
      }
    }
  }, [enableUnfilteredFiles]);

  // Enabling unfiltered files ajax status.
  (0, _react.useEffect)(function () {
    switch (ajaxState.status) {
      case 'success':
        onReady();
        break;
      case 'error':
        setIsEnableError(true);
        setShow(true);
        break;
    }
  }, [ajaxState]);
  (0, _react.useEffect)(function () {
    if (show && onLoad) {
      onLoad();
    }
  }, [show]);
  if (!show) {
    return null;
  }
  return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, isEnableError ? /*#__PURE__*/_react.default.createElement(_dialog.default, {
    title: __('Something went wrong.', 'elementor'),
    text: props.errorModalText,
    approveButtonColor: "link",
    approveButtonText: __('Continue', 'elementor'),
    approveButtonOnClick: onReady,
    dismissButtonText: __('Go Back', 'elementor'),
    dismissButtonOnClick: onCancel,
    onClose: onCancel
  }) : /*#__PURE__*/_react.default.createElement(_dialog.default, {
    title: __('First, enable unfiltered file uploads.', 'elementor'),
    text: props.confirmModalText,
    approveButtonColor: "link",
    approveButtonText: __('Enable', 'elementor'),
    approveButtonOnClick: function approveButtonOnClick() {
      return setEnableUnfilteredFiles(true);
    },
    dismissButtonText: __('Skip', 'elementor'),
    dismissButtonOnClick: onDismiss || onReady,
    onClose: onClose || onDismiss || onReady
  }));
}
UnfilteredFilesDialog.propTypes = {
  show: PropTypes.bool,
  setShow: PropTypes.func.isRequired,
  onReady: PropTypes.func.isRequired,
  onCancel: PropTypes.func.isRequired,
  onDismiss: PropTypes.func,
  confirmModalText: PropTypes.string.isRequired,
  errorModalText: PropTypes.string.isRequired,
  onLoad: PropTypes.func,
  onEnable: PropTypes.func,
  onClose: PropTypes.func
};
UnfilteredFilesDialog.defaultProps = {
  show: false,
  onReady: function onReady() {},
  onCancel: function onCancel() {}
};

/***/ }),

/***/ "../app/assets/js/organisms/wizard-footer.js":
/*!***************************************************!*\
  !*** ../app/assets/js/organisms/wizard-footer.js ***!
  \***************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = WizardFooter;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _extends2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/extends */ "../node_modules/@babel/runtime/helpers/extends.js"));
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
var _grid = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/grid/grid */ "../app/assets/js/ui/grid/grid.js"));
__webpack_require__(/*! ./wizard-footer.scss */ "../app/assets/js/organisms/wizard-footer.scss");
function WizardFooter(props) {
  var baseClassName = 'e-app-wizard-footer',
    classes = [baseClassName, props.className];
  if (props.separator) {
    classes.push(baseClassName + '__separator');
  }
  return /*#__PURE__*/_react.default.createElement(_grid.default, (0, _extends2.default)({
    container: true
  }, props, {
    className: (0, _utils.arrayToClassName)(classes)
  }), props.children);
}
WizardFooter.propTypes = {
  className: PropTypes.string,
  justify: PropTypes.any,
  separator: PropTypes.any,
  children: PropTypes.oneOfType([PropTypes.string, PropTypes.object, PropTypes.arrayOf(PropTypes.object)]).isRequired
};
WizardFooter.defaultProps = {
  className: ''
};

/***/ }),

/***/ "../app/assets/js/pages/index.js":
/*!***************************************!*\
  !*** ../app/assets/js/pages/index.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = Index;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _router = __webpack_require__(/*! @reach/router */ "../node_modules/@reach/router/es/index.js");
var _actionsMap = _interopRequireDefault(__webpack_require__(/*! elementor-app/url-actions/actions-map */ "../app/assets/js/url-actions/actions-map.js"));
function Index() {
  var _elementorAppConfig$m;
  var urlSearchParams = new URLSearchParams(window.location.search),
    queryParams = Object.fromEntries(urlSearchParams.entries()),
    // The 'action' query param is translated into a route URL.
    url = _actionsMap.default[queryParams.action] || ((_elementorAppConfig$m = elementorAppConfig.menu_url.split('#')) === null || _elementorAppConfig$m === void 0 ? void 0 : _elementorAppConfig$m[1]);
  return /*#__PURE__*/_react.default.createElement(_router.Redirect, {
    to: url || '/not-found',
    noThrow: true
  });
}

/***/ }),

/***/ "../app/assets/js/pages/not-found.js":
/*!*******************************************!*\
  !*** ../app/assets/js/pages/not-found.js ***!
  \*******************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = NotFound;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _page = _interopRequireDefault(__webpack_require__(/*! elementor-app/layout/page */ "../app/assets/js/layout/page.js"));
function NotFound() {
  var config = {
    title: __('Not Found', 'elementor'),
    className: 'eps-app__not-found',
    content: /*#__PURE__*/_react.default.createElement("h1", null, " ", __('Not Found', 'elementor'), " "),
    sidebar: /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null)
  };
  return /*#__PURE__*/_react.default.createElement(_page.default, config);
}

/***/ }),

/***/ "../app/assets/js/ui/atoms/box.js":
/*!****************************************!*\
  !*** ../app/assets/js/ui/atoms/box.js ***!
  \****************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = Box;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
__webpack_require__(/*! ./box.scss */ "../app/assets/js/ui/atoms/box.scss");
function Box(props) {
  var baseClassName = 'eps-box',
    classes = [baseClassName, props.className],
    style = {};
  if (Object.prototype.hasOwnProperty.call(props, 'padding')) {
    style['--eps-box-padding'] = (0, _utils.pxToRem)(props.padding);
    classes.push(baseClassName + '--padding');
  }
  return /*#__PURE__*/_react.default.createElement("div", {
    style: style,
    className: (0, _utils.arrayToClassName)(classes)
  }, props.children);
}
Box.propTypes = {
  className: PropTypes.string,
  padding: PropTypes.string,
  children: PropTypes.oneOfType([PropTypes.string, PropTypes.object, PropTypes.arrayOf(PropTypes.object)]).isRequired
};
Box.defaultProps = {
  className: ''
};

/***/ }),

/***/ "../app/assets/js/ui/atoms/checkbox.js":
/*!*********************************************!*\
  !*** ../app/assets/js/ui/atoms/checkbox.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = Checkbox;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
__webpack_require__(/*! ./checkbox.scss */ "../app/assets/js/ui/atoms/checkbox.scss");
function Checkbox(_ref) {
  var className = _ref.className,
    checked = _ref.checked,
    rounded = _ref.rounded,
    indeterminate = _ref.indeterminate,
    error = _ref.error,
    disabled = _ref.disabled,
    onChange = _ref.onChange,
    id = _ref.id;
  var baseClassName = 'eps-checkbox',
    classes = [baseClassName, className];
  if (rounded) {
    classes.push(baseClassName + '--rounded');
  }
  if (indeterminate) {
    classes.push(baseClassName + '--indeterminate');
  }
  if (error) {
    classes.push(baseClassName + '--error');
  }
  return /*#__PURE__*/_react.default.createElement("input", {
    className: (0, _utils.arrayToClassName)(classes),
    type: "checkbox",
    checked: checked,
    disabled: disabled,
    onChange: onChange,
    id: id
  });
}
Checkbox.propTypes = {
  className: PropTypes.string,
  checked: PropTypes.bool,
  disabled: PropTypes.bool,
  indeterminate: PropTypes.bool,
  rounded: PropTypes.bool,
  error: PropTypes.bool,
  onChange: PropTypes.func,
  id: PropTypes.string
};
Checkbox.defaultProps = {
  className: '',
  checked: null,
  disabled: false,
  indeterminate: false,
  error: false,
  onChange: function onChange() {}
};

/***/ }),

/***/ "../app/assets/js/ui/atoms/drag-drop.js":
/*!**********************************************!*\
  !*** ../app/assets/js/ui/atoms/drag-drop.js ***!
  \**********************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = DragDrop;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _extends2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/extends */ "../node_modules/@babel/runtime/helpers/extends.js"));
var _slicedToArray2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "../node_modules/@babel/runtime/helpers/slicedToArray.js"));
var _utils = __webpack_require__(/*! ../../utils/utils */ "../app/assets/js/utils/utils.js");
__webpack_require__(/*! ./drag-drop.scss */ "../app/assets/js/ui/atoms/drag-drop.scss");
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function DragDrop(props) {
  var _useState = (0, _react.useState)(false),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    isDragOver = _useState2[0],
    setIsDragOver = _useState2[1],
    getClassName = function getClassName() {
      var baseClassName = 'e-app-drag-drop',
        classes = [baseClassName, props.className];
      if (isDragOver && !props.isLoading) {
        classes.push(baseClassName + '--drag-over');
      }
      return (0, _utils.arrayToClassName)(classes);
    },
    onDragDropActions = function onDragDropActions(event) {
      event.preventDefault();
      event.stopPropagation();
    },
    dragDropEvents = {
      onDrop: function onDrop(event) {
        onDragDropActions(event);
        setIsDragOver(false);
        if (props.onDrop) {
          props.onDrop(event);
        }
      },
      onDragOver: function onDragOver(event) {
        onDragDropActions(event);
        setIsDragOver(true);
        if (props.onDragOver) {
          props.onDragOver(event);
        }
      },
      onDragLeave: function onDragLeave(event) {
        onDragDropActions(event);
        setIsDragOver(false);
        if (props.onDragLeave) {
          props.onDragLeave(event);
        }
      }
    };
  return /*#__PURE__*/_react.default.createElement("div", (0, _extends2.default)({}, dragDropEvents, {
    className: getClassName()
  }), props.children);
}
DragDrop.propTypes = {
  className: PropTypes.string,
  children: PropTypes.any,
  onDrop: PropTypes.func,
  onDragLeave: PropTypes.func,
  onDragOver: PropTypes.func,
  isLoading: PropTypes.bool
};
DragDrop.defaultProps = {
  className: ''
};

/***/ }),

/***/ "../app/assets/js/ui/atoms/heading.js":
/*!********************************************!*\
  !*** ../app/assets/js/ui/atoms/heading.js ***!
  \********************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = Heading;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _utils = __webpack_require__(/*! ../../utils/utils */ "../app/assets/js/utils/utils.js");
function Heading(props) {
  var baseClassName = 'eps',
    classes = [props.className];
  if (props.variant) {
    classes.push(baseClassName + '-' + props.variant);
  }
  var Element = function Element() {
    return _react.default.createElement(props.tag, {
      className: (0, _utils.arrayToClassName)(classes)
    }, props.children);
  };
  return /*#__PURE__*/_react.default.createElement(Element, null);
}
Heading.propTypes = {
  className: PropTypes.string,
  children: PropTypes.oneOfType([PropTypes.string, PropTypes.object, PropTypes.arrayOf(PropTypes.object)]).isRequired,
  tag: PropTypes.oneOf(['h1', 'h2', 'h3', 'h4', 'h5', 'h6']),
  variant: PropTypes.oneOf(['display-1', 'display-2', 'display-3', 'display-4', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6']).isRequired
};
Heading.defaultProps = {
  className: '',
  tag: 'h1'
};

/***/ }),

/***/ "../app/assets/js/ui/atoms/icon.js":
/*!*****************************************!*\
  !*** ../app/assets/js/ui/atoms/icon.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = Icon;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
function Icon(props) {
  return /*#__PURE__*/_react.default.createElement("i", {
    className: "eps-icon ".concat(props.className)
  });
}
Icon.propTypes = {
  className: PropTypes.string.isRequired
};
Icon.defaultProps = {
  className: ''
};

/***/ }),

/***/ "../app/assets/js/ui/atoms/select.js":
/*!*******************************************!*\
  !*** ../app/assets/js/ui/atoms/select.js ***!
  \*******************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = Select;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
function Select(props) {
  return /*#__PURE__*/_react.default.createElement("select", {
    multiple: props.multiple,
    className: props.className,
    value: props.value,
    onChange: props.onChange,
    ref: props.elRef,
    onClick: function onClick() {
      var _props$onClick;
      return (_props$onClick = props.onClick) === null || _props$onClick === void 0 ? void 0 : _props$onClick.call(props);
    }
  }, props.options.map(function (option) {
    return option.children ? /*#__PURE__*/_react.default.createElement("optgroup", {
      label: option.label,
      key: option.label
    }, option.children.map(function (childOption) {
      return /*#__PURE__*/_react.default.createElement("option", {
        key: childOption.value,
        value: childOption.value
      }, childOption.label);
    })) : /*#__PURE__*/_react.default.createElement("option", {
      key: option.value,
      value: option.value
    }, option.label);
  }));
}
Select.propTypes = {
  className: PropTypes.string,
  onChange: PropTypes.func,
  options: PropTypes.array,
  elRef: PropTypes.object,
  multiple: PropTypes.bool,
  value: PropTypes.oneOfType([PropTypes.array, PropTypes.string]),
  onClick: PropTypes.func
};
Select.defaultProps = {
  className: '',
  options: []
};

/***/ }),

/***/ "../app/assets/js/ui/atoms/text-field.js":
/*!***********************************************!*\
  !*** ../app/assets/js/ui/atoms/text-field.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = TextField;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _extends2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/extends */ "../node_modules/@babel/runtime/helpers/extends.js"));
var _defineProperty2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "../node_modules/@babel/runtime/helpers/defineProperty.js"));
var _utils = __webpack_require__(/*! ../../utils/utils */ "../app/assets/js/utils/utils.js");
__webpack_require__(/*! ./text-field.scss */ "../app/assets/js/ui/atoms/text-field.scss");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { (0, _defineProperty2.default)(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function TextField(props) {
  var classNameBase = 'eps-text-field',
    classes = [classNameBase, props.className, (0, _defineProperty2.default)({}, classNameBase + '--outlined', 'outlined' === props.variant)],
    validProps = _objectSpread(_objectSpread({}, props), {}, {
      className: (0, _utils.arrayToClassName)(classes)
    });
  if (validProps.multiline) {
    delete validProps.multiline;
    return /*#__PURE__*/_react.default.createElement("textarea", validProps);
  }
  return /*#__PURE__*/_react.default.createElement("input", (0, _extends2.default)({}, validProps, {
    type: "text"
  }));
}
TextField.propTypes = {
  className: PropTypes.string,
  multiline: PropTypes.bool,
  variant: PropTypes.oneOf(['standard', 'outlined']),
  children: PropTypes.string
};
TextField.defaultProps = {
  className: '',
  variant: 'standard'
};

/***/ }),

/***/ "../app/assets/js/ui/atoms/text.js":
/*!*****************************************!*\
  !*** ../app/assets/js/ui/atoms/text.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = Text;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _utils = __webpack_require__(/*! ../../utils/utils */ "../app/assets/js/utils/utils.js");
function Text(props) {
  var baseClassName = 'eps',
    classes = [props.className],
    variant = props.variant && 'md' !== props.variant ? '-' + props.variant : '';
  classes.push(baseClassName + '-text' + variant);
  var Element = function Element() {
    return _react.default.createElement(props.tag, {
      className: (0, _utils.arrayToClassName)(classes)
    }, props.children);
  };
  return /*#__PURE__*/_react.default.createElement(Element, null);
}
Text.propTypes = {
  className: PropTypes.string,
  variant: PropTypes.oneOf(['xl', 'lg', 'md', 'sm', 'xs', 'xxs']),
  tag: PropTypes.string,
  children: PropTypes.any.isRequired
};
Text.defaultProps = {
  className: '',
  tag: 'p'
};

/***/ }),

/***/ "../app/assets/js/ui/card/card-body.js":
/*!*********************************************!*\
  !*** ../app/assets/js/ui/card/card-body.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = CardBody;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
__webpack_require__(/*! ./card.scss */ "../app/assets/js/ui/card/card.scss");
function CardBody(props) {
  var classNameBase = 'eps-card__body',
    classes = [classNameBase, props.className],
    style = {};
  if (Object.prototype.hasOwnProperty.call(props, 'padding')) {
    style['--eps-card-body-padding'] = (0, _utils.pxToRem)(props.padding);
    classes.push(classNameBase + '--padding');
  }
  return /*#__PURE__*/_react.default.createElement("main", {
    className: (0, _utils.arrayToClassName)(classes),
    style: style
  }, props.children);
}
CardBody.propTypes = {
  className: PropTypes.string,
  padding: PropTypes.string,
  passive: PropTypes.bool,
  active: PropTypes.bool,
  children: PropTypes.any.isRequired
};
CardBody.defaultProps = {
  className: ''
};

/***/ }),

/***/ "../app/assets/js/ui/card/card-divider.js":
/*!************************************************!*\
  !*** ../app/assets/js/ui/card/card-divider.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = CardDivider;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
__webpack_require__(/*! ./card.scss */ "../app/assets/js/ui/card/card.scss");
function CardDivider(props) {
  var classNameBase = 'eps-card__divider',
    classes = [classNameBase, props.className];
  return /*#__PURE__*/_react.default.createElement("hr", {
    className: (0, _utils.arrayToClassName)(classes)
  });
}
CardDivider.propTypes = {
  className: PropTypes.string
};
CardDivider.defaultProps = {
  className: ''
};

/***/ }),

/***/ "../app/assets/js/ui/card/card-footer.js":
/*!***********************************************!*\
  !*** ../app/assets/js/ui/card/card-footer.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = CardFooter;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
__webpack_require__(/*! ./card.scss */ "../app/assets/js/ui/card/card.scss");
function CardFooter(props) {
  var classNameBase = 'eps-card__footer',
    classes = [classNameBase, props.className],
    style = {};
  if (Object.prototype.hasOwnProperty.call(props, 'padding')) {
    style['--eps-card-footer-padding'] = (0, _utils.pxToRem)(props.padding);
    classes.push(classNameBase + '--padding');
  }
  return /*#__PURE__*/_react.default.createElement("footer", {
    className: (0, _utils.arrayToClassName)(classes),
    style: style
  }, props.children);
}
CardFooter.propTypes = {
  className: PropTypes.string,
  padding: PropTypes.string,
  passive: PropTypes.bool,
  active: PropTypes.bool,
  children: PropTypes.object.isRequired
};
CardFooter.defaultProps = {
  className: ''
};

/***/ }),

/***/ "../app/assets/js/ui/card/card-header.js":
/*!***********************************************!*\
  !*** ../app/assets/js/ui/card/card-header.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = CardHeader;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
__webpack_require__(/*! ./card.scss */ "../app/assets/js/ui/card/card.scss");
function CardHeader(props) {
  var classNameBase = 'eps-card__header',
    classes = [classNameBase, props.className],
    style = {};
  if (Object.prototype.hasOwnProperty.call(props, 'padding')) {
    style['--eps-card-header-padding'] = (0, _utils.pxToRem)(props.padding);
    classes.push(classNameBase + '--padding');
  }
  return /*#__PURE__*/_react.default.createElement("header", {
    className: (0, _utils.arrayToClassName)(classes),
    style: style
  }, props.children);
}
CardHeader.propTypes = {
  className: PropTypes.string,
  padding: PropTypes.string,
  passive: PropTypes.bool,
  active: PropTypes.bool,
  children: PropTypes.any.isRequired
};
CardHeader.defaultProps = {
  className: ''
};

/***/ }),

/***/ "../app/assets/js/ui/card/card-headline.js":
/*!*************************************************!*\
  !*** ../app/assets/js/ui/card/card-headline.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = CardHeadline;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
__webpack_require__(/*! ./card.scss */ "../app/assets/js/ui/card/card.scss");
function CardHeadline(props) {
  var classNameBase = 'eps-card__headline',
    classes = [classNameBase, props.className];
  return /*#__PURE__*/_react.default.createElement("h4", {
    className: (0, _utils.arrayToClassName)(classes)
  }, props.children);
}
CardHeadline.propTypes = {
  className: PropTypes.string,
  children: PropTypes.any.isRequired
};
CardHeadline.defaultProps = {
  className: ''
};

/***/ }),

/***/ "../app/assets/js/ui/card/card-image.js":
/*!**********************************************!*\
  !*** ../app/assets/js/ui/card/card-image.js ***!
  \**********************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = CardImage;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
__webpack_require__(/*! ./card.scss */ "../app/assets/js/ui/card/card.scss");
function CardImage(props) {
  var image = /*#__PURE__*/_react.default.createElement("img", {
    src: props.src,
    alt: props.alt,
    className: "eps-card__image",
    loading: "lazy"
  });
  return /*#__PURE__*/_react.default.createElement("figure", {
    className: "eps-card__figure ".concat(props.className)
  }, image, props.children);
}
CardImage.propTypes = {
  className: PropTypes.string,
  src: PropTypes.string.isRequired,
  alt: PropTypes.string.isRequired,
  children: PropTypes.any
};
CardImage.defaultProps = {
  className: ''
};

/***/ }),

/***/ "../app/assets/js/ui/card/card-overlay.js":
/*!************************************************!*\
  !*** ../app/assets/js/ui/card/card-overlay.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = CardOverlay;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
__webpack_require__(/*! ./card.scss */ "../app/assets/js/ui/card/card.scss");
function CardOverlay(props) {
  return /*#__PURE__*/_react.default.createElement("div", {
    className: "eps-card__image-overlay ".concat(props.className)
  }, props.children);
}
CardOverlay.propTypes = {
  className: PropTypes.string,
  children: PropTypes.object.isRequired
};
CardOverlay.defaultProps = {
  className: ''
};

/***/ }),

/***/ "../app/assets/js/ui/card/card.js":
/*!****************************************!*\
  !*** ../app/assets/js/ui/card/card.js ***!
  \****************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _cardHeader = _interopRequireDefault(__webpack_require__(/*! ./card-header */ "../app/assets/js/ui/card/card-header.js"));
var _cardBody = _interopRequireDefault(__webpack_require__(/*! ./card-body */ "../app/assets/js/ui/card/card-body.js"));
var _cardImage = _interopRequireDefault(__webpack_require__(/*! ./card-image */ "../app/assets/js/ui/card/card-image.js"));
var _cardOverlay = _interopRequireDefault(__webpack_require__(/*! ./card-overlay */ "../app/assets/js/ui/card/card-overlay.js"));
var _cardFooter = _interopRequireDefault(__webpack_require__(/*! ./card-footer */ "../app/assets/js/ui/card/card-footer.js"));
var _cardHeadline = _interopRequireDefault(__webpack_require__(/*! ./card-headline */ "../app/assets/js/ui/card/card-headline.js"));
var _cardDivider = _interopRequireDefault(__webpack_require__(/*! ./card-divider */ "../app/assets/js/ui/card/card-divider.js"));
__webpack_require__(/*! ./card.scss */ "../app/assets/js/ui/card/card.scss");
var Card = _react.default.forwardRef(function (props, ref) {
  return /*#__PURE__*/_react.default.createElement("article", {
    className: "eps-card ".concat(props.className),
    ref: ref
  }, props.children);
});
Card.propTypes = {
  type: PropTypes.string,
  className: PropTypes.string,
  children: PropTypes.any
};
Card.defaultProps = {
  className: ''
};
Card.displayName = 'Card';
Card.Header = _cardHeader.default;
Card.Body = _cardBody.default;
Card.Image = _cardImage.default;
Card.Overlay = _cardOverlay.default;
Card.Footer = _cardFooter.default;
Card.Headline = _cardHeadline.default;
Card.Divider = _cardDivider.default;
var _default = Card;
exports["default"] = _default;

/***/ }),

/***/ "../app/assets/js/ui/dialog/dialog-actions.js":
/*!****************************************************!*\
  !*** ../app/assets/js/ui/dialog/dialog-actions.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = DialogActions;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
function DialogActions(props) {
  return /*#__PURE__*/_react.default.createElement("div", {
    className: "eps-dialog__buttons"
  }, props.children);
}
DialogActions.propTypes = {
  children: PropTypes.any
};

/***/ }),

/***/ "../app/assets/js/ui/dialog/dialog-button.js":
/*!***************************************************!*\
  !*** ../app/assets/js/ui/dialog/dialog-button.js ***!
  \***************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = DialogButton;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _defineProperty2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "../node_modules/@babel/runtime/helpers/defineProperty.js"));
var _extends2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/extends */ "../node_modules/@babel/runtime/helpers/extends.js"));
var _button = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/button */ "../app/assets/js/ui/molecules/button.js"));
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { (0, _defineProperty2.default)(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function DialogButton(props) {
  return /*#__PURE__*/_react.default.createElement(_button.default, (0, _extends2.default)({}, props, {
    className: "eps-dialog__button ".concat(props.className)
  }));
}
DialogButton.propTypes = _objectSpread(_objectSpread({}, _button.default.propTypes), {}, {
  tabIndex: PropTypes.string,
  type: PropTypes.string
});
DialogButton.defaultProps = _objectSpread(_objectSpread({}, _button.default.defaultProps), {}, {
  tabIndex: '0',
  type: 'button'
});

/***/ }),

/***/ "../app/assets/js/ui/dialog/dialog-content.js":
/*!****************************************************!*\
  !*** ../app/assets/js/ui/dialog/dialog-content.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = DialogContent;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
function DialogContent(props) {
  return /*#__PURE__*/_react.default.createElement("div", {
    className: "eps-dialog__content"
  }, props.children);
}
DialogContent.propTypes = {
  children: PropTypes.any
};

/***/ }),

/***/ "../app/assets/js/ui/dialog/dialog-text.js":
/*!*************************************************!*\
  !*** ../app/assets/js/ui/dialog/dialog-text.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = DialogText;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _defineProperty2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "../node_modules/@babel/runtime/helpers/defineProperty.js"));
var _extends2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/extends */ "../node_modules/@babel/runtime/helpers/extends.js"));
var _text = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/text */ "../app/assets/js/ui/atoms/text.js"));
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { (0, _defineProperty2.default)(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function DialogText(props) {
  return /*#__PURE__*/_react.default.createElement(_text.default, (0, _extends2.default)({
    variant: "xs"
  }, props, {
    className: "eps-dialog__text ".concat(props.className)
  }));
}
DialogText.propTypes = _objectSpread({}, _text.default.propTypes);
DialogText.defaultProps = _objectSpread(_objectSpread({}, _text.default.defaultProps), {}, {
  tag: 'p',
  variant: 'sm'
});

/***/ }),

/***/ "../app/assets/js/ui/dialog/dialog-title.js":
/*!**************************************************!*\
  !*** ../app/assets/js/ui/dialog/dialog-title.js ***!
  \**************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = DialogTitle;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _defineProperty2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "../node_modules/@babel/runtime/helpers/defineProperty.js"));
var _extends2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/extends */ "../node_modules/@babel/runtime/helpers/extends.js"));
var _heading = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/heading */ "../app/assets/js/ui/atoms/heading.js"));
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { (0, _defineProperty2.default)(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function DialogTitle(props) {
  return /*#__PURE__*/_react.default.createElement(_heading.default, (0, _extends2.default)({}, props, {
    className: "eps-dialog__title ".concat(props.className)
  }));
}
DialogTitle.propTypes = _objectSpread(_objectSpread({}, _heading.default.propTypes), {}, {
  className: PropTypes.string
});
DialogTitle.defaultProps = _objectSpread(_objectSpread({}, _heading.default.propTypes), {}, {
  variant: 'h3',
  tag: 'h3',
  className: ''
});

/***/ }),

/***/ "../app/assets/js/ui/dialog/dialog-wrapper.js":
/*!****************************************************!*\
  !*** ../app/assets/js/ui/dialog/dialog-wrapper.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = DialogWrapper;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _button = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/button */ "../app/assets/js/ui/molecules/button.js"));
function DialogWrapper(props) {
  var WrapperTag = 'div';
  if (props.onSubmit) {
    WrapperTag = 'form';
  }
  return /*#__PURE__*/_react.default.createElement("section", {
    className: "eps-modal__overlay"
  }, /*#__PURE__*/_react.default.createElement(WrapperTag, {
    className: "eps-modal eps-dialog",
    onSubmit: props.onSubmit
  }, props.onClose && /*#__PURE__*/_react.default.createElement(_button.default, {
    onClick: props.onClose,
    text: __('Close', 'elementor'),
    hideText: true,
    icon: "eicon-close",
    className: "eps-dialog__close-button"
  }), props.children));
}
DialogWrapper.propTypes = {
  onClose: PropTypes.func,
  onSubmit: PropTypes.func,
  children: PropTypes.any
};

/***/ }),

/***/ "../app/assets/js/ui/dialog/dialog.js":
/*!********************************************!*\
  !*** ../app/assets/js/ui/dialog/dialog.js ***!
  \********************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = Dialog;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _dialogWrapper = _interopRequireDefault(__webpack_require__(/*! ./dialog-wrapper */ "../app/assets/js/ui/dialog/dialog-wrapper.js"));
var _dialogContent = _interopRequireDefault(__webpack_require__(/*! ./dialog-content */ "../app/assets/js/ui/dialog/dialog-content.js"));
var _dialogTitle = _interopRequireDefault(__webpack_require__(/*! ./dialog-title */ "../app/assets/js/ui/dialog/dialog-title.js"));
var _dialogText = _interopRequireDefault(__webpack_require__(/*! ./dialog-text */ "../app/assets/js/ui/dialog/dialog-text.js"));
var _dialogActions = _interopRequireDefault(__webpack_require__(/*! ./dialog-actions */ "../app/assets/js/ui/dialog/dialog-actions.js"));
var _dialogButton = _interopRequireDefault(__webpack_require__(/*! ./dialog-button */ "../app/assets/js/ui/dialog/dialog-button.js"));
__webpack_require__(/*! ./dialog.scss */ "../app/assets/js/ui/dialog/dialog.scss");
function Dialog(props) {
  return /*#__PURE__*/_react.default.createElement(_dialogWrapper.default, {
    onSubmit: props.onSubmit,
    onClose: props.onClose
  }, /*#__PURE__*/_react.default.createElement(_dialogContent.default, null, props.title && /*#__PURE__*/_react.default.createElement(_dialogTitle.default, null, props.title), props.text && /*#__PURE__*/_react.default.createElement(_dialogText.default, null, props.text), props.children), /*#__PURE__*/_react.default.createElement(_dialogActions.default, null, /*#__PURE__*/_react.default.createElement(_dialogButton.default, {
    key: "dismiss",
    text: props.dismissButtonText,
    onClick: props.dismissButtonOnClick,
    url: props.dismissButtonUrl,
    target: props.dismissButtonTarget
    // eslint-disable-next-line jsx-a11y/tabindex-no-positive
    ,
    tabIndex: "2"
  }), /*#__PURE__*/_react.default.createElement(_dialogButton.default, {
    key: "approve",
    text: props.approveButtonText,
    onClick: props.approveButtonOnClick,
    url: props.approveButtonUrl,
    target: props.approveButtonTarget,
    color: props.approveButtonColor,
    elRef: props.approveButtonRef
    // eslint-disable-next-line jsx-a11y/tabindex-no-positive
    ,
    tabIndex: "1"
  })));
}
Dialog.propTypes = {
  title: PropTypes.any,
  text: PropTypes.any,
  children: PropTypes.any,
  onSubmit: PropTypes.func,
  onClose: PropTypes.func,
  dismissButtonText: PropTypes.string.isRequired,
  dismissButtonOnClick: PropTypes.func,
  dismissButtonUrl: PropTypes.string,
  dismissButtonTarget: PropTypes.string,
  approveButtonText: PropTypes.string.isRequired,
  approveButtonOnClick: PropTypes.func,
  approveButtonUrl: PropTypes.string,
  approveButtonColor: PropTypes.string,
  approveButtonTarget: PropTypes.string,
  approveButtonRef: PropTypes.object
};
Dialog.defaultProps = {};
Dialog.Wrapper = _dialogWrapper.default;
Dialog.Content = _dialogContent.default;
Dialog.Title = _dialogTitle.default;
Dialog.Text = _dialogText.default;
Dialog.Actions = _dialogActions.default;
Dialog.Button = _dialogButton.default;

/***/ }),

/***/ "../app/assets/js/ui/grid/grid.js":
/*!****************************************!*\
  !*** ../app/assets/js/ui/grid/grid.js ***!
  \****************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = Grid;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _toConsumableArray2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/toConsumableArray */ "../node_modules/@babel/runtime/helpers/toConsumableArray.js"));
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
__webpack_require__(/*! ./grid.scss */ "../app/assets/js/ui/grid/grid.scss");
function Grid(props) {
  var propsMap = {
      direction: '--direction{{ -VALUE }}',
      justify: '--justify{{ -VALUE }}',
      alignContent: '--align-content{{ -VALUE }}',
      alignItems: '--align-items{{ -VALUE }}',
      container: '-container',
      item: '-item',
      noWrap: '-container--no-wrap',
      wrapReverse: '-container--wrap-reverse',
      zeroMinWidth: '-item--zero-min-width',
      spacing: '-container--spacing',
      xs: '-item-xs{{ -VALUE }}',
      sm: '-item-sm{{ -VALUE }}',
      md: '-item-md{{ -VALUE }}',
      lg: '-item-lg{{ -VALUE }}',
      xl: '-item-xl{{ -VALUE }}',
      xxl: '-item-xxl{{ -VALUE }}'
    },
    getStyle = function getStyle() {
      return isValidPropValue(props.spacing) ? {
        '--grid-spacing-gutter': (0, _utils.pxToRem)(props.spacing)
      } : {};
    },
    classes = [getBaseClassName(), props.className].concat((0, _toConsumableArray2.default)(getPropsClasses(propsMap, props)));
  return /*#__PURE__*/_react.default.createElement("div", {
    style: getStyle(),
    className: (0, _utils.arrayToClassName)(classes)
  }, props.children);
}
function getPropsClasses(propsMap, props) {
  var classes = [];
  for (var prop in propsMap) {
    if (props[prop]) {
      var propValue = isValidPropValue(props[prop]) ? props[prop] : '';
      classes.push(getBaseClassName() + renderPropValueBrackets(propsMap[prop], propValue));
    }
  }
  return classes;
}
function renderPropValueBrackets(propClass, propValue) {
  var brackets = propClass.match(/{{.*?}}/);
  if (brackets) {
    var bracketsValue = propValue ? brackets[0].replace(/[{ }]/g, '').replace(/value/i, propValue) : '';
    propClass = propClass.replace(brackets[0], bracketsValue);
  }
  return propClass;
}
function getBaseClassName() {
  return 'eps-grid';
}
function isValidPropValue(propValue) {
  return propValue && 'boolean' !== typeof propValue;
}
Grid.propTypes = {
  className: PropTypes.string,
  direction: PropTypes.oneOf(['row', 'column', 'row-reverse', 'column-reverse']),
  justify: PropTypes.oneOf(['start', 'center', 'end', 'space-between', 'space-evenly', 'space-around', 'stretch']),
  alignContent: PropTypes.oneOf(['start', 'center', 'end', 'space-between', 'stretch']),
  alignItems: PropTypes.oneOf(['start', 'center', 'end', 'baseline', 'stretch']),
  container: PropTypes.bool,
  item: PropTypes.bool,
  noWrap: PropTypes.bool,
  wrapReverse: PropTypes.bool,
  zeroMinWidth: PropTypes.bool,
  spacing: PropTypes.number,
  xs: PropTypes.oneOfType([PropTypes.number, PropTypes.bool]),
  sm: PropTypes.oneOfType([PropTypes.number, PropTypes.bool]),
  md: PropTypes.oneOfType([PropTypes.number, PropTypes.bool]),
  lg: PropTypes.oneOfType([PropTypes.number, PropTypes.bool]),
  xl: PropTypes.oneOfType([PropTypes.number, PropTypes.bool]),
  xxl: PropTypes.oneOfType([PropTypes.number, PropTypes.bool]),
  children: PropTypes.any.isRequired
};
Grid.defaultProps = {
  className: ''
};

/***/ }),

/***/ "../app/assets/js/ui/modal/modal-section.js":
/*!**************************************************!*\
  !*** ../app/assets/js/ui/modal/modal-section.js ***!
  \**************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = ModalSection;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _utils = __webpack_require__(/*! ../../utils/utils */ "../app/assets/js/utils/utils.js");
function ModalSection(props) {
  return /*#__PURE__*/_react.default.createElement("section", {
    className: (0, _utils.arrayToClassName)(['eps-modal__section', props.className])
  }, props.children);
}
ModalSection.propTypes = {
  className: PropTypes.string,
  children: PropTypes.any
};
ModalSection.defaultProps = {
  className: ''
};

/***/ }),

/***/ "../app/assets/js/ui/modal/modal-tip.js":
/*!**********************************************!*\
  !*** ../app/assets/js/ui/modal/modal-tip.js ***!
  \**********************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = ModalTip;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _utils = __webpack_require__(/*! ../../utils/utils */ "../app/assets/js/utils/utils.js");
var _heading = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/heading */ "../app/assets/js/ui/atoms/heading.js"));
var _text = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/text */ "../app/assets/js/ui/atoms/text.js"));
function ModalTip(props) {
  return /*#__PURE__*/_react.default.createElement("div", {
    className: (0, _utils.arrayToClassName)(['eps-modal__tip', props.className])
  }, /*#__PURE__*/_react.default.createElement(_heading.default, {
    variant: "h3",
    tag: "h3"
  }, props.title), props.description && /*#__PURE__*/_react.default.createElement(_text.default, {
    variant: "xs"
  }, props.description));
}
ModalTip.propTypes = {
  className: PropTypes.string,
  title: PropTypes.string,
  description: PropTypes.string
};
ModalTip.defaultProps = {
  className: '',
  title: __('Tip', 'elementor')
};

/***/ }),

/***/ "../app/assets/js/ui/modal/modal.js":
/*!******************************************!*\
  !*** ../app/assets/js/ui/modal/modal.js ***!
  \******************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.Modal = void 0;
exports["default"] = ModalProvider;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _extends2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/extends */ "../node_modules/@babel/runtime/helpers/extends.js"));
var _defineProperty2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "../node_modules/@babel/runtime/helpers/defineProperty.js"));
var _slicedToArray2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "../node_modules/@babel/runtime/helpers/slicedToArray.js"));
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
var _button = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/button */ "../app/assets/js/ui/molecules/button.js"));
var _grid = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/grid/grid */ "../app/assets/js/ui/grid/grid.js"));
var _icon = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/icon */ "../app/assets/js/ui/atoms/icon.js"));
var _text = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/text */ "../app/assets/js/ui/atoms/text.js"));
var _modalSection = _interopRequireDefault(__webpack_require__(/*! ./modal-section */ "../app/assets/js/ui/modal/modal-section.js"));
var _modalTip = _interopRequireDefault(__webpack_require__(/*! ./modal-tip */ "../app/assets/js/ui/modal/modal-tip.js"));
__webpack_require__(/*! ./modal.scss */ "../app/assets/js/ui/modal/modal.scss");
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { (0, _defineProperty2.default)(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function ModalProvider(props) {
  var _useState = (0, _react.useState)(props.show),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    show = _useState2[0],
    setShow = _useState2[1],
    hideModal = function hideModal() {
      setShow(false);

      // The purpose of the props.setShow is to sync an external state with the component inner state.
      if (props.setShow) {
        props.setShow(false);
      }
    },
    showModal = function showModal() {
      setShow(true);

      // The purpose of the props.setShow is to sync an external state with the component inner state.
      if (props.setShow) {
        props.setShow(true);
      }
    },
    modalAttrs = _objectSpread(_objectSpread({}, props), {}, {
      show: show,
      hideModal: hideModal,
      showModal: showModal
    });
  (0, _react.useEffect)(function () {
    // Sync with external state.
    setShow(props.show);
  }, [props.show]);
  return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, props.toggleButtonProps && /*#__PURE__*/_react.default.createElement(_button.default, (0, _extends2.default)({}, props.toggleButtonProps, {
    onClick: showModal
  })), /*#__PURE__*/_react.default.createElement(Modal, modalAttrs, props.children));
}
ModalProvider.propTypes = {
  children: PropTypes.node.isRequired,
  toggleButtonProps: PropTypes.object,
  title: PropTypes.string,
  icon: PropTypes.string,
  show: PropTypes.bool,
  setShow: PropTypes.func,
  onOpen: PropTypes.func,
  onClose: PropTypes.func
};
ModalProvider.defaultProps = {
  show: false
};
ModalProvider.Section = _modalSection.default;
ModalProvider.Tip = _modalTip.default;
var Modal = function Modal(props) {
  var modalRef = (0, _react.useRef)(null),
    closeRef = (0, _react.useRef)(null),
    closeModal = function closeModal(e) {
      var node = modalRef.current,
        closeNode = closeRef.current,
        isInCloseNode = closeNode && closeNode.contains(e.target);

      // Ignore if click is inside the modal
      if (node && node.contains(e.target) && !isInCloseNode) {
        return;
      }
      props.hideModal();
      if (props.onClose) {
        props.onClose(e);
      }
    };
  (0, _react.useEffect)(function () {
    if (props.show) {
      var _props$onOpen;
      document.addEventListener('mousedown', closeModal, false);
      (_props$onOpen = props.onOpen) === null || _props$onOpen === void 0 ? void 0 : _props$onOpen.call(props);
    }
    return function () {
      return document.removeEventListener('mousedown', closeModal, false);
    };
  }, [props.show]);
  if (!props.show) {
    return null;
  }
  return (
    /*#__PURE__*/
    // eslint-disable-next-line jsx-a11y/click-events-have-key-events, jsx-a11y/no-static-element-interactions
    _react.default.createElement("div", {
      className: "eps-modal__overlay",
      onClick: closeModal
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: (0, _utils.arrayToClassName)(['eps-modal', props.className]),
      ref: modalRef
    }, /*#__PURE__*/_react.default.createElement(_grid.default, {
      container: true,
      className: "eps-modal__header",
      justify: "space-between",
      alignItems: "center"
    }, /*#__PURE__*/_react.default.createElement(_grid.default, {
      item: true
    }, /*#__PURE__*/_react.default.createElement(_icon.default, {
      className: "eps-modal__icon ".concat(props.icon)
    }), /*#__PURE__*/_react.default.createElement(_text.default, {
      className: "title",
      tag: "span"
    }, props.title)), /*#__PURE__*/_react.default.createElement(_grid.default, {
      item: true
    }, /*#__PURE__*/_react.default.createElement("div", {
      className: "eps-modal__close-wrapper",
      ref: closeRef
    }, /*#__PURE__*/_react.default.createElement(_button.default, {
      text: __('Close', 'elementor'),
      hideText: true,
      icon: "eicon-close",
      onClick: props.closeModal
    })))), /*#__PURE__*/_react.default.createElement("div", {
      className: "eps-modal__body"
    }, props.children)))
  );
};
exports.Modal = Modal;
Modal.propTypes = {
  className: PropTypes.string,
  children: PropTypes.any.isRequired,
  title: PropTypes.string.isRequired,
  icon: PropTypes.string,
  show: PropTypes.bool,
  setShow: PropTypes.func,
  hideModal: PropTypes.func,
  showModal: PropTypes.func,
  closeModal: PropTypes.func,
  onOpen: PropTypes.func,
  onClose: PropTypes.func
};
Modal.defaultProps = {
  className: ''
};

/***/ }),

/***/ "../app/assets/js/ui/molecules/button.js":
/*!***********************************************!*\
  !*** ../app/assets/js/ui/molecules/button.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _extends2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/extends */ "../node_modules/@babel/runtime/helpers/extends.js"));
var _classCallCheck2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "../node_modules/@babel/runtime/helpers/classCallCheck.js"));
var _createClass2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/createClass */ "../node_modules/@babel/runtime/helpers/createClass.js"));
var _inherits2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/inherits */ "../node_modules/@babel/runtime/helpers/inherits.js"));
var _possibleConstructorReturn2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/possibleConstructorReturn */ "../node_modules/@babel/runtime/helpers/possibleConstructorReturn.js"));
var _getPrototypeOf2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/getPrototypeOf */ "../node_modules/@babel/runtime/helpers/getPrototypeOf.js"));
var _defineProperty2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "../node_modules/@babel/runtime/helpers/defineProperty.js"));
var _router = __webpack_require__(/*! @reach/router */ "../node_modules/@reach/router/es/index.js");
var _router2 = _interopRequireDefault(__webpack_require__(/*! @elementor/router */ "@elementor/router"));
var _icon = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/icon */ "../app/assets/js/ui/atoms/icon.js"));
function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0, _getPrototypeOf2.default)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0, _getPrototypeOf2.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0, _possibleConstructorReturn2.default)(this, result); }; }
function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var Button = /*#__PURE__*/function (_React$Component) {
  (0, _inherits2.default)(Button, _React$Component);
  var _super = _createSuper(Button);
  function Button() {
    (0, _classCallCheck2.default)(this, Button);
    return _super.apply(this, arguments);
  }
  (0, _createClass2.default)(Button, [{
    key: "getCssId",
    value: function getCssId() {
      return this.props.id;
    }
  }, {
    key: "getClassName",
    value: function getClassName() {
      var baseClassName = 'eps-button',
        classes = [baseClassName, this.props.className];
      return classes.concat(this.getStylePropsClasses(baseClassName)).filter(function (classItem) {
        return '' !== classItem;
      }).join(' ');
    }
  }, {
    key: "getStylePropsClasses",
    value: function getStylePropsClasses(baseClassName) {
      var _this = this;
      var styleProps = ['color', 'size', 'variant'],
        stylePropClasses = [];
      styleProps.forEach(function (styleProp) {
        var stylePropValue = _this.props[styleProp];
        if (stylePropValue) {
          stylePropClasses.push(baseClassName + '--' + stylePropValue);
        }
      });
      return stylePropClasses;
    }
  }, {
    key: "getIcon",
    value: function getIcon() {
      if (this.props.icon) {
        var tooltip = this.props.tooltip || this.props.text;
        var icon = /*#__PURE__*/_react.default.createElement(_icon.default, {
          className: this.props.icon,
          "aria-hidden": "true",
          title: tooltip
        });
        var screenReaderText = '';
        if (this.props.hideText) {
          screenReaderText = /*#__PURE__*/_react.default.createElement("span", {
            className: "sr-only"
          }, tooltip);
        }
        return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, icon, screenReaderText);
      }
      return '';
    }
  }, {
    key: "getText",
    value: function getText() {
      return this.props.hideText ? '' : /*#__PURE__*/_react.default.createElement("span", null, this.props.text);
    }
  }, {
    key: "render",
    value: function render() {
      var attributes = {},
        id = this.getCssId(),
        className = this.getClassName();

      // Add attributes only if they are not empty.
      if (id) {
        attributes.id = id;
      }
      if (className) {
        attributes.className = className;
      }
      if (this.props.onClick) {
        attributes.onClick = this.props.onClick;
      }
      if (this.props.rel) {
        attributes.rel = this.props.rel;
      }
      if (this.props.elRef) {
        attributes.ref = this.props.elRef;
      }
      var buttonContent = /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, this.getIcon(), this.getText());
      if (this.props.url) {
        if (0 === this.props.url.indexOf('http')) {
          return /*#__PURE__*/_react.default.createElement("a", (0, _extends2.default)({
            href: this.props.url,
            target: this.props.target
          }, attributes), buttonContent);
        }

        // @see https://reach.tech/router/example/active-links.
        attributes.getProps = function (props) {
          if (props.isCurrent) {
            attributes.className += ' active';
          }
          return {
            className: attributes.className
          };
        };
        return /*#__PURE__*/_react.default.createElement(_router.LocationProvider, {
          history: _router2.default.appHistory
        }, /*#__PURE__*/_react.default.createElement(_router.Link, (0, _extends2.default)({
          to: this.props.url
        }, attributes), buttonContent));
      }
      return /*#__PURE__*/_react.default.createElement("div", attributes, buttonContent);
    }
  }]);
  return Button;
}(_react.default.Component);
exports["default"] = Button;
(0, _defineProperty2.default)(Button, "propTypes", {
  text: PropTypes.string.isRequired,
  hideText: PropTypes.bool,
  icon: PropTypes.string,
  tooltip: PropTypes.string,
  id: PropTypes.string,
  className: PropTypes.string,
  url: PropTypes.string,
  onClick: PropTypes.func,
  variant: PropTypes.oneOf(['contained', 'underlined', 'outlined', '']),
  color: PropTypes.oneOf(['primary', 'secondary', 'cta', 'link', 'disabled']),
  size: PropTypes.oneOf(['sm', 'md', 'lg']),
  target: PropTypes.string,
  rel: PropTypes.string,
  elRef: PropTypes.object
});
(0, _defineProperty2.default)(Button, "defaultProps", {
  id: '',
  className: '',
  variant: '',
  target: '_parent'
});

/***/ }),

/***/ "../app/assets/js/ui/molecules/inline-link.js":
/*!****************************************************!*\
  !*** ../app/assets/js/ui/molecules/inline-link.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = InlineLink;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _router = __webpack_require__(/*! @reach/router */ "../node_modules/@reach/router/es/index.js");
var _router2 = _interopRequireDefault(__webpack_require__(/*! @elementor/router */ "@elementor/router"));
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
__webpack_require__(/*! ./inline-link.scss */ "../app/assets/js/ui/molecules/inline-link.scss");
function InlineLink(props) {
  var baseClassName = 'eps-inline-link',
    colorClassName = "".concat(baseClassName, "--color-").concat(props.color),
    underlineClassName = 'none' !== props.underline ? "".concat(baseClassName, "--underline-").concat(props.underline) : '',
    italicClassName = props.italic ? "".concat(baseClassName, "--italic") : '',
    classes = [baseClassName, colorClassName, underlineClassName, italicClassName, props.className],
    className = (0, _utils.arrayToClassName)(classes),
    getRouterLink = function getRouterLink() {
      return /*#__PURE__*/_react.default.createElement(_router.LocationProvider, {
        history: _router2.default.appHistory
      }, /*#__PURE__*/_react.default.createElement(_router.Link, {
        to: props.url,
        className: className
      }, props.children));
    },
    getExternalLink = function getExternalLink() {
      return /*#__PURE__*/_react.default.createElement("a", {
        href: props.url,
        target: props.target,
        rel: props.rel,
        className: className,
        onClick: props.onClick
      }, props.children);
    },
    getActionLink = function getActionLink() {
      return /*#__PURE__*/_react.default.createElement("button", {
        className: className,
        onClick: props.onClick
      }, props.children);
    };
  if (!props.url) {
    return getActionLink();
  }
  return props.url.includes('http') ? getExternalLink() : getRouterLink();
}
InlineLink.propTypes = {
  className: PropTypes.string,
  children: PropTypes.any,
  url: PropTypes.string,
  target: PropTypes.string,
  rel: PropTypes.string,
  text: PropTypes.string,
  color: PropTypes.oneOf(['primary', 'secondary', 'cta', 'link', 'disabled']),
  underline: PropTypes.oneOf(['none', 'hover', 'always']),
  italic: PropTypes.bool,
  onClick: PropTypes.func
};
InlineLink.defaultProps = {
  className: '',
  color: 'link',
  underline: 'always',
  target: '_blank',
  rel: 'noopener noreferrer'
};

/***/ }),

/***/ "../app/assets/js/ui/molecules/list-item.js":
/*!**************************************************!*\
  !*** ../app/assets/js/ui/molecules/list-item.js ***!
  \**************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = ListItem;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
function ListItem(props) {
  var baseClassName = 'eps-list__item',
    classes = [baseClassName, props.className];
  var style;
  if (Object.prototype.hasOwnProperty.call(props, 'padding')) {
    style = {
      '--eps-list-item-padding': (0, _utils.pxToRem)(props.padding)
    };
    classes.push(baseClassName + '--padding');
  }
  return /*#__PURE__*/_react.default.createElement("li", {
    style: style,
    className: (0, _utils.arrayToClassName)(classes)
  }, props.children);
}
ListItem.propTypes = {
  className: PropTypes.string,
  padding: PropTypes.string,
  children: PropTypes.any.isRequired
};
ListItem.defaultProps = {
  className: ''
};

/***/ }),

/***/ "../app/assets/js/ui/molecules/list.js":
/*!*********************************************!*\
  !*** ../app/assets/js/ui/molecules/list.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = List;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
var _listItem = _interopRequireDefault(__webpack_require__(/*! ./list-item */ "../app/assets/js/ui/molecules/list-item.js"));
__webpack_require__(/*! ./list.scss */ "../app/assets/js/ui/molecules/list.scss");
function List(props) {
  var baseClassName = 'eps-list',
    classes = [baseClassName, props.className];
  var style;
  if (Object.prototype.hasOwnProperty.call(props, 'padding')) {
    style = {
      '--eps-list-padding': (0, _utils.pxToRem)(props.padding)
    };
    classes.push(baseClassName + '--padding');
  }
  if (props.separated) {
    classes.push(baseClassName + '--separated');
  }
  return /*#__PURE__*/_react.default.createElement("ul", {
    style: style,
    className: (0, _utils.arrayToClassName)(classes)
  }, props.children);
}
List.propTypes = {
  className: PropTypes.string,
  divided: PropTypes.any,
  separated: PropTypes.any,
  padding: PropTypes.string,
  children: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]).isRequired
};
List.defaultProps = {
  className: ''
};
List.Item = _listItem.default;

/***/ }),

/***/ "../app/assets/js/ui/molecules/notice.js":
/*!***********************************************!*\
  !*** ../app/assets/js/ui/molecules/notice.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = Notice;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
var _text = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/text */ "../app/assets/js/ui/atoms/text.js"));
var _icon = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/icon */ "../app/assets/js/ui/atoms/icon.js"));
var _grid = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/grid/grid */ "../app/assets/js/ui/grid/grid.js"));
__webpack_require__(/*! ./notice.scss */ "../app/assets/js/ui/molecules/notice.scss");
var iconsClassesMap = {
  danger: 'eicon-warning',
  info: 'eicon-info-circle-o',
  warning: 'eicon-warning'
};
function Notice(props) {
  var baseClassName = 'eps-notice',
    classes = [baseClassName, props.className];
  if (props.color) {
    classes.push(baseClassName + '-semantic', baseClassName + '--' + props.color);
  }
  return /*#__PURE__*/_react.default.createElement(_grid.default, {
    className: (0, _utils.arrayToClassName)(classes),
    container: true,
    noWrap: true,
    alignItems: "center",
    justify: "space-between"
  }, /*#__PURE__*/_react.default.createElement(_grid.default, {
    item: true,
    container: true,
    alignItems: "start",
    noWrap: true
  }, props.withIcon && props.color && /*#__PURE__*/_react.default.createElement(_icon.default, {
    className: (0, _utils.arrayToClassName)(['eps-notice__icon', iconsClassesMap[props.color]])
  }), /*#__PURE__*/_react.default.createElement(_text.default, {
    variant: "xs",
    className: "eps-notice__text"
  }, props.label && /*#__PURE__*/_react.default.createElement("strong", null, props.label + ' '), props.children)), props.button && /*#__PURE__*/_react.default.createElement(_grid.default, {
    item: true,
    container: true,
    justify: "end",
    className: baseClassName + '__button-container'
  }, props.button));
}
Notice.propTypes = {
  className: PropTypes.string,
  color: PropTypes.string,
  label: PropTypes.string,
  children: PropTypes.any.isRequired,
  icon: PropTypes.string,
  withIcon: PropTypes.bool,
  button: PropTypes.object
};
Notice.defaultProps = {
  className: '',
  withIcon: true,
  button: null
};

/***/ }),

/***/ "../app/assets/js/ui/molecules/select2.js":
/*!************************************************!*\
  !*** ../app/assets/js/ui/molecules/select2.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = Select2;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _defineProperty2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "../node_modules/@babel/runtime/helpers/defineProperty.js"));
var _select = _interopRequireDefault(__webpack_require__(/*! ../atoms/select */ "../app/assets/js/ui/atoms/select.js"));
__webpack_require__(/*! ./select2.scss */ "../app/assets/js/ui/molecules/select2.scss");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { (0, _defineProperty2.default)(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
/**
 * Default settings of the select 2
 *
 * @return {{placeholder: string, allowClear: boolean, dir: string}}
 */

var getDefaultSettings = function getDefaultSettings() {
  return {
    allowClear: true,
    placeholder: '',
    dir: elementorCommon.config.isRTL ? 'rtl' : 'ltr'
  };
};
/**
 * Main component
 *
 * @param {*} props
 * @return {*} component
 * @function Object() { [native code] }
 */
function Select2(props) {
  var ref = _react.default.useRef(null);

  // Initiate the select 2 library, call to onReady after initiate, and
  // listen to select event on the select instance.
  _react.default.useEffect(function () {
    var $select2 = jQuery(ref.current).select2(_objectSpread(_objectSpread(_objectSpread({}, getDefaultSettings()), props.settings), {}, {
      placeholder: props.placeholder
    })).on('select2:select select2:unselect', props.onChange);
    if (props.onReady) {
      props.onReady($select2);
    }
    return function () {
      $select2.select2('destroy').off('select2:select select2:unselect');
    };
  }, [props.settings, props.options]);

  // Listen to changes in the prop `value`, if changed update the select 2.
  _react.default.useEffect(function () {
    jQuery(ref.current).val(props.value).trigger('change');
  }, [props.value]);
  return /*#__PURE__*/_react.default.createElement(_select.default, {
    multiple: props.multiple,
    value: props.value,
    onChange: props.onChange,
    elRef: ref,
    options: props.options,
    placeholder: props.placeholder
  });
}
Select2.propTypes = {
  value: PropTypes.oneOfType([PropTypes.array, PropTypes.string]),
  onChange: PropTypes.func,
  onReady: PropTypes.func,
  options: PropTypes.array,
  settings: PropTypes.object,
  multiple: PropTypes.bool,
  placeholder: PropTypes.string
};
Select2.defaultProps = {
  settings: {},
  options: [],
  dependencies: [],
  placeholder: ''
};

/***/ }),

/***/ "../app/assets/js/ui/panel/panel-body.js":
/*!***********************************************!*\
  !*** ../app/assets/js/ui/panel/panel-body.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = PanelBody;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
var _card = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/card/card */ "../app/assets/js/ui/card/card.js"));
var _collapse = _interopRequireDefault(__webpack_require__(/*! elementor-app/molecules/collapse */ "../app/assets/js/molecules/collapse.js"));
function PanelBody(props) {
  return /*#__PURE__*/_react.default.createElement(_collapse.default.Content, null, /*#__PURE__*/_react.default.createElement(_card.default.Body, {
    padding: props.padding,
    className: (0, _utils.arrayToClassName)(['eps-panel__body', props.className])
  }, props.children));
}
PanelBody.propTypes = {
  className: PropTypes.string,
  padding: PropTypes.string,
  children: PropTypes.any.isRequired
};
PanelBody.defaultProps = {
  className: '',
  padding: '0'
};

/***/ }),

/***/ "../app/assets/js/ui/panel/panel-header.js":
/*!*************************************************!*\
  !*** ../app/assets/js/ui/panel/panel-header.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = PanelHeader;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
var _card = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/card/card */ "../app/assets/js/ui/card/card.js"));
var _collapse = _interopRequireDefault(__webpack_require__(/*! elementor-app/molecules/collapse */ "../app/assets/js/molecules/collapse.js"));
function PanelHeader(props) {
  return /*#__PURE__*/_react.default.createElement(_collapse.default.Toggle, {
    active: props.toggle,
    showIcon: props.showIcon
  }, /*#__PURE__*/_react.default.createElement(_card.default.Header, {
    padding: "20",
    className: (0, _utils.arrayToClassName)(['eps-panel__header', props.className])
  }, props.children));
}
PanelHeader.propTypes = {
  className: PropTypes.string,
  padding: PropTypes.string,
  toggle: PropTypes.bool,
  showIcon: PropTypes.bool,
  children: PropTypes.any.isRequired
};
PanelHeader.defaultProps = {
  className: '',
  padding: '20',
  toggle: true,
  showIcon: true
};

/***/ }),

/***/ "../app/assets/js/ui/panel/panel-headline.js":
/*!***************************************************!*\
  !*** ../app/assets/js/ui/panel/panel-headline.js ***!
  \***************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = PanelHeadline;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
var _card = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/card/card */ "../app/assets/js/ui/card/card.js"));
function PanelHeadline(props) {
  return /*#__PURE__*/_react.default.createElement(_card.default.Headline, {
    className: (0, _utils.arrayToClassName)(['eps-panel__headline', props.className])
  }, props.children);
}
PanelHeadline.propTypes = {
  className: PropTypes.string,
  children: PropTypes.any.isRequired
};
PanelHeadline.defaultProps = {
  className: ''
};

/***/ }),

/***/ "../app/assets/js/ui/panel/panel.js":
/*!******************************************!*\
  !*** ../app/assets/js/ui/panel/panel.js ***!
  \******************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = Panel;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
var _card = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/card/card */ "../app/assets/js/ui/card/card.js"));
var _collapse = _interopRequireDefault(__webpack_require__(/*! elementor-app/molecules/collapse */ "../app/assets/js/molecules/collapse.js"));
var _panelHeader = _interopRequireDefault(__webpack_require__(/*! ./panel-header */ "../app/assets/js/ui/panel/panel-header.js"));
var _panelHeadline = _interopRequireDefault(__webpack_require__(/*! ./panel-headline */ "../app/assets/js/ui/panel/panel-headline.js"));
var _panelBody = _interopRequireDefault(__webpack_require__(/*! ./panel-body */ "../app/assets/js/ui/panel/panel-body.js"));
__webpack_require__(/*! ./panel.scss */ "../app/assets/js/ui/panel/panel.scss");
function Panel(props) {
  return /*#__PURE__*/_react.default.createElement(_collapse.default, {
    isOpened: props.isOpened
  }, /*#__PURE__*/_react.default.createElement(_card.default, {
    className: (0, _utils.arrayToClassName)(['eps-panel', props.className])
  }, props.children));
}
Panel.propTypes = {
  className: PropTypes.string,
  isOpened: PropTypes.bool,
  children: PropTypes.any.isRequired
};
Panel.defaultProps = {
  className: '',
  isOpened: false
};
Panel.Header = _panelHeader.default;
Panel.Headline = _panelHeadline.default;
Panel.Body = _panelBody.default;

/***/ }),

/***/ "../app/assets/js/ui/table/table-body.js":
/*!***********************************************!*\
  !*** ../app/assets/js/ui/table/table-body.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = TableBody;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
function TableBody(props) {
  return /*#__PURE__*/_react.default.createElement("tbody", {
    className: (0, _utils.arrayToClassName)(['eps-table__body', props.className])
  }, props.children);
}
TableBody.propTypes = {
  children: PropTypes.any.isRequired,
  className: PropTypes.string
};

/***/ }),

/***/ "../app/assets/js/ui/table/table-cell.js":
/*!***********************************************!*\
  !*** ../app/assets/js/ui/table/table-cell.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = TableCell;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
function TableCell(props) {
  var Element = function Element() {
    return _react.default.createElement(props.tag, {
      className: (0, _utils.arrayToClassName)(['eps-table__cell', props.className]),
      colSpan: props.colSpan || null
    }, props.children);
  };
  return /*#__PURE__*/_react.default.createElement(Element, null);
}
TableCell.propTypes = {
  children: PropTypes.any,
  className: PropTypes.string,
  colSpan: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  tag: PropTypes.oneOf(['td', 'th']).isRequired
};

/***/ }),

/***/ "../app/assets/js/ui/table/table-checkbox.js":
/*!***************************************************!*\
  !*** ../app/assets/js/ui/table/table-checkbox.js ***!
  \***************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = TableCheckbox;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _toConsumableArray2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/toConsumableArray */ "../node_modules/@babel/runtime/helpers/toConsumableArray.js"));
var _tableContext = __webpack_require__(/*! ./table-context */ "../app/assets/js/ui/table/table-context.js");
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
var _checkbox = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/checkbox */ "../app/assets/js/ui/atoms/checkbox.js"));
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function TableCheckbox(props) {
  var context = (0, _react.useContext)(_tableContext.Context),
    _ref = context || {},
    selected = _ref.selected,
    disabled = _ref.disabled,
    setSelected = _ref.setSelected,
    isSelectAllCheckbox = Object.prototype.hasOwnProperty.call(props, 'allSelectedCount'),
    isAllSelected = selected.length === props.allSelectedCount,
    isIndeterminate = isSelectAllCheckbox ? !!(selected.length - disabled.length && !isAllSelected) : false,
    isSelected = isSelectAllCheckbox ? isAllSelected : selected.includes(props.index),
    isDisabled = !isSelectAllCheckbox ? disabled.includes(props.index) : null,
    onSelectAll = function onSelectAll() {
      setSelected(function () {
        if (isAllSelected || isIndeterminate) {
          // Disabled checkboxes should not be unchecked.
          return disabled.length ? (0, _toConsumableArray2.default)(disabled) : [];
        }
        return Array(props.allSelectedCount).fill(true).map(function (value, index) {
          return index;
        });
      });
    },
    onSelectRow = function onSelectRow() {
      setSelected(function (prevState) {
        var currentSelections = (0, _toConsumableArray2.default)(prevState),
          currentIndexPosition = currentSelections.indexOf(props.index);
        if (currentIndexPosition > -1) {
          currentSelections.splice(currentIndexPosition, 1);
        } else {
          currentSelections.push(props.index);
        }
        return currentSelections;
      });
    },
    onChange = function onChange() {
      return isSelectAllCheckbox ? onSelectAll() : onSelectRow();
    };
  return /*#__PURE__*/_react.default.createElement(_checkbox.default, {
    checked: isSelected,
    indeterminate: isIndeterminate,
    onChange: onChange,
    disabled: isDisabled,
    className: (0, _utils.arrayToClassName)(['eps-table__checkbox', props.className])
  });
}
TableCheckbox.propTypes = {
  className: PropTypes.string,
  index: PropTypes.number,
  initialChecked: PropTypes.bool,
  allSelectedCount: PropTypes.number
};

/***/ }),

/***/ "../app/assets/js/ui/table/table-context.js":
/*!**************************************************!*\
  !*** ../app/assets/js/ui/table/table-context.js ***!
  \**************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.Context = void 0;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var Context = _react.default.createContext();
exports.Context = Context;

/***/ }),

/***/ "../app/assets/js/ui/table/table-row.js":
/*!**********************************************!*\
  !*** ../app/assets/js/ui/table/table-row.js ***!
  \**********************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = TableRow;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
function TableRow(props) {
  return /*#__PURE__*/_react.default.createElement("tr", {
    className: (0, _utils.arrayToClassName)(['eps-table__row', props.className])
  }, props.children);
}
TableRow.propTypes = {
  children: PropTypes.any.isRequired,
  className: PropTypes.string
};

/***/ }),

/***/ "../app/assets/js/ui/table/table.head.js":
/*!***********************************************!*\
  !*** ../app/assets/js/ui/table/table.head.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = TableHead;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
function TableHead(props) {
  return /*#__PURE__*/_react.default.createElement("thead", {
    className: (0, _utils.arrayToClassName)(['eps-table__head', props.className])
  }, props.children);
}
TableHead.propTypes = {
  children: PropTypes.any.isRequired,
  className: PropTypes.string
};

/***/ }),

/***/ "../app/assets/js/ui/table/table.js":
/*!******************************************!*\
  !*** ../app/assets/js/ui/table/table.js ***!
  \******************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = Table;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _defineProperty2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "../node_modules/@babel/runtime/helpers/defineProperty.js"));
var _slicedToArray2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "../node_modules/@babel/runtime/helpers/slicedToArray.js"));
var _tableContext = __webpack_require__(/*! ./table-context */ "../app/assets/js/ui/table/table-context.js");
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
var _table = _interopRequireDefault(__webpack_require__(/*! ./table.head */ "../app/assets/js/ui/table/table.head.js"));
var _tableBody = _interopRequireDefault(__webpack_require__(/*! ./table-body */ "../app/assets/js/ui/table/table-body.js"));
var _tableRow = _interopRequireDefault(__webpack_require__(/*! ./table-row */ "../app/assets/js/ui/table/table-row.js"));
var _tableCell = _interopRequireDefault(__webpack_require__(/*! ./table-cell */ "../app/assets/js/ui/table/table-cell.js"));
var _tableCheckbox = _interopRequireDefault(__webpack_require__(/*! ./table-checkbox */ "../app/assets/js/ui/table/table-checkbox.js"));
__webpack_require__(/*! ./table.scss */ "../app/assets/js/ui/table/table.scss");
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function Table(_ref) {
  var className = _ref.className,
    initialSelected = _ref.initialSelected,
    initialDisabled = _ref.initialDisabled,
    selection = _ref.selection,
    children = _ref.children,
    onSelect = _ref.onSelect;
  var _useState = (0, _react.useState)(initialSelected),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    selected = _useState2[0],
    setSelected = _useState2[1],
    _useState3 = (0, _react.useState)(initialDisabled),
    _useState4 = (0, _slicedToArray2.default)(_useState3, 2),
    disabled = _useState4[0],
    setDisabled = _useState4[1],
    classNameBase = 'eps-table',
    classes = [classNameBase, (0, _defineProperty2.default)({}, classNameBase + '--selection', selection), className];
  (0, _react.useEffect)(function () {
    if (onSelect) {
      onSelect(selected);
    }
  }, [selected]);
  return /*#__PURE__*/_react.default.createElement(_tableContext.Context.Provider, {
    value: {
      selected: selected,
      setSelected: setSelected,
      disabled: disabled,
      setDisabled: setDisabled
    }
  }, /*#__PURE__*/_react.default.createElement("table", {
    className: (0, _utils.arrayToClassName)(classes)
  }, selection && /*#__PURE__*/_react.default.createElement("colgroup", null, /*#__PURE__*/_react.default.createElement("col", {
    className: classNameBase + '__checkboxes-column'
  })), children));
}
Table.Head = _table.default;
Table.Body = _tableBody.default;
Table.Row = _tableRow.default;
Table.Cell = _tableCell.default;
Table.Checkbox = _tableCheckbox.default;
Table.propTypes = {
  children: PropTypes.any.isRequired,
  className: PropTypes.string,
  headers: PropTypes.array,
  initialDisabled: PropTypes.array,
  initialSelected: PropTypes.array,
  rows: PropTypes.array,
  selection: PropTypes.bool,
  onSelect: PropTypes.func
};
Table.defaultProps = {
  selection: false,
  initialDisabled: [],
  initialSelected: []
};

/***/ }),

/***/ "../app/assets/js/url-actions/actions-map.js":
/*!***************************************************!*\
  !*** ../app/assets/js/url-actions/actions-map.js ***!
  \***************************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _default = {
  'import-kit': '/import/process'
};
exports["default"] = _default;

/***/ }),

/***/ "../app/assets/js/utils/utils.js":
/*!***************************************!*\
  !*** ../app/assets/js/utils/utils.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.stringToRemValues = exports.rgbToHex = exports.pxToRem = exports.isOneOf = exports.arrayToObjectByKey = exports.arrayToClassName = void 0;
var _typeof2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js"));
var pxToRem = function pxToRem(pixels) {
  if (!pixels) {
    return;
  } else if ('string' !== typeof pixels) {
    pixels = pixels.toString();
  }
  return pixels.split(' ').map(function (value) {
    return "".concat(value * 0.0625, "rem");
  }).join(' ');
};
exports.pxToRem = pxToRem;
var arrayToClassName = function arrayToClassName(array, action) {
  return array.filter(function (item) {
    return 'object' === (0, _typeof2.default)(item) ? Object.entries(item)[0][1] : item;
  }).map(function (item) {
    var value = 'object' === (0, _typeof2.default)(item) ? Object.entries(item)[0][0] : item;
    return action ? action(value) : value;
  }).join(' ');
};
exports.arrayToClassName = arrayToClassName;
var stringToRemValues = function stringToRemValues(string) {
  return string.split(' ').map(function (value) {
    return pxToRem(value);
  }).join(' ');
};
exports.stringToRemValues = stringToRemValues;
var rgbToHex = function rgbToHex(r, g, b) {
  return '#' + [r, g, b].map(function (x) {
    var hex = x.toString(16);
    return 1 === hex.length ? '0' + hex : hex;
  }).join('');
};
exports.rgbToHex = rgbToHex;
var isOneOf = function isOneOf(filetype, filetypeOptions) {
  return filetypeOptions.some(function (type) {
    return filetype.includes(type);
  });
};
exports.isOneOf = isOneOf;
var arrayToObjectByKey = function arrayToObjectByKey(array, key) {
  var finalObject = {};
  array.forEach(function (item) {
    return finalObject[item[key]] = item;
  });
  return finalObject;
};
exports.arrayToObjectByKey = arrayToObjectByKey;

/***/ }),

/***/ "../app/modules/import-export/assets/js/context/export-context/export-context-provider.js":
/*!************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/context/export-context/export-context-provider.js ***!
  \************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.ExportContext = void 0;
exports["default"] = ExportContextProvider;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _slicedToArray2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "../node_modules/@babel/runtime/helpers/slicedToArray.js"));
var _exportContextReducer = __webpack_require__(/*! ./export-context-reducer */ "../app/modules/import-export/assets/js/context/export-context/export-context-reducer.js");
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
var ExportContext = _react.default.createContext();
exports.ExportContext = ExportContext;
function ExportContextProvider(props) {
  var initialState = {
      downloadUrl: '',
      exportedData: null,
      isExportProcessStarted: false,
      plugins: [],
      kitInfo: {
        title: null,
        description: null
      }
    },
    _useReducer = (0, _react.useReducer)(_exportContextReducer.reducer, initialState),
    _useReducer2 = (0, _slicedToArray2.default)(_useReducer, 2),
    data = _useReducer2[0],
    dispatch = _useReducer2[1];
  return /*#__PURE__*/_react.default.createElement(ExportContext.Provider, {
    value: {
      data: data,
      dispatch: dispatch
    }
  }, props.children);
}
ExportContextProvider.propTypes = {
  children: PropTypes.object.isRequired
};

/***/ }),

/***/ "../app/modules/import-export/assets/js/context/export-context/export-context-reducer.js":
/*!***********************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/context/export-context/export-context-reducer.js ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.reducer = void 0;
var _defineProperty2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "../node_modules/@babel/runtime/helpers/defineProperty.js"));
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { (0, _defineProperty2.default)(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
var reducer = function reducer(state, _ref) {
  var type = _ref.type,
    payload = _ref.payload;
  switch (type) {
    case 'SET_DOWNLOAD_URL':
      return _objectSpread(_objectSpread({}, state), {}, {
        downloadUrl: payload
      });
    case 'SET_EXPORTED_DATA':
      return _objectSpread(_objectSpread({}, state), {}, {
        exportedData: payload
      });
    case 'SET_PLUGINS':
      return _objectSpread(_objectSpread({}, state), {}, {
        plugins: payload
      });
    case 'SET_IS_EXPORT_PROCESS_STARTED':
      return _objectSpread(_objectSpread({}, state), {}, {
        isExportProcessStarted: payload
      });
    case 'SET_KIT_TITLE':
      return _objectSpread(_objectSpread({}, state), {}, {
        kitInfo: _objectSpread(_objectSpread({}, state.kitInfo), {}, {
          title: payload
        })
      });
    case 'SET_KIT_DESCRIPTION':
      return _objectSpread(_objectSpread({}, state), {}, {
        kitInfo: _objectSpread(_objectSpread({}, state.kitInfo), {}, {
          description: payload
        })
      });
    default:
      return state;
  }
};
exports.reducer = reducer;

/***/ }),

/***/ "../app/modules/import-export/assets/js/context/import-context/import-context-provider.js":
/*!************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/context/import-context/import-context-provider.js ***!
  \************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.ImportContext = void 0;
exports["default"] = ImportContextProvider;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _slicedToArray2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "../node_modules/@babel/runtime/helpers/slicedToArray.js"));
var _importContextReducer = __webpack_require__(/*! ./import-context-reducer */ "../app/modules/import-export/assets/js/context/import-context/import-context-reducer.js");
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
var ImportContext = _react.default.createContext();
exports.ImportContext = ImportContext;
function ImportContextProvider(props) {
  var initialState = {
      id: null,
      file: null,
      uploadedData: null,
      importedData: null,
      plugins: [],
      requiredPlugins: [],
      importedPlugins: [],
      overrideConditions: [],
      isProInstalledDuringProcess: false,
      actionType: null,
      isResolvedData: false,
      pluginsState: ''
    },
    _useReducer = (0, _react.useReducer)(_importContextReducer.reducer, initialState),
    _useReducer2 = (0, _slicedToArray2.default)(_useReducer, 2),
    data = _useReducer2[0],
    dispatch = _useReducer2[1];
  return /*#__PURE__*/_react.default.createElement(ImportContext.Provider, {
    value: {
      data: data,
      dispatch: dispatch
    }
  }, props.children);
}
ImportContextProvider.propTypes = {
  children: PropTypes.object.isRequired
};

/***/ }),

/***/ "../app/modules/import-export/assets/js/context/import-context/import-context-reducer.js":
/*!***********************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/context/import-context/import-context-reducer.js ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.reducer = void 0;
var _defineProperty2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "../node_modules/@babel/runtime/helpers/defineProperty.js"));
var _reducerUtils = __webpack_require__(/*! ../utils/reducer-utils */ "../app/modules/import-export/assets/js/context/utils/reducer-utils.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { (0, _defineProperty2.default)(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
var reducer = function reducer(state, _ref) {
  var type = _ref.type,
    payload = _ref.payload;
  switch (type) {
    case 'SET_ID':
      return _objectSpread(_objectSpread({}, state), {}, {
        id: payload
      });
    case 'SET_FILE':
      return _objectSpread(_objectSpread({}, state), {}, {
        file: payload
      });
    case 'ADD_OVERRIDE_CONDITION':
      return _reducerUtils.ReducerUtils.updateArray(state, 'overrideConditions', payload, 'add');
    case 'REMOVE_OVERRIDE_CONDITION':
      return _reducerUtils.ReducerUtils.updateArray(state, 'overrideConditions', payload, 'remove');
    case 'SET_UPLOADED_DATA':
      return _objectSpread(_objectSpread({}, state), {}, {
        uploadedData: payload
      });
    case 'SET_IMPORTED_DATA':
      return _objectSpread(_objectSpread({}, state), {}, {
        importedData: payload
      });
    case 'SET_PLUGINS':
      return _objectSpread(_objectSpread({}, state), {}, {
        plugins: payload
      });
    case 'SET_REQUIRED_PLUGINS':
      return _objectSpread(_objectSpread({}, state), {}, {
        requiredPlugins: payload
      });
    case 'SET_IMPORTED_PLUGINS':
      return _objectSpread(_objectSpread({}, state), {}, {
        importedPlugins: payload
      });
    case 'SET_IS_PRO_INSTALLED_DURING_PROCESS':
      return _objectSpread(_objectSpread({}, state), {}, {
        isProInstalledDuringProcess: payload
      });
    case 'SET_ACTION_TYPE':
      return _objectSpread(_objectSpread({}, state), {}, {
        actionType: payload
      });
    case 'SET_IS_RESOLVED':
      return _objectSpread(_objectSpread({}, state), {}, {
        isResolvedData: payload
      });
    case 'SET_PLUGINS_STATE':
      return _objectSpread(_objectSpread({}, state), {}, {
        pluginsState: payload
      });
    default:
      return state;
  }
};
exports.reducer = reducer;

/***/ }),

/***/ "../app/modules/import-export/assets/js/context/shared-context/shared-context-provider.js":
/*!************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/context/shared-context/shared-context-provider.js ***!
  \************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.SharedContext = void 0;
exports["default"] = SharedContextProvider;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _slicedToArray2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "../node_modules/@babel/runtime/helpers/slicedToArray.js"));
var _sharedContextReducer = __webpack_require__(/*! ./shared-context-reducer */ "../app/modules/import-export/assets/js/context/shared-context/shared-context-reducer.js");
var _kitContentData = _interopRequireDefault(__webpack_require__(/*! ../../shared/kit-content-data/kit-content-data */ "../app/modules/import-export/assets/js/shared/kit-content-data/kit-content-data.js"));
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
var SharedContext = _react.default.createContext();
exports.SharedContext = SharedContext;
function SharedContextProvider(props) {
  var initialState = {
      includes: _kitContentData.default.map(function (item) {
        return item.type;
      }),
      referrer: null,
      customPostTypes: [],
      selectedCustomPostTypes: null,
      currentPage: null
    },
    _useReducer = (0, _react.useReducer)(_sharedContextReducer.reducer, initialState),
    _useReducer2 = (0, _slicedToArray2.default)(_useReducer, 2),
    data = _useReducer2[0],
    dispatch = _useReducer2[1];
  return /*#__PURE__*/_react.default.createElement(SharedContext.Provider, {
    value: {
      data: data,
      dispatch: dispatch
    }
  }, props.children);
}
SharedContextProvider.propTypes = {
  children: PropTypes.object.isRequired
};

/***/ }),

/***/ "../app/modules/import-export/assets/js/context/shared-context/shared-context-reducer.js":
/*!***********************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/context/shared-context/shared-context-reducer.js ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.reducer = void 0;
var _defineProperty2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "../node_modules/@babel/runtime/helpers/defineProperty.js"));
var _reducerUtils = __webpack_require__(/*! ../utils/reducer-utils */ "../app/modules/import-export/assets/js/context/utils/reducer-utils.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { (0, _defineProperty2.default)(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
var reducer = function reducer(state, _ref) {
  var type = _ref.type,
    payload = _ref.payload;
  switch (type) {
    case 'ADD_INCLUDE':
      return _reducerUtils.ReducerUtils.updateArray(state, 'includes', payload, 'add');
    case 'REMOVE_INCLUDE':
      return _reducerUtils.ReducerUtils.updateArray(state, 'includes', payload, 'remove');
    case 'SET_REFERRER':
      return _objectSpread(_objectSpread({}, state), {}, {
        referrer: payload
      });
    case 'SET_INCLUDES':
      return _objectSpread(_objectSpread({}, state), {}, {
        includes: payload
      });
    case 'SET_CPT':
      return _objectSpread(_objectSpread({}, state), {}, {
        customPostTypes: payload
      });
    case 'SET_SELECTED_CPT':
      return _objectSpread(_objectSpread({}, state), {}, {
        selectedCustomPostTypes: payload
      });
    case 'SET_CURRENT_PAGE_NAME':
      return _objectSpread(_objectSpread({}, state), {}, {
        currentPage: payload
      });
    default:
      return state;
  }
};
exports.reducer = reducer;

/***/ }),

/***/ "../app/modules/import-export/assets/js/context/utils/reducer-utils.js":
/*!*****************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/context/utils/reducer-utils.js ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.ReducerUtils = void 0;
var _toConsumableArray2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/toConsumableArray */ "../node_modules/@babel/runtime/helpers/toConsumableArray.js"));
var _defineProperty2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "../node_modules/@babel/runtime/helpers/defineProperty.js"));
var _classCallCheck2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "../node_modules/@babel/runtime/helpers/classCallCheck.js"));
var _createClass2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/createClass */ "../node_modules/@babel/runtime/helpers/createClass.js"));
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { (0, _defineProperty2.default)(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
var ReducerUtils = /*#__PURE__*/function () {
  function ReducerUtils() {
    (0, _classCallCheck2.default)(this, ReducerUtils);
  }
  (0, _createClass2.default)(ReducerUtils, null, [{
    key: "updateArray",
    value: function updateArray(state, key, value, action) {
      if ('add' === action) {
        // If the value already exists, then do nothing.
        if (state[key].includes(value)) {
          return state;
        }
        return _objectSpread(_objectSpread({}, state), {}, (0, _defineProperty2.default)({}, key, [].concat((0, _toConsumableArray2.default)(state[key]), [value])));
      } else if ('remove' === action) {
        return _objectSpread(_objectSpread({}, state), {}, (0, _defineProperty2.default)({}, key, state[key].filter(function (item) {
          return item !== value;
        })));
      }
      return state;
    }
  }]);
  return ReducerUtils;
}();
exports.ReducerUtils = ReducerUtils;

/***/ }),

/***/ "../app/modules/import-export/assets/js/export.js":
/*!********************************************************!*\
  !*** ../app/modules/import-export/assets/js/export.js ***!
  \********************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = Export;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _sharedContextProvider = _interopRequireDefault(__webpack_require__(/*! ./context/shared-context/shared-context-provider */ "../app/modules/import-export/assets/js/context/shared-context/shared-context-provider.js"));
var _exportContextProvider = _interopRequireDefault(__webpack_require__(/*! ./context/export-context/export-context-provider */ "../app/modules/import-export/assets/js/context/export-context/export-context-provider.js"));
var _router = __webpack_require__(/*! @reach/router */ "../node_modules/@reach/router/es/index.js");
var _router2 = _interopRequireDefault(__webpack_require__(/*! @elementor/router */ "@elementor/router"));
var _exportKit = _interopRequireDefault(__webpack_require__(/*! ./pages/export/export-kit/export-kit */ "../app/modules/import-export/assets/js/pages/export/export-kit/export-kit.js"));
var _exportComplete = _interopRequireDefault(__webpack_require__(/*! ./pages/export/export-complete/export-complete */ "../app/modules/import-export/assets/js/pages/export/export-complete/export-complete.js"));
var _exportPlugins = _interopRequireDefault(__webpack_require__(/*! ./pages/export/export-plugins/export-plugins */ "../app/modules/import-export/assets/js/pages/export/export-plugins/export-plugins.js"));
var _exportProcess = _interopRequireDefault(__webpack_require__(/*! ./pages/export/export-process/export-process */ "../app/modules/import-export/assets/js/pages/export/export-process/export-process.js"));
function Export() {
  return /*#__PURE__*/_react.default.createElement(_sharedContextProvider.default, null, /*#__PURE__*/_react.default.createElement(_exportContextProvider.default, null, /*#__PURE__*/_react.default.createElement(_router.LocationProvider, {
    history: _router2.default.appHistory
  }, /*#__PURE__*/_react.default.createElement(_router.Router, null, /*#__PURE__*/_react.default.createElement(_exportComplete.default, {
    path: "complete"
  }), /*#__PURE__*/_react.default.createElement(_exportPlugins.default, {
    path: "plugins"
  }), /*#__PURE__*/_react.default.createElement(_exportProcess.default, {
    path: "process"
  }), /*#__PURE__*/_react.default.createElement(_exportKit.default, {
    default: true
  })))));
}

/***/ }),

/***/ "../app/modules/import-export/assets/js/hooks/use-kit.js":
/*!***************************************************************!*\
  !*** ../app/modules/import-export/assets/js/hooks/use-kit.js ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = useKit;
var _regenerator = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/regenerator */ "../node_modules/@babel/runtime/regenerator/index.js"));
var _asyncToGenerator2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/asyncToGenerator */ "../node_modules/@babel/runtime/helpers/asyncToGenerator.js"));
var _defineProperty2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "../node_modules/@babel/runtime/helpers/defineProperty.js"));
var _slicedToArray2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "../node_modules/@babel/runtime/helpers/slicedToArray.js"));
var _react = __webpack_require__(/*! react */ "react");
var _useAjax2 = _interopRequireDefault(__webpack_require__(/*! elementor-app/hooks/use-ajax */ "../app/assets/js/hooks/use-ajax.js"));
function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it.return != null) it.return(); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { (0, _defineProperty2.default)(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
var KIT_STATUS_MAP = Object.freeze({
    INITIAL: 'initial',
    UPLOADED: 'uploaded',
    IMPORTED: 'imported',
    EXPORTED: 'exported',
    ERROR: 'error'
  }),
  UPLOAD_KIT_KEY = 'elementor_upload_kit',
  IMPORT_KIT_KEY = 'elementor_import_kit',
  EXPORT_KIT_KEY = 'elementor_export_kit',
  RUN_RUNNER_KEY = 'elementor_import_kit__runner';
function useKit() {
  var _useAjax = (0, _useAjax2.default)(),
    ajaxState = _useAjax.ajaxState,
    setAjax = _useAjax.setAjax,
    ajaxActions = _useAjax.ajaxActions,
    runRequest = _useAjax.runRequest,
    kitStateInitialState = {
      status: KIT_STATUS_MAP.INITIAL,
      data: null
    },
    _useState = (0, _react.useState)(kitStateInitialState),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    kitState = _useState2[0],
    setKitState = _useState2[1],
    uploadKit = function uploadKit(_ref) {
      var kitId = _ref.kitId,
        file = _ref.file,
        kitLibraryNonce = _ref.kitLibraryNonce;
      setAjax({
        data: _objectSpread({
          action: UPLOAD_KIT_KEY,
          e_import_file: file,
          kit_id: kitId
        }, kitLibraryNonce ? {
          e_kit_library_nonce: kitLibraryNonce
        } : {})
      });
    },
    initImportProcess = /*#__PURE__*/function () {
      var _ref3 = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee(_ref2) {
        var id, session, include, overrideConditions, referrer, selectedCustomPostTypes, ajaxConfig;
        return _regenerator.default.wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              id = _ref2.id, session = _ref2.session, include = _ref2.include, overrideConditions = _ref2.overrideConditions, referrer = _ref2.referrer, selectedCustomPostTypes = _ref2.selectedCustomPostTypes;
              ajaxConfig = {
                data: {
                  action: IMPORT_KIT_KEY,
                  data: {
                    id: id,
                    session: session,
                    include: include,
                    overrideConditions: overrideConditions
                  }
                }
              };
              if (referrer) {
                ajaxConfig.data.data.referrer = referrer;
              }
              if (selectedCustomPostTypes) {
                ajaxConfig.data.data.selectedCustomPostTypes = selectedCustomPostTypes;
              }
              ajaxConfig.data.data = JSON.stringify(ajaxConfig.data.data);
              _context.next = 7;
              return runRequest(ajaxConfig);
            case 7:
              return _context.abrupt("return", _context.sent);
            case 8:
            case "end":
              return _context.stop();
          }
        }, _callee);
      }));
      return function initImportProcess(_x) {
        return _ref3.apply(this, arguments);
      };
    }(),
    runImportRunners = /*#__PURE__*/function () {
      var _ref4 = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee2(session, runners) {
        var stopIterations, _iterator, _step, _step$value, iteration, runner, ajaxConfig, isLastIteration;
        return _regenerator.default.wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              stopIterations = false;
              _iterator = _createForOfIteratorHelper(runners.entries());
              _context2.prev = 2;
              _iterator.s();
            case 4:
              if ((_step = _iterator.n()).done) {
                _context2.next = 19;
                break;
              }
              _step$value = (0, _slicedToArray2.default)(_step.value, 2), iteration = _step$value[0], runner = _step$value[1];
              if (!stopIterations) {
                _context2.next = 8;
                break;
              }
              return _context2.abrupt("break", 19);
            case 8:
              ajaxConfig = {
                data: {
                  action: RUN_RUNNER_KEY,
                  data: {
                    session: session,
                    runner: runner
                  }
                }
              };
              ajaxConfig.data.data = JSON.stringify(ajaxConfig.data.data);

              // The last runner should run using the setAjax method, so it will trigger the useEffect and update the kitState.
              isLastIteration = iteration === runners.length - 1;
              if (isLastIteration) {
                _context2.next = 16;
                break;
              }
              _context2.next = 14;
              return runRequest(ajaxConfig).catch(function (error) {
                var _error$responseJSON;
                stopIterations = true;
                var response = 408 === error.status ? 'timeout' : (_error$responseJSON = error.responseJSON) === null || _error$responseJSON === void 0 ? void 0 : _error$responseJSON.data;
                setKitState(function (prevState) {
                  return _objectSpread(_objectSpread({}, prevState), {
                    status: KIT_STATUS_MAP.ERROR,
                    data: response || {}
                  });
                });
              });
            case 14:
              _context2.next = 17;
              break;
            case 16:
              setAjax(ajaxConfig);
            case 17:
              _context2.next = 4;
              break;
            case 19:
              _context2.next = 24;
              break;
            case 21:
              _context2.prev = 21;
              _context2.t0 = _context2["catch"](2);
              _iterator.e(_context2.t0);
            case 24:
              _context2.prev = 24;
              _iterator.f();
              return _context2.finish(24);
            case 27:
            case "end":
              return _context2.stop();
          }
        }, _callee2, null, [[2, 21, 24, 27]]);
      }));
      return function runImportRunners(_x2, _x3) {
        return _ref4.apply(this, arguments);
      };
    }(),
    importKit = /*#__PURE__*/function () {
      var _ref6 = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee3(_ref5) {
        var id, session, include, overrideConditions, referrer, selectedCustomPostTypes, importSession, newState;
        return _regenerator.default.wrap(function _callee3$(_context3) {
          while (1) switch (_context3.prev = _context3.next) {
            case 0:
              id = _ref5.id, session = _ref5.session, include = _ref5.include, overrideConditions = _ref5.overrideConditions, referrer = _ref5.referrer, selectedCustomPostTypes = _ref5.selectedCustomPostTypes;
              ajaxActions.reset();
              _context3.next = 4;
              return initImportProcess({
                id: id,
                session: session,
                include: include,
                overrideConditions: overrideConditions,
                referrer: referrer,
                selectedCustomPostTypes: selectedCustomPostTypes
              });
            case 4:
              importSession = _context3.sent;
              if (importSession.success) {
                _context3.next = 10;
                break;
              }
              newState = {
                status: KIT_STATUS_MAP.ERROR,
                data: ajaxState.response || {}
              };
              setKitState(function (prevState) {
                return _objectSpread(_objectSpread({}, prevState), newState);
              });
              _context3.next = 12;
              break;
            case 10:
              _context3.next = 12;
              return runImportRunners(importSession.data.session, importSession.data.runners);
            case 12:
            case "end":
              return _context3.stop();
          }
        }, _callee3);
      }));
      return function importKit(_x4) {
        return _ref6.apply(this, arguments);
      };
    }(),
    exportKit = function exportKit(_ref7) {
      var include = _ref7.include,
        kitInfo = _ref7.kitInfo,
        plugins = _ref7.plugins,
        selectedCustomPostTypes = _ref7.selectedCustomPostTypes;
      setAjax({
        data: {
          action: EXPORT_KIT_KEY,
          data: JSON.stringify({
            include: include,
            kitInfo: kitInfo,
            plugins: plugins,
            selectedCustomPostTypes: selectedCustomPostTypes
          })
        }
      });
    },
    reset = function reset() {
      return ajaxActions.reset();
    };
  (0, _react.useEffect)(function () {
    if ('initial' !== ajaxState.status) {
      var newState = {};
      if ('success' === ajaxState.status) {
        var _ajaxState$response;
        if ((_ajaxState$response = ajaxState.response) !== null && _ajaxState$response !== void 0 && _ajaxState$response.file) {
          newState.status = KIT_STATUS_MAP.EXPORTED;
        } else {
          var _ajaxState$response2;
          newState.status = (_ajaxState$response2 = ajaxState.response) !== null && _ajaxState$response2 !== void 0 && _ajaxState$response2.manifest ? KIT_STATUS_MAP.UPLOADED : KIT_STATUS_MAP.IMPORTED;
        }
      } else if ('error' === ajaxState.status) {
        newState.status = KIT_STATUS_MAP.ERROR;
      }

      // The response is required even if an error occurred, in order to detect the error type.
      newState.data = ajaxState.response || {};
      setKitState(function (prevState) {
        return _objectSpread(_objectSpread({}, prevState), newState);
      });
    }
  }, [ajaxState.status]);
  return {
    kitState: kitState,
    KIT_STATUS_MAP: KIT_STATUS_MAP,
    kitActions: {
      upload: uploadKit,
      import: importKit,
      export: exportKit,
      reset: reset
    }
  };
}

/***/ }),

/***/ "../app/modules/import-export/assets/js/hooks/use-plugins-data.js":
/*!************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/hooks/use-plugins-data.js ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.PLUGINS_KEYS = void 0;
exports["default"] = usePluginsData;
var _react = __webpack_require__(/*! react */ "react");
var PLUGINS_KEYS = Object.freeze({
  ELEMENTOR: 'Elementor',
  ELEMENTOR_PRO: 'Elementor Pro'
});
exports.PLUGINS_KEYS = PLUGINS_KEYS;
function usePluginsData(plugins) {
  var getPluginsData = function getPluginsData() {
    if (!plugins) {
      return [];
    }
    var elementorPlugins = [],
      generalPlugins = [];
    plugins.forEach(function (plugin) {
      switch (plugin.name) {
        case PLUGINS_KEYS.ELEMENTOR:
          // Making sure that the core plugin is always first.
          elementorPlugins.unshift(plugin);
          break;
        case PLUGINS_KEYS.ELEMENTOR_PRO:
          // Making sure that the pro plugin is always second.
          elementorPlugins.push(plugin);
          break;
        default:
          generalPlugins.push(plugin);
      }
    });

    // Making sure that the elementor plugins are always first.
    return elementorPlugins.concat(generalPlugins);
  };
  return {
    pluginsData: (0, _react.useMemo)(function () {
      return getPluginsData();
    }, [plugins])
  };
}

/***/ }),

/***/ "../app/modules/import-export/assets/js/hooks/use-plugins.js":
/*!*******************************************************************!*\
  !*** ../app/modules/import-export/assets/js/hooks/use-plugins.js ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.PLUGIN_STATUS_MAP = exports.PLUGINS_RESPONSE_MAP = void 0;
exports["default"] = usePlugins;
var _slicedToArray2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "../node_modules/@babel/runtime/helpers/slicedToArray.js"));
var _react = __webpack_require__(/*! react */ "react");
var PLUGINS_RESPONSE_MAP = Object.freeze({
  INITIAL: 'initial',
  SUCCESS: 'success',
  ERROR: 'error'
});
exports.PLUGINS_RESPONSE_MAP = PLUGINS_RESPONSE_MAP;
var PLUGIN_STATUS_MAP = Object.freeze({
  ACTIVE: 'active',
  MULTISITE_ACTIVE: 'network-active',
  INACTIVE: 'inactive',
  NOT_INSTALLED: 'Not Installed'
});
exports.PLUGIN_STATUS_MAP = PLUGIN_STATUS_MAP;
var baseEndpoint = elementorCommon.config.urls.rest + 'wp/v2/plugins/',
  getInitialState = function getInitialState() {
    return {
      status: PLUGINS_RESPONSE_MAP.INITIAL,
      data: null
    };
  };
function usePlugins() {
  var _useState = (0, _react.useState)(function () {
      return getInitialState();
    }),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    response = _useState2[0],
    setResponse = _useState2[1],
    allowResponseUpdate = (0, _react.useRef)(true),
    fetchRest = function fetchRest(_ref) {
      var body = _ref.body,
        method = _ref.method,
        _ref$endpoint = _ref.endpoint,
        endpoint = _ref$endpoint === void 0 ? '' : _ref$endpoint;
      var data = {
        method: method,
        headers: {
          'Content-Type': 'application/json; charset=utf-8',
          'X-WP-Nonce': wpApiSettings.nonce,
          // TODO 18/04/2023 : This needs to be removed after https://elementor.atlassian.net/browse/HTS-434 is done.
          'X-Elementor-Action': 'import-plugins'
        }
      };
      if (body) {
        data.body = JSON.stringify(body);
      }
      if (response.data) {
        reset();
      }
      return new Promise(function (resolve, reject) {
        fetch(baseEndpoint + endpoint, data).then(function (res) {
          return res.json();
        }).then(function (res) {
          if (allowResponseUpdate.current) {
            setResponse({
              status: PLUGINS_RESPONSE_MAP.SUCCESS,
              data: res
            });
          }
          resolve(res);
        }).catch(function (error) {
          setResponse({
            status: PLUGINS_RESPONSE_MAP.ERROR,
            data: error
          });
          reject(error);
        });
      });
    },
    fetchData = function fetchData(slug) {
      return fetchRest({
        method: 'GET',
        endpoint: slug
      });
    },
    install = function install(slug) {
      slug = slug.split('/')[0];
      return fetchRest({
        method: 'POST',
        body: {
          slug: slug
        }
      });
    },
    activate = function activate(slug) {
      return fetchRest({
        endpoint: slug,
        method: 'PUT',
        body: {
          status: PLUGIN_STATUS_MAP.ACTIVE
        }
      });
    },
    deactivate = function deactivate(slug) {
      return fetchRest({
        endpoint: slug,
        method: 'PUT',
        body: {
          status: PLUGIN_STATUS_MAP.INACTIVE
        }
      });
    },
    remove = function remove(slug) {
      return fetchRest({
        endpoint: slug,
        method: 'DELETE'
      });
    },
    reset = function reset() {
      return setResponse(getInitialState());
    };

  // On load.
  (0, _react.useEffect)(function () {
    fetchData();

    // Cleanup on destroy.
    return function () {
      allowResponseUpdate.current = false;
    };
  }, []);
  return {
    response: response,
    pluginsActions: {
      fetch: fetchData,
      install: install,
      activate: activate,
      deactivate: deactivate,
      remove: remove,
      reset: reset
    }
  };
}

/***/ }),

/***/ "../app/modules/import-export/assets/js/import.js":
/*!********************************************************!*\
  !*** ../app/modules/import-export/assets/js/import.js ***!
  \********************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = Import;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _sharedContextProvider = _interopRequireDefault(__webpack_require__(/*! ./context/shared-context/shared-context-provider */ "../app/modules/import-export/assets/js/context/shared-context/shared-context-provider.js"));
var _importContextProvider = _interopRequireDefault(__webpack_require__(/*! ./context/import-context/import-context-provider */ "../app/modules/import-export/assets/js/context/import-context/import-context-provider.js"));
var _router = __webpack_require__(/*! @reach/router */ "../node_modules/@reach/router/es/index.js");
var _router2 = _interopRequireDefault(__webpack_require__(/*! @elementor/router */ "@elementor/router"));
var _importKit = _interopRequireDefault(__webpack_require__(/*! ./pages/import/import-kit/import-kit */ "../app/modules/import-export/assets/js/pages/import/import-kit/import-kit.js"));
var _importContent = _interopRequireDefault(__webpack_require__(/*! ./pages/import/import-content/import-content */ "../app/modules/import-export/assets/js/pages/import/import-content/import-content.js"));
var _importResolver = _interopRequireDefault(__webpack_require__(/*! ./pages/import/import-resolver/import-resolver */ "../app/modules/import-export/assets/js/pages/import/import-resolver/import-resolver.js"));
var _importPluginsActivation = _interopRequireDefault(__webpack_require__(/*! ./pages/import/import-plugins-activation/import-plugins-activation */ "../app/modules/import-export/assets/js/pages/import/import-plugins-activation/import-plugins-activation.js"));
var _importProcess = _interopRequireDefault(__webpack_require__(/*! ./pages/import/import-process/import-process */ "../app/modules/import-export/assets/js/pages/import/import-process/import-process.js"));
var _importComplete = _interopRequireDefault(__webpack_require__(/*! ./pages/import/import-complete/import-complete */ "../app/modules/import-export/assets/js/pages/import/import-complete/import-complete.js"));
var _importPlugins = _interopRequireDefault(__webpack_require__(/*! ./pages/import/import-plugins/import-plugins */ "../app/modules/import-export/assets/js/pages/import/import-plugins/import-plugins.js"));
function Import() {
  return /*#__PURE__*/_react.default.createElement(_sharedContextProvider.default, null, /*#__PURE__*/_react.default.createElement(_importContextProvider.default, null, /*#__PURE__*/_react.default.createElement(_router.LocationProvider, {
    history: _router2.default.appHistory
  }, /*#__PURE__*/_react.default.createElement(_router.Router, null, /*#__PURE__*/_react.default.createElement(_importComplete.default, {
    path: "complete"
  }), /*#__PURE__*/_react.default.createElement(_importProcess.default, {
    path: "process"
  }), /*#__PURE__*/_react.default.createElement(_importResolver.default, {
    path: "resolver"
  }), /*#__PURE__*/_react.default.createElement(_importContent.default, {
    path: "content"
  }), /*#__PURE__*/_react.default.createElement(_importPlugins.default, {
    path: "plugins"
  }), /*#__PURE__*/_react.default.createElement(_importPluginsActivation.default, {
    path: "plugins-activation"
  }), /*#__PURE__*/_react.default.createElement(_importKit.default, {
    default: true
  })))));
}

/***/ }),

/***/ "../app/modules/import-export/assets/js/module.js":
/*!********************************************************!*\
  !*** ../app/modules/import-export/assets/js/module.js ***!
  \********************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _createClass2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/createClass */ "../node_modules/@babel/runtime/helpers/createClass.js"));
var _classCallCheck2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "../node_modules/@babel/runtime/helpers/classCallCheck.js"));
var _defineProperty2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "../node_modules/@babel/runtime/helpers/defineProperty.js"));
var _router = _interopRequireDefault(__webpack_require__(/*! @elementor/router */ "@elementor/router"));
var _import = _interopRequireDefault(__webpack_require__(/*! ./import */ "../app/modules/import-export/assets/js/import.js"));
var _export = _interopRequireDefault(__webpack_require__(/*! ./export */ "../app/modules/import-export/assets/js/export.js"));
function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it.return != null) it.return(); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
var ImportExport = /*#__PURE__*/(0, _createClass2.default)(function ImportExport() {
  (0, _classCallCheck2.default)(this, ImportExport);
  (0, _defineProperty2.default)(this, "routes", [{
    path: '/import/*',
    component: _import.default
  }, {
    path: '/export/*',
    component: _export.default
  }]);
  var _iterator = _createForOfIteratorHelper(this.routes),
    _step;
  try {
    for (_iterator.s(); !(_step = _iterator.n()).done;) {
      var route = _step.value;
      _router.default.addRoute(route);
    }
  } catch (err) {
    _iterator.e(err);
  } finally {
    _iterator.f();
  }
});
exports["default"] = ImportExport;

/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/export/export-complete/export-complete.js":
/*!**********************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/export/export-complete/export-complete.js ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = ExportComplete;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _router = __webpack_require__(/*! @reach/router */ "../node_modules/@reach/router/es/index.js");
var _exportContextProvider = __webpack_require__(/*! ../../../context/export-context/export-context-provider */ "../app/modules/import-export/assets/js/context/export-context/export-context-provider.js");
var _layout = _interopRequireDefault(__webpack_require__(/*! ../../../templates/layout */ "../app/modules/import-export/assets/js/templates/layout.js"));
var _actionsFooter = _interopRequireDefault(__webpack_require__(/*! ../../../shared/actions-footer/actions-footer */ "../app/modules/import-export/assets/js/shared/actions-footer/actions-footer.js"));
var _wizardStep = _interopRequireDefault(__webpack_require__(/*! ../../../ui/wizard-step/wizard-step */ "../app/modules/import-export/assets/js/ui/wizard-step/wizard-step.js"));
var _kitData = _interopRequireDefault(__webpack_require__(/*! ../../../shared/kit-data/kit-data */ "../app/modules/import-export/assets/js/shared/kit-data/kit-data.js"));
var _inlineLink = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/inline-link */ "../app/assets/js/ui/molecules/inline-link.js"));
var _dashboardButton = _interopRequireDefault(__webpack_require__(/*! elementor-app/molecules/dashboard-button */ "../app/assets/js/molecules/dashboard-button.js"));
__webpack_require__(/*! ./export-complete.scss */ "../app/modules/import-export/assets/js/pages/export/export-complete/export-complete.scss");
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function ExportComplete() {
  var _exportContext$data, _exportContext$data$e;
  var exportContext = (0, _react.useContext)(_exportContextProvider.ExportContext),
    navigate = (0, _router.useNavigate)(),
    downloadLink = (0, _react.useRef)(null),
    getFooter = function getFooter() {
      return /*#__PURE__*/_react.default.createElement(_actionsFooter.default, null, /*#__PURE__*/_react.default.createElement(_dashboardButton.default, {
        text: __('Close', 'elementor')
      }));
    },
    downloadFile = function downloadFile() {
      if (!downloadLink.current) {
        var link = document.createElement('a');
        link.href = 'data:text/plain;base64,' + exportContext.data.exportedData.file;
        link.download = 'elementor-kit.zip';
        downloadLink.current = link;
      }
      downloadLink.current.click();
    },
    getDownloadLink = function getDownloadLink() {
      return /*#__PURE__*/_react.default.createElement(_inlineLink.default, {
        onClick: downloadFile,
        italic: true
      }, __('Click here', 'elementor'));
    };
  (0, _react.useEffect)(function () {
    if (exportContext.data.exportedData) {
      downloadFile();
    } else {
      navigate('/export');
    }
  }, [exportContext.data.downloadUrl]);
  return /*#__PURE__*/_react.default.createElement(_layout.default, {
    type: "export",
    footer: getFooter()
  }, /*#__PURE__*/_react.default.createElement(_wizardStep.default, {
    image: elementorAppConfig.assets_url + 'images/go-pro.svg',
    heading: __('Your export is ready!', 'elementor'),
    description: __('Now you can import this kit and use it on other sites.', 'elementor'),
    notice: /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, __('Download not working?', 'elementor'), " ", getDownloadLink(), " ", __('to download', 'elementor'))
  }, /*#__PURE__*/_react.default.createElement(_kitData.default, {
    data: (_exportContext$data = exportContext.data) === null || _exportContext$data === void 0 ? void 0 : (_exportContext$data$e = _exportContext$data.exportedData) === null || _exportContext$data$e === void 0 ? void 0 : _exportContext$data$e.manifest
  })));
}

/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/export/export-kit/components/kit-information/components/kit-description/kit-description.js":
/*!***********************************************************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/export/export-kit/components/kit-information/components/kit-description/kit-description.js ***!
  \***********************************************************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = KitDescription;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _exportContextProvider = __webpack_require__(/*! ../../../../../../../context/export-context/export-context-provider */ "../app/modules/import-export/assets/js/context/export-context/export-context-provider.js");
var _textField = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/text-field */ "../app/assets/js/ui/atoms/text-field.js"));
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function KitDescription() {
  var exportContext = (0, _react.useContext)(_exportContextProvider.ExportContext);
  return /*#__PURE__*/_react.default.createElement(_textField.default, {
    variant: "outlined"
    // eslint-disable-next-line @wordpress/i18n-ellipsis
    ,
    placeholder: __('Say something about the style and content of these files...', 'elementor'),
    multiline: true,
    rows: 5,
    onChange: function onChange(event) {
      exportContext.dispatch({
        type: 'SET_KIT_DESCRIPTION',
        payload: event.target.value
      });
    }
  });
}

/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/export/export-kit/components/kit-information/components/kit-info-modal/kit-info-modal.js":
/*!*********************************************************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/export/export-kit/components/kit-information/components/kit-info-modal/kit-info-modal.js ***!
  \*********************************************************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = KitInfoModal;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _extends2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/extends */ "../node_modules/@babel/runtime/helpers/extends.js"));
var _modal = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/modal/modal */ "../app/assets/js/ui/modal/modal.js"));
var _heading = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/heading */ "../app/assets/js/ui/atoms/heading.js"));
var _text = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/text */ "../app/assets/js/ui/atoms/text.js"));
function KitInfoModal(props) {
  return /*#__PURE__*/_react.default.createElement(_modal.default, (0, _extends2.default)({}, props, {
    className: "e-app-export-kit-info-modal",
    title: __('Website Kit Information', 'elementor')
  }), /*#__PURE__*/_react.default.createElement(_modal.default.Section, null, /*#__PURE__*/_react.default.createElement(_heading.default, {
    className: "e-app-export-kit-info-modal__heading",
    variant: "h2",
    tag: "h3"
  }, __('What is kit information?', 'elementor')), /*#__PURE__*/_react.default.createElement(_text.default, null, __('These are the details you’ll use to quickly find and apply this kit in the future, even as your collection grows.', 'elementor'))));
}

/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/export/export-kit/components/kit-information/components/kit-name/kit-name.js":
/*!*********************************************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/export/export-kit/components/kit-information/components/kit-name/kit-name.js ***!
  \*********************************************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = KitName;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _exportContextProvider = __webpack_require__(/*! ../../../../../../../context/export-context/export-context-provider */ "../app/modules/import-export/assets/js/context/export-context/export-context-provider.js");
var _textField = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/text-field */ "../app/assets/js/ui/atoms/text-field.js"));
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function KitName() {
  var exportContext = (0, _react.useContext)(_exportContextProvider.ExportContext);
  return /*#__PURE__*/_react.default.createElement(_textField.default, {
    variant: "outlined",
    placeholder: __('Elementor Kit', 'elementor'),
    onChange: function onChange(event) {
      exportContext.dispatch({
        type: 'SET_KIT_TITLE',
        payload: event.target.value
      });
    }
  });
}

/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/export/export-kit/components/kit-information/kit-information.js":
/*!********************************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/export/export-kit/components/kit-information/kit-information.js ***!
  \********************************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = KitInformation;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _slicedToArray2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "../node_modules/@babel/runtime/helpers/slicedToArray.js"));
var _kitName = _interopRequireDefault(__webpack_require__(/*! ./components/kit-name/kit-name */ "../app/modules/import-export/assets/js/pages/export/export-kit/components/kit-information/components/kit-name/kit-name.js"));
var _kitDescription = _interopRequireDefault(__webpack_require__(/*! ./components/kit-description/kit-description */ "../app/modules/import-export/assets/js/pages/export/export-kit/components/kit-information/components/kit-description/kit-description.js"));
var _kitInfoModal = _interopRequireDefault(__webpack_require__(/*! ./components/kit-info-modal/kit-info-modal */ "../app/modules/import-export/assets/js/pages/export/export-kit/components/kit-information/components/kit-info-modal/kit-info-modal.js"));
var _panel = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/panel/panel */ "../app/assets/js/ui/panel/panel.js"));
var _grid = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/grid/grid */ "../app/assets/js/ui/grid/grid.js"));
var _heading = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/heading */ "../app/assets/js/ui/atoms/heading.js"));
var _button = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/button */ "../app/assets/js/ui/molecules/button.js"));
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
var kitInfoTitle = __('Kit Information', 'elementor');
function KitInformation() {
  var _useState = (0, _react.useState)(false),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    showKitInfoModal = _useState2[0],
    setShowKitInfoModal = _useState2[1];
  return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement(_panel.default, {
    className: "e-app-export-kit-information"
  }, /*#__PURE__*/_react.default.createElement(_panel.default.Header, null, /*#__PURE__*/_react.default.createElement(_panel.default.Headline, null, kitInfoTitle, /*#__PURE__*/_react.default.createElement(_button.default, {
    className: "e-app-export-kit-info-modal__icon",
    icon: "eicon-info-circle",
    color: "secondary",
    hideText: true,
    text: kitInfoTitle,
    onClick: function onClick(event) {
      event.stopPropagation();
      setShowKitInfoModal(function (prevState) {
        return !prevState;
      });
    }
  }))), /*#__PURE__*/_react.default.createElement(_panel.default.Body, null, /*#__PURE__*/_react.default.createElement(_grid.default, {
    container: true,
    spacing: 20
  }, /*#__PURE__*/_react.default.createElement(_grid.default, {
    item: true,
    md: 4
  }, /*#__PURE__*/_react.default.createElement(_grid.default, {
    container: true,
    direction: "column"
  }, /*#__PURE__*/_react.default.createElement(_grid.default, {
    className: "e-app-export-kit-information__field-header",
    container: true,
    alignItems: "center"
  }, /*#__PURE__*/_react.default.createElement(_heading.default, {
    className: "e-app-export-kit-information__label",
    variant: "h6",
    tag: "h4"
  }, __('Kit Name', 'elementor'))), /*#__PURE__*/_react.default.createElement(_grid.default, {
    item: true
  }, /*#__PURE__*/_react.default.createElement(_kitName.default, null)))), /*#__PURE__*/_react.default.createElement(_grid.default, {
    item: true,
    md: 4
  }, /*#__PURE__*/_react.default.createElement(_grid.default, {
    className: "e-app-export-kit-information__field-header",
    container: true,
    alignItems: "center"
  }, /*#__PURE__*/_react.default.createElement(_heading.default, {
    className: "e-app-export-kit-information__label",
    variant: "h6",
    tag: "h4"
  }, __('Kit Description', 'elementor'))), /*#__PURE__*/_react.default.createElement(_grid.default, {
    item: true
  }, /*#__PURE__*/_react.default.createElement(_kitDescription.default, null)))))), /*#__PURE__*/_react.default.createElement(_kitInfoModal.default, {
    show: showKitInfoModal,
    setShow: setShowKitInfoModal
  }));
}

/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/export/export-kit/export-kit.js":
/*!************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/export/export-kit/export-kit.js ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = ExportKit;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _exportContextProvider = __webpack_require__(/*! ../../../context/export-context/export-context-provider */ "../app/modules/import-export/assets/js/context/export-context/export-context-provider.js");
var _sharedContextProvider = __webpack_require__(/*! ../../../context/shared-context/shared-context-provider */ "../app/modules/import-export/assets/js/context/shared-context/shared-context-provider.js");
var _cptObjectToOptionsArray = __webpack_require__(/*! ../../../shared/cpt-select-box/cpt-object-to-options-array */ "../app/modules/import-export/assets/js/shared/cpt-select-box/cpt-object-to-options-array.js");
var _layout = _interopRequireDefault(__webpack_require__(/*! ../../../templates/layout */ "../app/modules/import-export/assets/js/templates/layout.js"));
var _pageHeader = _interopRequireDefault(__webpack_require__(/*! ../../../ui/page-header/page-header */ "../app/modules/import-export/assets/js/ui/page-header/page-header.js"));
var _kitContent = _interopRequireDefault(__webpack_require__(/*! ../../../shared/kit-content/kit-content */ "../app/modules/import-export/assets/js/shared/kit-content/kit-content.js"));
var _kitInformation = _interopRequireDefault(__webpack_require__(/*! ./components/kit-information/kit-information */ "../app/modules/import-export/assets/js/pages/export/export-kit/components/kit-information/kit-information.js"));
var _actionsFooter = _interopRequireDefault(__webpack_require__(/*! ../../../shared/actions-footer/actions-footer */ "../app/modules/import-export/assets/js/shared/actions-footer/actions-footer.js"));
var _inlineLink = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/inline-link */ "../app/assets/js/ui/molecules/inline-link.js"));
var _button = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/button */ "../app/assets/js/ui/molecules/button.js"));
var _kitContentData = _interopRequireDefault(__webpack_require__(/*! ../../../shared/kit-content-data/kit-content-data */ "../app/modules/import-export/assets/js/shared/kit-content-data/kit-content-data.js"));
__webpack_require__(/*! ./export-kit.scss */ "../app/modules/import-export/assets/js/pages/export/export-kit/export-kit.scss");
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function ExportKit() {
  var exportContext = (0, _react.useContext)(_exportContextProvider.ExportContext),
    sharedContext = (0, _react.useContext)(_sharedContextProvider.SharedContext),
    getFooter = function getFooter() {
      return /*#__PURE__*/_react.default.createElement(_actionsFooter.default, null, /*#__PURE__*/_react.default.createElement(_button.default, {
        variant: "contained",
        text: __('Next', 'elementor'),
        color: "primary",
        url: "/export/plugins"
      }));
    },
    getLearnMoreLink = function getLearnMoreLink() {
      return /*#__PURE__*/_react.default.createElement(_inlineLink.default, {
        url: "https://go.elementor.com/app-what-are-kits",
        italic: true
      }, __('Learn More', 'elementor'));
    };
  (0, _react.useEffect)(function () {
    var _elementorAppConfig$i;
    exportContext.dispatch({
      type: 'SET_IS_EXPORT_PROCESS_STARTED',
      payload: true
    });
    sharedContext.dispatch({
      type: 'SET_CPT',
      payload: (0, _cptObjectToOptionsArray.cptObjectToOptionsArray)((_elementorAppConfig$i = elementorAppConfig['import-export'].summaryTitles.content) === null || _elementorAppConfig$i === void 0 ? void 0 : _elementorAppConfig$i.customPostTypes, 'plural')
    });
  }, []);
  return /*#__PURE__*/_react.default.createElement(_layout.default, {
    type: "export",
    footer: getFooter()
  }, /*#__PURE__*/_react.default.createElement("section", {
    className: "e-app-export-kit"
  }, /*#__PURE__*/_react.default.createElement(_pageHeader.default, {
    heading: __('Export a Website Kit', 'elementor'),
    description: [__('Choose which Elementor components - templates, content and site settings - to include in your kit file.', 'elementor'), /*#__PURE__*/_react.default.createElement(_react.default.Fragment, {
      key: "description-secondary-line"
    }, __('By default, all of your components will be exported.', 'elementor'), " ", getLearnMoreLink())]
  }), /*#__PURE__*/_react.default.createElement(_kitContent.default, {
    contentData: _kitContentData.default
  }), /*#__PURE__*/_react.default.createElement(_kitInformation.default, null)));
}

/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/export/export-plugins/components/export-plugins-footer/export-plugins-footer.js":
/*!************************************************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/export/export-plugins/components/export-plugins-footer/export-plugins-footer.js ***!
  \************************************************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = ExportPluginsFooter;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _actionsFooter = _interopRequireDefault(__webpack_require__(/*! ../../../../../shared/actions-footer/actions-footer */ "../app/modules/import-export/assets/js/shared/actions-footer/actions-footer.js"));
var _button = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/button */ "../app/assets/js/ui/molecules/button.js"));
function ExportPluginsFooter(_ref) {
  var isKitReady = _ref.isKitReady;
  return /*#__PURE__*/_react.default.createElement(_actionsFooter.default, null, /*#__PURE__*/_react.default.createElement(_button.default, {
    text: __('Back', 'elementor'),
    variant: "contained",
    url: "/export"
  }), /*#__PURE__*/_react.default.createElement(_button.default, {
    text: __('Create Kit', 'elementor'),
    variant: "contained",
    color: isKitReady ? 'primary' : 'disabled',
    url: isKitReady ? '/export/process' : ''
  }));
}
ExportPluginsFooter.propTypes = {
  isKitReady: PropTypes.bool.isRequired
};

/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/export/export-plugins/components/export-plugins-selection/export-plugins-selection.js":
/*!******************************************************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/export/export-plugins/components/export-plugins-selection/export-plugins-selection.js ***!
  \******************************************************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _pluginsSelection = _interopRequireDefault(__webpack_require__(/*! ../../../../../shared/plugins-selection/plugins-selection */ "../app/modules/import-export/assets/js/shared/plugins-selection/plugins-selection.js"));
var _loader = _interopRequireDefault(__webpack_require__(/*! ../../../../../ui/loader/loader */ "../app/modules/import-export/assets/js/ui/loader/loader.js"));
var _usePlugins2 = _interopRequireWildcard(__webpack_require__(/*! ../../../../../hooks/use-plugins */ "../app/modules/import-export/assets/js/hooks/use-plugins.js"));
var _usePluginsData2 = _interopRequireWildcard(__webpack_require__(/*! ../../../../../hooks/use-plugins-data */ "../app/modules/import-export/assets/js/hooks/use-plugins-data.js"));
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
var layout = [3, 1],
  initialDisabled = [0]; // Elementor Core will always be first and should always be disabled.

function ExportPluginsSelection(_ref) {
  var onSelect = _ref.onSelect;
  var _usePlugins = (0, _usePlugins2.default)(),
    response = _usePlugins.response,
    _usePluginsData = (0, _usePluginsData2.default)(response.data),
    pluginsData = _usePluginsData.pluginsData,
    activePlugins = pluginsData.filter(function (_ref2) {
      var status = _ref2.status;
      return _usePlugins2.PLUGIN_STATUS_MAP.ACTIVE === status || _usePlugins2.PLUGIN_STATUS_MAP.MULTISITE_ACTIVE === status;
    }),
    getInitialSelected = function getInitialSelected() {
      // Elementor Core will always be the first plugin on the list.
      var initialSelected = [0];

      // In case that Elementor Pro appears in the list it will always be second and should always be selected by default.
      if (activePlugins.length > 1 && _usePluginsData2.PLUGINS_KEYS.ELEMENTOR_PRO === activePlugins[1].name) {
        initialSelected.push(1);
      }
      return initialSelected;
    };
  if (!response.data) {
    return /*#__PURE__*/_react.default.createElement(_loader.default, {
      absoluteCenter: true
    });
  }
  return /*#__PURE__*/_react.default.createElement(_pluginsSelection.default, {
    plugins: activePlugins,
    initialSelected: getInitialSelected(),
    initialDisabled: initialDisabled,
    layout: layout,
    withStatus: false,
    onSelect: onSelect
  });
}
ExportPluginsSelection.propTypes = {
  onSelect: PropTypes.func.isRequired
};
var _default = (0, _react.memo)(ExportPluginsSelection);
exports["default"] = _default;

/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/export/export-plugins/export-plugins.js":
/*!********************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/export/export-plugins/export-plugins.js ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = ExportPlugins;
var _slicedToArray2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "../node_modules/@babel/runtime/helpers/slicedToArray.js"));
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _router = __webpack_require__(/*! @reach/router */ "../node_modules/@reach/router/es/index.js");
var _sharedContextProvider = __webpack_require__(/*! ../../../context/shared-context/shared-context-provider */ "../app/modules/import-export/assets/js/context/shared-context/shared-context-provider.js");
var _exportContextProvider = __webpack_require__(/*! ../../../context/export-context/export-context-provider */ "../app/modules/import-export/assets/js/context/export-context/export-context-provider.js");
var _layout = _interopRequireDefault(__webpack_require__(/*! ../../../templates/layout */ "../app/modules/import-export/assets/js/templates/layout.js"));
var _pageHeader = _interopRequireDefault(__webpack_require__(/*! ../../../ui/page-header/page-header */ "../app/modules/import-export/assets/js/ui/page-header/page-header.js"));
var _exportPluginsSelection = _interopRequireDefault(__webpack_require__(/*! ./components/export-plugins-selection/export-plugins-selection */ "../app/modules/import-export/assets/js/pages/export/export-plugins/components/export-plugins-selection/export-plugins-selection.js"));
var _exportPluginsFooter = _interopRequireDefault(__webpack_require__(/*! ./components/export-plugins-footer/export-plugins-footer */ "../app/modules/import-export/assets/js/pages/export/export-plugins/components/export-plugins-footer/export-plugins-footer.js"));
__webpack_require__(/*! ./export-plugins.scss */ "../app/modules/import-export/assets/js/pages/export/export-plugins/export-plugins.scss");
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function ExportPlugins() {
  var sharedContext = (0, _react.useContext)(_sharedContextProvider.SharedContext),
    exportContext = (0, _react.useContext)(_exportContextProvider.ExportContext),
    navigate = (0, _router.useNavigate)(),
    _useState = (0, _react.useState)(false),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    isKitReady = _useState2[0],
    setIsKitReady = _useState2[1],
    _ref = exportContext.data || [],
    plugins = _ref.plugins,
    isExportProcessStarted = _ref.isExportProcessStarted,
    hasIncludes = !!sharedContext.data.includes.length,
    handleOnSelect = (0, _react.useCallback)(function (selectedPlugins) {
      return exportContext.dispatch({
        type: 'SET_PLUGINS',
        payload: selectedPlugins
      });
    }, []);

  // On load.
  (0, _react.useEffect)(function () {
    if (!isExportProcessStarted) {
      // When not starting from the main screen.
      navigate('/export');
    }
  }, []);

  // On plugins change.
  (0, _react.useEffect)(function () {
    if (hasIncludes && plugins.length) {
      // In case that the kit has content and the plugins data exist, then the kit can be exported.
      setIsKitReady(true);
    } else {
      // There should be at least one more plugin select in addition to Elementor Core.
      var isExportKitAllowed = plugins.length > 1;

      // In case that the kit has no content, it can only be exported if there is at least one selected plugin.
      setIsKitReady(isExportKitAllowed);
    }
  }, [plugins]);
  return /*#__PURE__*/_react.default.createElement(_layout.default, {
    type: "export",
    footer: /*#__PURE__*/_react.default.createElement(_exportPluginsFooter.default, {
      isKitReady: isKitReady
    })
  }, /*#__PURE__*/_react.default.createElement("section", {
    className: "e-app-export-plugins"
  }, /*#__PURE__*/_react.default.createElement(_pageHeader.default, {
    heading: __('Export your site as a Website Kit', 'elementor'),
    description: __('Select which of these plugins are required for this kit work.', 'elementor')
  }), /*#__PURE__*/_react.default.createElement(_exportPluginsSelection.default, {
    onSelect: handleOnSelect
  })));
}

/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/export/export-process/export-process.js":
/*!********************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/export/export-process/export-process.js ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = ExportProcess;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _toConsumableArray2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/toConsumableArray */ "../node_modules/@babel/runtime/helpers/toConsumableArray.js"));
var _slicedToArray2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "../node_modules/@babel/runtime/helpers/slicedToArray.js"));
var _router = __webpack_require__(/*! @reach/router */ "../node_modules/@reach/router/es/index.js");
var _sharedContextProvider = __webpack_require__(/*! ../../../context/shared-context/shared-context-provider */ "../app/modules/import-export/assets/js/context/shared-context/shared-context-provider.js");
var _exportContextProvider = __webpack_require__(/*! ../../../context/export-context/export-context-provider */ "../app/modules/import-export/assets/js/context/export-context/export-context-provider.js");
var _layout = _interopRequireDefault(__webpack_require__(/*! ../../../templates/layout */ "../app/modules/import-export/assets/js/templates/layout.js"));
var _fileProcess = _interopRequireDefault(__webpack_require__(/*! ../../../shared/file-process/file-process */ "../app/modules/import-export/assets/js/shared/file-process/file-process.js"));
var _useKit2 = _interopRequireDefault(__webpack_require__(/*! ../../../hooks/use-kit */ "../app/modules/import-export/assets/js/hooks/use-kit.js"));
var _useExportPluginsData2 = _interopRequireDefault(__webpack_require__(/*! ./hooks/use-export-plugins-data */ "../app/modules/import-export/assets/js/pages/export/export-process/hooks/use-export-plugins-data.js"));
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function ExportProcess() {
  var sharedContext = (0, _react.useContext)(_sharedContextProvider.SharedContext),
    exportContext = (0, _react.useContext)(_exportContextProvider.ExportContext),
    navigate = (0, _router.useNavigate)(),
    _useKit = (0, _useKit2.default)(),
    kitState = _useKit.kitState,
    kitActions = _useKit.kitActions,
    KIT_STATUS_MAP = _useKit.KIT_STATUS_MAP,
    _useState = (0, _react.useState)(''),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    errorType = _useState2[0],
    setErrorType = _useState2[1],
    _ref = exportContext.data || {},
    plugins = _ref.plugins,
    exportedData = _ref.exportedData,
    kitInfo = _ref.kitInfo,
    isExportProcessStarted = _ref.isExportProcessStarted,
    _useExportPluginsData = (0, _useExportPluginsData2.default)(plugins),
    pluginsData = _useExportPluginsData.pluginsData,
    onDialogDismiss = function onDialogDismiss() {
      exportContext.dispatch({
        type: 'SET_DOWNLOAD_URL',
        payload: ''
      });
      navigate('export');
    },
    exportKit = function exportKit() {
      var _sharedContext$data = sharedContext.data,
        includes = _sharedContext$data.includes,
        selectedCustomPostTypes = _sharedContext$data.selectedCustomPostTypes;

      /*
      	Adding the plugins just before the export process begins for not mixing the kit-content selection with the plugins.
      	The plugins must be added to the includes items, otherwise they will not be exported.
      	The plugins should always be added in order to include the Core plugin data in the kit.
       */
      kitActions.export({
        include: [].concat((0, _toConsumableArray2.default)(includes), ['plugins']),
        kitInfo: kitInfo,
        plugins: pluginsData,
        selectedCustomPostTypes: selectedCustomPostTypes
      });
    };

  // On load.
  (0, _react.useEffect)(function () {
    if (isExportProcessStarted) {
      exportKit();
    } else {
      // When not starting from the main screen.
      navigate('/export');
    }
  }, []);

  // On kit status change.
  (0, _react.useEffect)(function () {
    switch (kitState.status) {
      case KIT_STATUS_MAP.EXPORTED:
        exportContext.dispatch({
          type: 'SET_EXPORTED_DATA',
          payload: kitState.data
        });
        break;
      case KIT_STATUS_MAP.ERROR:
        setErrorType(kitState.data);
        break;
    }
  }, [kitState.status]);

  // On process finished.
  (0, _react.useEffect)(function () {
    if (exportedData) {
      navigate('export/complete');
    }
  }, [exportedData]);
  return /*#__PURE__*/_react.default.createElement(_layout.default, {
    type: "export"
  }, /*#__PURE__*/_react.default.createElement(_fileProcess.default, {
    errorType: errorType,
    onDialogApprove: onDialogDismiss,
    onDialogDismiss: onDialogDismiss
  }));
}

/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/export/export-process/hooks/use-export-plugins-data.js":
/*!***********************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/export/export-process/hooks/use-export-plugins-data.js ***!
  \***********************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = useExportPluginsData;
var _react = __webpack_require__(/*! react */ "react");
function useExportPluginsData(plugins) {
  var getData = function getData() {
    var pluginsData = [];
    plugins.forEach(function (pluginData) {
      var name = pluginData.name,
        plugin = pluginData.plugin,
        pluginUri = pluginData.plugin_uri,
        version = pluginData.version;
      pluginsData.push({
        name: name,
        plugin: plugin,
        pluginUri: pluginUri,
        version: version
      });
    });
    return pluginsData;
  };
  return {
    pluginsData: (0, _react.useMemo)(function () {
      return getData();
    }, [plugins])
  };
}

/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/import/hooks/use-import-actions.js":
/*!***************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/import/hooks/use-import-actions.js ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = useImportActions;
var _react = __webpack_require__(/*! react */ "react");
var _router = __webpack_require__(/*! @reach/router */ "../node_modules/@reach/router/es/index.js");
var _sharedContextProvider = __webpack_require__(/*! ../../../context/shared-context/shared-context-provider */ "../app/modules/import-export/assets/js/context/shared-context/shared-context-provider.js");
var _useAction2 = _interopRequireDefault(__webpack_require__(/*! elementor-app/hooks/use-action */ "../app/assets/js/hooks/use-action.js"));
function useImportActions() {
  var sharedContext = (0, _react.useContext)(_sharedContextProvider.SharedContext),
    navigate = (0, _router.useNavigate)(),
    _useAction = (0, _useAction2.default)(),
    backToDashboard = _useAction.backToDashboard,
    isStartedFromKitLibrary = 'kit-library' === sharedContext.data.referrer,
    navigateToMainScreen = function navigateToMainScreen() {
      var url = isStartedFromKitLibrary ? '/kit-library' : '/import';
      navigate(url);
    },
    closeApp = function closeApp() {
      if (isStartedFromKitLibrary) {
        navigate('/kit-library');
      } else {
        backToDashboard();
      }
    };
  return {
    navigateToMainScreen: navigateToMainScreen,
    closeApp: closeApp
  };
}

/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/import/import-complete/components/connect-pro-notice/connect-pro-notice.js":
/*!*******************************************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/import/import-complete/components/connect-pro-notice/connect-pro-notice.js ***!
  \*******************************************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = ConnectProNotice;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _notice = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/notice */ "../app/assets/js/ui/molecules/notice.js"));
var _button = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/button */ "../app/assets/js/ui/molecules/button.js"));
__webpack_require__(/*! ./connect-pro-notice.scss */ "../app/modules/import-export/assets/js/pages/import/import-complete/components/connect-pro-notice/connect-pro-notice.scss");
function ConnectProNotice() {
  var getButton = function getButton() {
    return /*#__PURE__*/_react.default.createElement(_button.default, {
      text: __('Let’s do it', 'elementor'),
      variant: "outlined",
      color: "secondary",
      size: "sm",
      target: "_blank",
      url: elementorAppConfig.admin_url + 'admin.php?page=elementor-license'
    });
  };
  return /*#__PURE__*/_react.default.createElement(_notice.default, {
    className: "e-app-import-connect-pro-notice",
    label: __('Tip:', 'elementor'),
    color: "info",
    button: getButton()
  }, __('Make sure your Elementor Pro account is connected', 'elementor'));
}

/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/import/import-complete/components/failed-plugins-notice/failed-plugins-notice.js":
/*!*************************************************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/import/import-complete/components/failed-plugins-notice/failed-plugins-notice.js ***!
  \*************************************************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = FailedPluginsNotice;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _notice = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/notice */ "../app/assets/js/ui/molecules/notice.js"));
var _button = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/button */ "../app/assets/js/ui/molecules/button.js"));
__webpack_require__(/*! ./failed-plugins-notice.scss */ "../app/modules/import-export/assets/js/pages/import/import-complete/components/failed-plugins-notice/failed-plugins-notice.scss");
function FailedPluginsNotice(_ref) {
  var failedPlugins = _ref.failedPlugins;
  var getButton = function getButton() {
    return /*#__PURE__*/_react.default.createElement(_button.default, {
      text: __('Learn more', 'elementor'),
      variant: "outlined",
      color: "secondary",
      size: "sm",
      target: "_blank",
      url: "https://go.elementor.com/app-import-plugin-installation-failed/"
    });
  };
  return /*#__PURE__*/_react.default.createElement(_notice.default, {
    className: "e-app-import-failed-plugins-notice",
    label: __('Important:', 'elementor'),
    color: "warning",
    button: getButton()
  }, __("There are few plugins that we couldn't install:", 'elementor') + ' ' + failedPlugins.map(function (_ref2) {
    var name = _ref2.name;
    return name;
  }).join(' | '));
}
FailedPluginsNotice.propTypes = {
  failedPlugins: PropTypes.array
};

/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/import/import-complete/components/import-complete-footer/import-complete-footer.js":
/*!***************************************************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/import/import-complete/components/import-complete-footer/import-complete-footer.js ***!
  \***************************************************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = ImportCompleteFooter;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _actionsFooter = _interopRequireDefault(__webpack_require__(/*! ../../../../../shared/actions-footer/actions-footer */ "../app/modules/import-export/assets/js/shared/actions-footer/actions-footer.js"));
var _button = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/button */ "../app/assets/js/ui/molecules/button.js"));
var _useAction = _interopRequireDefault(__webpack_require__(/*! elementor-app/hooks/use-action */ "../app/assets/js/hooks/use-action.js"));
var _appsEventTracking = __webpack_require__(/*! elementor-app/event-track/apps-event-tracking */ "../app/assets/js/event-track/apps-event-tracking.js");
function ImportCompleteFooter(_ref) {
  var seeItLiveUrl = _ref.seeItLiveUrl,
    referrer = _ref.referrer;
  var action = (0, _useAction.default)(),
    eventTracking = function eventTracking(command) {
      var eventType = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'click';
      if ('kit-library' === referrer) {
        (0, _appsEventTracking.appsEventTrackingDispatch)(command, {
          page_source: 'kit is live',
          element_location: 'app_wizard_footer',
          event_type: eventType
        });
      }
    };
  return /*#__PURE__*/_react.default.createElement(_actionsFooter.default, null, seeItLiveUrl && /*#__PURE__*/_react.default.createElement(_button.default, {
    text: __('See it live', 'elementor'),
    variant: "contained",
    onClick: function onClick() {
      eventTracking('kit-library/see-it-live');
      window.open(seeItLiveUrl, '_blank');
    }
  }), /*#__PURE__*/_react.default.createElement(_button.default, {
    text: __('Close', 'elementor'),
    variant: "contained",
    color: "primary",
    onClick: function onClick() {
      eventTracking('kit-library/close');
      action.backToDashboard();
    }
  }));
}
ImportCompleteFooter.propTypes = {
  seeItLiveUrl: PropTypes.string,
  referrer: PropTypes.string
};

/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/import/import-complete/hooks/use-imported-kit-data.js":
/*!**********************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/import/import-complete/hooks/use-imported-kit-data.js ***!
  \**********************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = useImportedKitData;
var _usePlugins = __webpack_require__(/*! ../../../../hooks/use-plugins */ "../app/modules/import-export/assets/js/hooks/use-plugins.js");
function useImportedKitData() {
  var getTemplates = function getTemplates(templates, importedData) {
      var kitTemplates = {};
      for (var key in importedData === null || importedData === void 0 ? void 0 : (_importedData$templat = importedData.templates) === null || _importedData$templat === void 0 ? void 0 : _importedData$templat.succeed) {
        var _importedData$templat;
        kitTemplates[key] = templates[key];
      }
      return kitTemplates;
    },
    getContent = function getContent(content, importedData) {
      var kitContent = {};
      for (var contentType in importedData === null || importedData === void 0 ? void 0 : importedData.content) {
        kitContent[contentType] = {};
        for (var key in (_importedData$content = importedData.content[contentType]) === null || _importedData$content === void 0 ? void 0 : _importedData$content.succeed) {
          var _importedData$content;
          kitContent[contentType][key] = content[contentType][key];
        }
      }
      return kitContent;
    },
    getWPContent = function getWPContent(content, importedData) {
      var kitWPContent = {};
      for (var contentType in importedData === null || importedData === void 0 ? void 0 : importedData['wp-content']) {
        var _importedData$wpCont;
        var succeededItems = (_importedData$wpCont = importedData['wp-content'][contentType]) === null || _importedData$wpCont === void 0 ? void 0 : _importedData$wpCont.succeed;
        kitWPContent[contentType] = succeededItems ? Object.keys(succeededItems) : [];
      }
      return kitWPContent;
    },
    getPlugins = function getPlugins(importedPlugins) {
      var plugins = {
        activePlugins: [],
        failedPlugins: []
      };
      importedPlugins.forEach(function (plugin) {
        var group = _usePlugins.PLUGIN_STATUS_MAP.ACTIVE === plugin.status ? 'activePlugins' : 'failedPlugins';
        plugins[group].push(plugin);
      });
      return plugins;
    };
  return {
    getTemplates: getTemplates,
    getContent: getContent,
    getWPContent: getWPContent,
    getPlugins: getPlugins
  };
}

/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/import/import-complete/import-complete.js":
/*!**********************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/import/import-complete/import-complete.js ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = ImportComplete;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _router = __webpack_require__(/*! @reach/router */ "../node_modules/@reach/router/es/index.js");
var _sharedContextProvider = __webpack_require__(/*! ../../../context/shared-context/shared-context-provider */ "../app/modules/import-export/assets/js/context/shared-context/shared-context-provider.js");
var _importContextProvider = __webpack_require__(/*! ../../../context/import-context/import-context-provider */ "../app/modules/import-export/assets/js/context/import-context/import-context-provider.js");
var _layout = _interopRequireDefault(__webpack_require__(/*! ../../../templates/layout */ "../app/modules/import-export/assets/js/templates/layout.js"));
var _wizardStep = _interopRequireDefault(__webpack_require__(/*! ../../../ui/wizard-step/wizard-step */ "../app/modules/import-export/assets/js/ui/wizard-step/wizard-step.js"));
var _kitData = _interopRequireDefault(__webpack_require__(/*! ../../../shared/kit-data/kit-data */ "../app/modules/import-export/assets/js/shared/kit-data/kit-data.js"));
var _inlineLink = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/inline-link */ "../app/assets/js/ui/molecules/inline-link.js"));
var _failedPluginsNotice = _interopRequireDefault(__webpack_require__(/*! ./components/failed-plugins-notice/failed-plugins-notice */ "../app/modules/import-export/assets/js/pages/import/import-complete/components/failed-plugins-notice/failed-plugins-notice.js"));
var _connectProNotice = _interopRequireDefault(__webpack_require__(/*! ./components/connect-pro-notice/connect-pro-notice */ "../app/modules/import-export/assets/js/pages/import/import-complete/components/connect-pro-notice/connect-pro-notice.js"));
var _importCompleteFooter = _interopRequireDefault(__webpack_require__(/*! ./components/import-complete-footer/import-complete-footer */ "../app/modules/import-export/assets/js/pages/import/import-complete/components/import-complete-footer/import-complete-footer.js"));
var _appsEventTracking = __webpack_require__(/*! elementor-app/event-track/apps-event-tracking */ "../app/assets/js/event-track/apps-event-tracking.js");
var _useImportedKitData2 = _interopRequireDefault(__webpack_require__(/*! ./hooks/use-imported-kit-data */ "../app/modules/import-export/assets/js/pages/import/import-complete/hooks/use-imported-kit-data.js"));
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function ImportComplete() {
  var sharedContext = (0, _react.useContext)(_sharedContextProvider.SharedContext),
    importContext = (0, _react.useContext)(_importContextProvider.ImportContext),
    navigate = (0, _router.useNavigate)(),
    _ref = importContext.data || {},
    importedPlugins = _ref.importedPlugins,
    uploadedData = _ref.uploadedData,
    importedData = _ref.importedData,
    isProInstalledDuringProcess = _ref.isProInstalledDuringProcess,
    _ref2 = sharedContext.data || {},
    referrer = _ref2.referrer,
    _useImportedKitData = (0, _useImportedKitData2.default)(),
    getTemplates = _useImportedKitData.getTemplates,
    getContent = _useImportedKitData.getContent,
    getWPContent = _useImportedKitData.getWPContent,
    getPlugins = _useImportedKitData.getPlugins,
    _getPlugins = getPlugins(importedPlugins),
    activePlugins = _getPlugins.activePlugins,
    failedPlugins = _getPlugins.failedPlugins,
    _ref3 = (importedData === null || importedData === void 0 ? void 0 : importedData.configData) || {},
    elementorHomePageUrl = _ref3.elementorHomePageUrl,
    recentlyEditedElementorPageUrl = _ref3.recentlyEditedElementorPageUrl,
    seeItLiveUrl = elementorHomePageUrl || recentlyEditedElementorPageUrl || null,
    getKitData = function getKitData() {
      if (!uploadedData || !importedData) {
        return {};
      }
      var manifest = uploadedData.manifest;
      return {
        templates: getTemplates(manifest.templates, importedData),
        content: getContent(manifest.content, importedData),
        'wp-content': getWPContent(manifest['wp-content'], importedData),
        'site-settings': sharedContext.data.includes.includes('settings') ? manifest['site-settings'] : {},
        plugins: activePlugins,
        configData: importedData.configData
      };
    },
    eventTracking = function eventTracking(command, source) {
      var eventType = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 'click';
      var elementLocation = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : null;
      if ('kit-library' === referrer) {
        (0, _appsEventTracking.appsEventTrackingDispatch)(command, {
          page_source: source,
          event_type: eventType,
          element_location: elementLocation
        });
      }
    },
    kitData = (0, _react.useMemo)(function () {
      return getKitData();
    }, []);
  (0, _react.useEffect)(function () {
    if (!uploadedData) {
      navigate('/import');
    }
    if (uploadedData) {
      eventTracking('kit-library/kit-is-live-load', 'kit is live', 'load');
    }
    sharedContext.dispatch({
      type: 'SET_CURRENT_PAGE_NAME',
      payload: ImportComplete.name
    });
  }, []);
  return /*#__PURE__*/_react.default.createElement(_layout.default, {
    type: "import",
    footer: /*#__PURE__*/_react.default.createElement(_importCompleteFooter.default, {
      seeItLiveUrl: seeItLiveUrl,
      referrer: referrer
    })
  }, /*#__PURE__*/_react.default.createElement(_wizardStep.default, {
    image: elementorAppConfig.assets_url + 'images/go-pro.svg',
    heading: __('Your kit is now live on your site!', 'elementor'),
    description: __('You’ve imported and applied the following to your site:', 'elementor'),
    notice: /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement(_inlineLink.default, {
      url: "https://go.elementor.com/app-what-are-kits",
      italic: true,
      onClick: function onClick() {
        return eventTracking('kit-library/seek-more-info', 'kit is live', 'click', 'app_header');
      }
    }, __('Click here', 'elementor')), " ", __('to learn more about building your site with Elementor Kits', 'elementor'))
  }, !!failedPlugins.length && /*#__PURE__*/_react.default.createElement(_failedPluginsNotice.default, {
    failedPlugins: failedPlugins
  }), isProInstalledDuringProcess && /*#__PURE__*/_react.default.createElement(_connectProNotice.default, null), /*#__PURE__*/_react.default.createElement(_kitData.default, {
    data: kitData
  })));
}

/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/import/import-content/components/import-content-display/import-content-display.js":
/*!**************************************************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/import/import-content/components/import-content-display/import-content-display.js ***!
  \**************************************************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = ImportContentDisplay;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _kitContent = _interopRequireDefault(__webpack_require__(/*! ../../../../../shared/kit-content/kit-content */ "../app/modules/import-export/assets/js/shared/kit-content/kit-content.js"));
var _sharedContextProvider = __webpack_require__(/*! ../../../../../context/shared-context/shared-context-provider */ "../app/modules/import-export/assets/js/context/shared-context/shared-context-provider.js");
var _kitContentData = _interopRequireDefault(__webpack_require__(/*! ../../../../../shared/kit-content-data/kit-content-data */ "../app/modules/import-export/assets/js/shared/kit-content-data/kit-content-data.js"));
var _notice = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/notice */ "../app/assets/js/ui/molecules/notice.js"));
var _inlineLink = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/inline-link */ "../app/assets/js/ui/molecules/inline-link.js"));
var _cptObjectToOptionsArray = __webpack_require__(/*! ../../../../../shared/cpt-select-box/cpt-object-to-options-array */ "../app/modules/import-export/assets/js/shared/cpt-select-box/cpt-object-to-options-array.js");
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function ImportContentDisplay(_ref) {
  var manifest = _ref.manifest,
    hasPro = _ref.hasPro,
    hasPlugins = _ref.hasPlugins,
    isAllRequiredPluginsSelected = _ref.isAllRequiredPluginsSelected,
    onResetProcess = _ref.onResetProcess;
  var sharedContext = (0, _react.useContext)(_sharedContextProvider.SharedContext);
  // Getting the kit data from the manifest.
  var kitData = _kitContentData.default.filter(function (_ref2) {
    var type = _ref2.type;
    var contentType = 'settings' === type ? 'site-settings' : type,
      data = manifest === null || manifest === void 0 ? void 0 : manifest[contentType];
    return !!(Array.isArray(data) ? data.length : data);
  });
  (0, _react.useEffect)(function () {
    sharedContext.dispatch({
      type: 'SET_CPT',
      payload: (0, _cptObjectToOptionsArray.cptObjectToOptionsArray)(manifest === null || manifest === void 0 ? void 0 : manifest['custom-post-type-title'], 'label')
    });
  }, []);
  if (!kitData.length && hasPlugins) {
    return /*#__PURE__*/_react.default.createElement(_notice.default, {
      color: "info",
      label: __('Note:', 'elementor')
    }, __('The Website Kit you’re using contains plugins for functionality, but no content or pages, etc.', 'elementor'));
  }
  if (!kitData.length) {
    return /*#__PURE__*/_react.default.createElement(_notice.default, {
      color: "danger"
    }, __('You can’t use this Website Kit because it doesn’t contain any content, pages, etc. Try again with a different file.', 'elementor'), " ", /*#__PURE__*/_react.default.createElement(_inlineLink.default, {
      onClick: onResetProcess
    }, __('Go Back', 'elementor')));
  }
  return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, !isAllRequiredPluginsSelected && /*#__PURE__*/_react.default.createElement(_notice.default, {
    color: "warning",
    label: __('Required plugins are still missing.', 'elementor'),
    className: "e-app-import-content__plugins-notice"
  }, __("If you don't include them, this kit may not work properly.", 'elementor'), " ", /*#__PURE__*/_react.default.createElement(_inlineLink.default, {
    url: "/import/plugins"
  }, __('Go Back', 'elementor'))), /*#__PURE__*/_react.default.createElement(_kitContent.default, {
    contentData: kitData,
    hasPro: hasPro
  }));
}
ImportContentDisplay.propTypes = {
  manifest: PropTypes.object,
  hasPro: PropTypes.bool,
  hasPlugins: PropTypes.bool,
  isAllRequiredPluginsSelected: PropTypes.bool,
  onResetProcess: PropTypes.func
};

/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/import/import-content/components/import-content-footer/import-content-footer.js":
/*!************************************************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/import/import-content/components/import-content-footer/import-content-footer.js ***!
  \************************************************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = ImportContentFooter;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _router = __webpack_require__(/*! @reach/router */ "../node_modules/@reach/router/es/index.js");
var _actionsFooter = _interopRequireDefault(__webpack_require__(/*! ../../../../../shared/actions-footer/actions-footer */ "../app/modules/import-export/assets/js/shared/actions-footer/actions-footer.js"));
var _button = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/button */ "../app/assets/js/ui/molecules/button.js"));
function ImportContentFooter(_ref) {
  var hasPlugins = _ref.hasPlugins,
    hasConflicts = _ref.hasConflicts,
    isImportAllowed = _ref.isImportAllowed,
    onResetProcess = _ref.onResetProcess,
    onPreviousClick = _ref.onPreviousClick,
    onImportClick = _ref.onImportClick;
  var navigate = (0, _router.useNavigate)(),
    getNextPageUrl = function getNextPageUrl() {
      if (hasConflicts) {
        return 'import/resolver';
      } else if (hasPlugins) {
        return 'import/plugins-activation';
      }
      return 'import/process';
    };
  return /*#__PURE__*/_react.default.createElement(_actionsFooter.default, null, /*#__PURE__*/_react.default.createElement(_button.default, {
    text: __('Previous', 'elementor'),
    variant: "contained",
    onClick: function onClick() {
      onPreviousClick === null || onPreviousClick === void 0 ? void 0 : onPreviousClick();
      if (hasPlugins) {
        navigate('import/plugins/');
      } else {
        onResetProcess();
      }
    }
  }), /*#__PURE__*/_react.default.createElement(_button.default, {
    variant: "contained",
    text: __('Import', 'elementor'),
    color: isImportAllowed ? 'primary' : 'disabled',
    onClick: function onClick() {
      onImportClick === null || onImportClick === void 0 ? void 0 : onImportClick();
      return isImportAllowed && navigate(getNextPageUrl());
    }
  }));
}
ImportContentFooter.propTypes = {
  hasPlugins: PropTypes.bool,
  hasConflicts: PropTypes.bool,
  isImportAllowed: PropTypes.bool,
  onResetProcess: PropTypes.func.isRequired,
  onPreviousClick: PropTypes.func,
  onImportClick: PropTypes.func
};

/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/import/import-content/import-content.js":
/*!********************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/import/import-content/import-content.js ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = ImportContent;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _sharedContextProvider = __webpack_require__(/*! ../../../context/shared-context/shared-context-provider */ "../app/modules/import-export/assets/js/context/shared-context/shared-context-provider.js");
var _importContextProvider = __webpack_require__(/*! ../../../context/import-context/import-context-provider */ "../app/modules/import-export/assets/js/context/import-context/import-context-provider.js");
var _appsEventTracking = __webpack_require__(/*! elementor-app/event-track/apps-event-tracking */ "../app/assets/js/event-track/apps-event-tracking.js");
var _layout = _interopRequireDefault(__webpack_require__(/*! ../../../templates/layout */ "../app/modules/import-export/assets/js/templates/layout.js"));
var _pageHeader = _interopRequireDefault(__webpack_require__(/*! ../../../ui/page-header/page-header */ "../app/modules/import-export/assets/js/ui/page-header/page-header.js"));
var _importContentDisplay = _interopRequireDefault(__webpack_require__(/*! ./components/import-content-display/import-content-display */ "../app/modules/import-export/assets/js/pages/import/import-content/components/import-content-display/import-content-display.js"));
var _importContentFooter = _interopRequireDefault(__webpack_require__(/*! ./components/import-content-footer/import-content-footer */ "../app/modules/import-export/assets/js/pages/import/import-content/components/import-content-footer/import-content-footer.js"));
var _useImportActions2 = _interopRequireDefault(__webpack_require__(/*! ../hooks/use-import-actions */ "../app/modules/import-export/assets/js/pages/import/hooks/use-import-actions.js"));
__webpack_require__(/*! ./import-content.scss */ "../app/modules/import-export/assets/js/pages/import/import-content/import-content.scss");
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function ImportContent() {
  var sharedContext = (0, _react.useContext)(_sharedContextProvider.SharedContext),
    importContext = (0, _react.useContext)(_importContextProvider.ImportContext),
    _sharedContext$data = sharedContext.data,
    referrer = _sharedContext$data.referrer,
    includes = _sharedContext$data.includes,
    currentPage = _sharedContext$data.currentPage,
    _importContext$data = importContext.data,
    plugins = _importContext$data.plugins,
    requiredPlugins = _importContext$data.requiredPlugins,
    uploadedData = _importContext$data.uploadedData,
    file = _importContext$data.file,
    isProInstalledDuringProcess = _importContext$data.isProInstalledDuringProcess,
    _useImportActions = (0, _useImportActions2.default)(),
    navigateToMainScreen = _useImportActions.navigateToMainScreen,
    handleResetProcess = function handleResetProcess() {
      return importContext.dispatch({
        type: 'SET_FILE',
        payload: null
      });
    },
    eventTracking = function eventTracking(command) {
      if ('kit-library' === referrer) {
        (0, _appsEventTracking.appsEventTrackingDispatch)(command, {
          page_source: 'import',
          step: currentPage,
          event_type: 'click'
        });
      }
    },
    getFooter = function getFooter() {
      return /*#__PURE__*/_react.default.createElement(_importContentFooter.default, {
        hasPlugins: !!plugins.length,
        hasConflicts: !!(includes.includes('templates') && uploadedData !== null && uploadedData !== void 0 && uploadedData.conflicts && Object.keys(uploadedData.conflicts).length),
        isImportAllowed: !!(plugins.length || includes.length),
        onResetProcess: handleResetProcess,
        onPreviousClick: function onPreviousClick() {
          return eventTracking('kit-library/go-back');
        },
        onImportClick: function onImportClick() {
          return eventTracking('kit-library/approve-import');
        }
      });
    };
  (0, _react.useEffect)(function () {
    sharedContext.dispatch({
      type: 'SET_CURRENT_PAGE_NAME',
      payload: ImportContent.name
    });
  }, []);
  // On file change.
  (0, _react.useEffect)(function () {
    if (!file) {
      navigateToMainScreen();
    }
  }, [file]);
  return /*#__PURE__*/_react.default.createElement(_layout.default, {
    type: "import",
    footer: getFooter()
  }, /*#__PURE__*/_react.default.createElement("section", {
    className: "e-app-import-content"
  }, /*#__PURE__*/_react.default.createElement(_pageHeader.default, {
    heading: __('Select which parts you want to apply', 'elementor'),
    description: [__('These are the templates, content and site settings that come with your kit.', 'elementor'), __("All items are already selected by default. Uncheck the ones you don't want.", 'elementor')]
  }), /*#__PURE__*/_react.default.createElement(_importContentDisplay.default, {
    manifest: uploadedData === null || uploadedData === void 0 ? void 0 : uploadedData.manifest,
    hasPro: isProInstalledDuringProcess,
    hasPlugins: !!requiredPlugins.length,
    isAllRequiredPluginsSelected: requiredPlugins.length === plugins.length,
    onResetProcess: handleResetProcess
  })));
}

/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/import/import-kit/hooks/use-import-kit-library-apply-all-plugins.js":
/*!************************************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/import/import-kit/hooks/use-import-kit-library-apply-all-plugins.js ***!
  \************************************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.useImportKitLibraryApplyAllPlugins = useImportKitLibraryApplyAllPlugins;
var _slicedToArray2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "../node_modules/@babel/runtime/helpers/slicedToArray.js"));
var _react = __webpack_require__(/*! react */ "react");
var _usePlugins2 = _interopRequireDefault(__webpack_require__(/*! ../../../../hooks/use-plugins */ "../app/modules/import-export/assets/js/hooks/use-plugins.js"));
var _usePluginsData2 = _interopRequireDefault(__webpack_require__(/*! ../../../../hooks/use-plugins-data */ "../app/modules/import-export/assets/js/hooks/use-plugins-data.js"));
var _useImportPluginsData2 = _interopRequireDefault(__webpack_require__(/*! ../../import-plugins/hooks/use-import-plugins-data */ "../app/modules/import-export/assets/js/pages/import/import-plugins/hooks/use-import-plugins-data.js"));
function useImportKitLibraryApplyAllPlugins(plugins) {
  var _useState = (0, _react.useState)(),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    missingPlugins = _useState2[0],
    setMissingPlugins = _useState2[1],
    _usePlugins = (0, _usePlugins2.default)(),
    response = _usePlugins.response,
    _usePluginsData = (0, _usePluginsData2.default)(response.data),
    pluginsData = _usePluginsData.pluginsData,
    _useImportPluginsData = (0, _useImportPluginsData2.default)(plugins, pluginsData),
    importPluginsData = _useImportPluginsData.importPluginsData,
    _ref = importPluginsData || {},
    missing = _ref.missing;
  (0, _react.useEffect)(function () {
    if (plugins && !plugins.length) {
      return;
    }
    setMissingPlugins(missing);
  }, [plugins, missing]);
  return missingPlugins;
}

/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/import/import-kit/import-kit.js":
/*!************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/import/import-kit/import-kit.js ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = ImportKit;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _slicedToArray2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "../node_modules/@babel/runtime/helpers/slicedToArray.js"));
var _router = __webpack_require__(/*! @reach/router */ "../node_modules/@reach/router/es/index.js");
var _hooks = __webpack_require__(/*! @elementor/hooks */ "@elementor/hooks");
var _sharedContextProvider = __webpack_require__(/*! ../../../context/shared-context/shared-context-provider */ "../app/modules/import-export/assets/js/context/shared-context/shared-context-provider.js");
var _importContextProvider = __webpack_require__(/*! ../../../context/import-context/import-context-provider */ "../app/modules/import-export/assets/js/context/import-context/import-context-provider.js");
var _layout = _interopRequireDefault(__webpack_require__(/*! ../../../templates/layout */ "../app/modules/import-export/assets/js/templates/layout.js"));
var _pageHeader = _interopRequireDefault(__webpack_require__(/*! ../../../ui/page-header/page-header */ "../app/modules/import-export/assets/js/ui/page-header/page-header.js"));
var _processFailedDialog = _interopRequireDefault(__webpack_require__(/*! ../../../shared/process-failed-dialog/process-failed-dialog */ "../app/modules/import-export/assets/js/shared/process-failed-dialog/process-failed-dialog.js"));
var _inlineLink = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/inline-link */ "../app/assets/js/ui/molecules/inline-link.js"));
var _notice = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/notice */ "../app/assets/js/ui/molecules/notice.js"));
var _dropZone = _interopRequireDefault(__webpack_require__(/*! elementor-app/organisms/drop-zone */ "../app/assets/js/organisms/drop-zone.js"));
var _button = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/button */ "../app/assets/js/ui/molecules/button.js"));
var _appsEventTracking = __webpack_require__(/*! elementor-app/event-track/apps-event-tracking */ "../app/assets/js/event-track/apps-event-tracking.js");
var _dialog = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/dialog/dialog */ "../app/assets/js/ui/dialog/dialog.js"));
var _useKit2 = _interopRequireDefault(__webpack_require__(/*! ../../../hooks/use-kit */ "../app/modules/import-export/assets/js/hooks/use-kit.js"));
__webpack_require__(/*! ./import-kit.scss */ "../app/modules/import-export/assets/js/pages/import/import-kit/import-kit.scss");
var _checkbox = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/checkbox */ "../app/assets/js/ui/atoms/checkbox.js"));
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function ImportKit() {
  var sharedContext = (0, _react.useContext)(_sharedContextProvider.SharedContext),
    importContext = (0, _react.useContext)(_importContextProvider.ImportContext),
    navigate = (0, _router.useNavigate)(),
    _useKit = (0, _useKit2.default)(),
    kitState = _useKit.kitState,
    kitActions = _useKit.kitActions,
    KIT_STATUS_MAP = _useKit.KIT_STATUS_MAP,
    _useState = (0, _react.useState)(''),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    errorType = _useState2[0],
    setErrorType = _useState2[1],
    _useState3 = (0, _react.useState)(false),
    _useState4 = (0, _slicedToArray2.default)(_useState3, 2),
    isLoading = _useState4[0],
    setIsLoading = _useState4[1],
    _sharedContext$data = sharedContext.data,
    referrer = _sharedContext$data.referrer,
    currentPage = _sharedContext$data.currentPage,
    resetImportProcess = function resetImportProcess() {
      importContext.dispatch({
        type: 'SET_FILE',
        payload: null
      });
      setErrorType(null);
      setIsLoading(false);
      kitActions.reset();
    },
    eventTracking = function eventTracking(command) {
      var event = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
      var eventType = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 'click';
      var error = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : null;
      var modalType = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : null;
      var uploadMethod = arguments.length > 5 ? arguments[5] : undefined;
      if ('kit-library' === referrer) {
        var uploadMethodName = null;
        if (uploadMethod) {
          uploadMethodName = 'drop' === uploadMethod ? 'drag-drop' : 'browse';
        }
        var element = null;
        if (event && 'eps-button eps-dialog__button' === event.currentTarget.className.trim()) {
          element = 'close button';
        } else if (event && 'eps-button eps-dialog__close-button' === event.currentTarget.className.trim()) {
          element = 'x';
        }
        (0, _appsEventTracking.appsEventTrackingDispatch)(command, {
          element: element,
          page_source: 'import',
          event_type: eventType,
          step: currentPage,
          error: 'general' === error ? 'unknown' : error,
          modal_type: modalType,
          method: uploadMethodName
        });
      }
    },
    getLearnMoreLink = function getLearnMoreLink() {
      return /*#__PURE__*/_react.default.createElement(_inlineLink.default, {
        url: "https://go.elementor.com/app-what-are-kits",
        key: "learn-more-link",
        italic: true,
        onClick: function onClick() {
          return eventTracking('kit-library/seek-more-info', null, 'click');
        }
      }, __('Learn More', 'elementor'));
    },
    _useConfirmAction = (0, _hooks.useConfirmAction)({
      doNotShowAgainKey: 'upload_json_warning_generic_message',
      action: function action(file, e) {
        setIsLoading(true);
        importContext.dispatch({
          type: 'SET_FILE',
          payload: file
        });
        eventTracking('kit-library/file-upload', null, 'feedback', null, null, e.type);
      }
    }),
    uploadFile = _useConfirmAction.runAction,
    dialog = _useConfirmAction.dialog,
    checkbox = _useConfirmAction.checkbox;

  // On load.
  (0, _react.useEffect)(function () {
    sharedContext.dispatch({
      type: 'SET_INCLUDES',
      payload: []
    });
    sharedContext.dispatch({
      type: 'SET_CURRENT_PAGE_NAME',
      payload: ImportKit.name
    });
  }, []);

  // Uploading the kit after file is selected.
  (0, _react.useEffect)(function () {
    if (importContext.data.file) {
      kitActions.upload({
        file: importContext.data.file
      });
    }
  }, [importContext.data.file]);

  // Listening to kit upload state.
  (0, _react.useEffect)(function () {
    if (KIT_STATUS_MAP.UPLOADED === kitState.status) {
      importContext.dispatch({
        type: 'SET_UPLOADED_DATA',
        payload: kitState.data
      });
    } else if ('error' === kitState.status) {
      setErrorType(kitState.data);
    }
  }, [kitState.status]);

  // After kit was uploaded.
  (0, _react.useEffect)(function () {
    if (importContext.data.uploadedData && importContext.data.file) {
      var url = importContext.data.uploadedData.manifest.plugins ? '/import/plugins' : '/import/content';
      navigate(url);
    }
  }, [importContext.data.uploadedData]);
  return /*#__PURE__*/_react.default.createElement(_layout.default, {
    type: "import"
  }, /*#__PURE__*/_react.default.createElement("section", {
    className: "e-app-import"
  }, 'kit-library' === referrer && /*#__PURE__*/_react.default.createElement(_button.default, {
    className: "e-app-import__back-to-library",
    icon: "eicon-chevron-left",
    text: __('Back to Kit Library', 'elementor'),
    url: "/kit-library"
  }), /*#__PURE__*/_react.default.createElement(_pageHeader.default, {
    heading: __('Import a Website Kit', 'elementor'),
    description: [__('Upload a file with templates, site settings, content, etc., and apply them to your site automatically.', 'elementor'), getLearnMoreLink()]
  }), /*#__PURE__*/_react.default.createElement(_notice.default, {
    label: __('Important:', 'elementor'),
    color: "warning",
    className: "e-app-import__notice"
  }, __('We recommend that you backup your site before importing a kit file.', 'elementor')), /*#__PURE__*/_react.default.createElement(_dropZone.default, {
    className: "e-app-import__drop-zone",
    heading: __('Upload Files to Your Library', 'elementor'),
    text: __('Drag & drop the .zip file with your Kit', 'elementor'),
    secondaryText: __('Or', 'elementor'),
    filetypes: ['zip'],
    onFileChoose: function onFileChoose() {
      return eventTracking('kit-library/choose-file');
    },
    onFileSelect: uploadFile,
    onError: function onError() {
      return setErrorType('general');
    },
    isLoading: isLoading
  }), errorType && /*#__PURE__*/_react.default.createElement(_processFailedDialog.default, {
    errorType: errorType,
    onApprove: resetImportProcess,
    onModalClose: function onModalClose(event) {
      return eventTracking('kit-library/modal-close', event, 'load', null, 'error');
    },
    onError: function onError() {
      return eventTracking('kit-library/modal-open', null, 'load', errorType, 'error');
    },
    onLearnMore: function onLearnMore() {
      return eventTracking('kit-library/seek-more-info', null, 'click', null, 'error');
    }
  }), dialog.isOpen && /*#__PURE__*/_react.default.createElement(_dialog.default, {
    title: __('Warning: JSON or ZIP files may be unsafe', 'elementor'),
    text: __('Uploading JSON or ZIP files from unknown sources can be harmful and put your site at risk. For maximum safety, upload only JSON or ZIP files from trusted sources.', 'elementor'),
    approveButtonColor: "link",
    approveButtonText: __('Continue', 'elementor'),
    approveButtonOnClick: dialog.approve,
    dismissButtonText: __('Cancel', 'elementor'),
    dismissButtonOnClick: dialog.dismiss,
    onClose: dialog.dismiss
  }, /*#__PURE__*/_react.default.createElement("label", {
    htmlFor: "do-not-show-upload-json-warning-again",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '5px'
    }
  }, /*#__PURE__*/_react.default.createElement(_checkbox.default, {
    id: "do-not-show-upload-json-warning-again",
    type: "checkbox",
    value: checkbox.isChecked,
    onChange: function onChange(event) {
      return checkbox.setIsChecked(!!event.target.checked);
    }
  }), __('Do not show this message again', 'elementor')))));
}

/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/import/import-plugins-activation/components/plugin-status-item/plugin-status-item.js":
/*!*****************************************************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/import/import-plugins-activation/components/plugin-status-item/plugin-status-item.js ***!
  \*****************************************************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = PluginStatusItem;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _grid = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/grid/grid */ "../app/assets/js/ui/grid/grid.js"));
var _checkbox = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/checkbox */ "../app/assets/js/ui/atoms/checkbox.js"));
var _text = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/text */ "../app/assets/js/ui/atoms/text.js"));
var _usePlugins = __webpack_require__(/*! ../../../../../hooks/use-plugins */ "../app/modules/import-export/assets/js/hooks/use-plugins.js");
var ACTIVE = _usePlugins.PLUGIN_STATUS_MAP.ACTIVE,
  INACTIVE = _usePlugins.PLUGIN_STATUS_MAP.INACTIVE,
  NOT_INSTALLED = _usePlugins.PLUGIN_STATUS_MAP.NOT_INSTALLED;
function PluginStatusItem(_ref) {
  var name = _ref.name,
    status = _ref.status;
  if (NOT_INSTALLED === status) {
    return null;
  } else if (INACTIVE === status) {
    status = 'installed';
  } else if (ACTIVE === status) {
    status = 'activated';
  }
  return /*#__PURE__*/_react.default.createElement(_grid.default, {
    container: true,
    alignItems: "center",
    key: name
  }, /*#__PURE__*/_react.default.createElement(_checkbox.default, {
    rounded: true,
    checked: true,
    error: 'failed' === status || null,
    onChange: function onChange() {}
  }), /*#__PURE__*/_react.default.createElement(_text.default, {
    tag: "span",
    variant: "xs",
    className: "e-app-import-plugins-activation__plugin-name"
  }, name + ' ' + status));
}
PluginStatusItem.propTypes = {
  name: PropTypes.string.isRequired,
  status: PropTypes.string.isRequired
};

/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/import/import-plugins-activation/hooks/use-install-plugins.js":
/*!******************************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/import/import-plugins-activation/hooks/use-install-plugins.js ***!
  \******************************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.ACTION_STATUS_MAP = void 0;
exports["default"] = useInstallPlugins;
var _toConsumableArray2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/toConsumableArray */ "../node_modules/@babel/runtime/helpers/toConsumableArray.js"));
var _defineProperty2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "../node_modules/@babel/runtime/helpers/defineProperty.js"));
var _slicedToArray2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "../node_modules/@babel/runtime/helpers/slicedToArray.js"));
var _react = __webpack_require__(/*! react */ "react");
var _usePlugins2 = _interopRequireWildcard(__webpack_require__(/*! ../../../../hooks/use-plugins */ "../app/modules/import-export/assets/js/hooks/use-plugins.js"));
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { (0, _defineProperty2.default)(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
var ACTION_STATUS_MAP = Object.freeze({
  ACTIVATED: 'activated',
  INSTALLED: 'installed',
  FAILED: 'failed'
});
exports.ACTION_STATUS_MAP = ACTION_STATUS_MAP;
function useInstallPlugins(_ref) {
  var _ref$plugins = _ref.plugins,
    plugins = _ref$plugins === void 0 ? [] : _ref$plugins,
    _ref$bulkMaxItems = _ref.bulkMaxItems,
    bulkMaxItems = _ref$bulkMaxItems === void 0 ? 5 : _ref$bulkMaxItems;
  var _usePlugins = (0, _usePlugins2.default)(),
    response = _usePlugins.response,
    pluginsActions = _usePlugins.pluginsActions,
    _useState = (0, _react.useState)(false),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    isPluginsFetched = _useState2[0],
    setIsPluginsFetched = _useState2[1],
    _useState3 = (0, _react.useState)(false),
    _useState4 = (0, _slicedToArray2.default)(_useState3, 2),
    isDone = _useState4[0],
    setIsDone = _useState4[1],
    _useState5 = (0, _react.useState)([]),
    _useState6 = (0, _slicedToArray2.default)(_useState5, 2),
    bulk = _useState6[0],
    setBulk = _useState6[1],
    _useState7 = (0, _react.useState)([]),
    _useState8 = (0, _slicedToArray2.default)(_useState7, 2),
    ready = _useState8[0],
    setReady = _useState8[1],
    _useState9 = (0, _react.useState)(''),
    _useState10 = (0, _slicedToArray2.default)(_useState9, 2),
    actionStatus = _useState10[0],
    setActionStatus = _useState10[1],
    _useState11 = (0, _react.useState)(null),
    _useState12 = (0, _slicedToArray2.default)(_useState11, 2),
    currentPlugin = _useState12[0],
    setCurrentPlugin = _useState12[1],
    isError = _usePlugins2.PLUGINS_RESPONSE_MAP.ERROR === response.status,
    getBulk = function getBulk() {
      if (bulk.length > bulkMaxItems) {
        // Getting a bulk for display, when needed to display only X plugins data that are in process.
        return bulk.slice(bulk.length - bulkMaxItems, bulk.length);
      }
      return bulk;
    };

  // Setting the next plugin to activate/install and checking when all plugins ar ready.
  (0, _react.useEffect)(function () {
    if (plugins.length) {
      if (ready.length === plugins.length) {
        setIsDone(true);
      } else if (isPluginsFetched) {
        var nextPluginToInstallIndex = ready.length;
        setCurrentPlugin(plugins[nextPluginToInstallIndex]);
      }
    }
  }, [ready, isPluginsFetched]);

  // Activating/installing the current plugin.
  (0, _react.useEffect)(function () {
    if (currentPlugin) {
      var runAction = _usePlugins2.PLUGIN_STATUS_MAP.INACTIVE === currentPlugin.status ? pluginsActions.activate : pluginsActions.install;
      runAction(currentPlugin.plugin);
    }
  }, [currentPlugin]);

  // Status Updater.
  (0, _react.useEffect)(function () {
    if (_usePlugins2.PLUGINS_RESPONSE_MAP.SUCCESS === response.status) {
      var data = response.data;
      if (Array.isArray(data)) {
        // When the data type is an Array it means that the plugins data was fetched.
        setIsPluginsFetched(true);
      } else if (!Object.prototype.hasOwnProperty.call(data, 'plugin')) {
        setActionStatus(ACTION_STATUS_MAP.FAILED);
      } else if (_usePlugins2.PLUGIN_STATUS_MAP.ACTIVE === data.status) {
        setActionStatus(ACTION_STATUS_MAP.ACTIVATED);
      } else if (_usePlugins2.PLUGIN_STATUS_MAP.INACTIVE === data.status) {
        setActionStatus(ACTION_STATUS_MAP.INSTALLED);
      }
    } else if (_usePlugins2.PLUGINS_RESPONSE_MAP.ERROR === response.status) {
      setActionStatus(ACTION_STATUS_MAP.FAILED);
    }
  }, [response.status]);

  // Actions after data response.
  (0, _react.useEffect)(function () {
    if (actionStatus) {
      var pluginData = ACTION_STATUS_MAP.FAILED === actionStatus ? _objectSpread(_objectSpread({}, currentPlugin), {}, {
        status: ACTION_STATUS_MAP.FAILED
      }) : response.data;

      // Updating the current plugin status in the bulk.
      setBulk(function (prevState) {
        var processedPlugins = (0, _toConsumableArray2.default)(prevState);
        processedPlugins[ready.length] = pluginData;
        return processedPlugins;
      });
      if (ACTION_STATUS_MAP.ACTIVATED === actionStatus || ACTION_STATUS_MAP.FAILED === actionStatus) {
        // After the plugin process was finished.
        setReady(function (prevState) {
          return [].concat((0, _toConsumableArray2.default)(prevState), [pluginData]);
        });
      } else if (ACTION_STATUS_MAP.INSTALLED === actionStatus) {
        // In case that the widget was installed it will be inactive after the installation and therefore should be activated manually.
        setCurrentPlugin(pluginData);
      }

      // Reset the actionStatus value for the next iteration.
      setActionStatus('');
    }
  }, [actionStatus]);
  return {
    isDone: isDone,
    ready: ready,
    bulk: (0, _react.useMemo)(function () {
      return getBulk();
    }, [bulk]),
    isError: isError
  };
}

/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/import/import-plugins-activation/import-plugins-activation.js":
/*!******************************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/import/import-plugins-activation/import-plugins-activation.js ***!
  \******************************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = ImportPluginsActivation;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _router = __webpack_require__(/*! @reach/router */ "../node_modules/@reach/router/es/index.js");
var _importContextProvider = __webpack_require__(/*! ../../../context/import-context/import-context-provider */ "../app/modules/import-export/assets/js/context/import-context/import-context-provider.js");
var _sharedContextProvider = __webpack_require__(/*! ../../../context/shared-context/shared-context-provider */ "../app/modules/import-export/assets/js/context/shared-context/shared-context-provider.js");
var _layout = _interopRequireDefault(__webpack_require__(/*! ../../../templates/layout */ "../app/modules/import-export/assets/js/templates/layout.js"));
var _fileProcess = _interopRequireDefault(__webpack_require__(/*! ../../../shared/file-process/file-process */ "../app/modules/import-export/assets/js/shared/file-process/file-process.js"));
var _pluginStatusItem = _interopRequireDefault(__webpack_require__(/*! ./components/plugin-status-item/plugin-status-item */ "../app/modules/import-export/assets/js/pages/import/import-plugins-activation/components/plugin-status-item/plugin-status-item.js"));
var _grid = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/grid/grid */ "../app/assets/js/ui/grid/grid.js"));
var _list = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/list */ "../app/assets/js/ui/molecules/list.js"));
__webpack_require__(/*! ./import-plugins-activation.scss */ "../app/modules/import-export/assets/js/pages/import/import-plugins-activation/import-plugins-activation.scss");
var _useInstallPlugins2 = _interopRequireDefault(__webpack_require__(/*! ./hooks/use-install-plugins */ "../app/modules/import-export/assets/js/pages/import/import-plugins-activation/hooks/use-install-plugins.js"));
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function ImportPluginsActivation() {
  var importContext = (0, _react.useContext)(_importContextProvider.ImportContext),
    sharedContext = (0, _react.useContext)(_sharedContextProvider.SharedContext),
    navigate = (0, _router.useNavigate)(),
    _useInstallPlugins = (0, _useInstallPlugins2.default)({
      plugins: importContext.data.plugins
    }),
    bulk = _useInstallPlugins.bulk,
    ready = _useInstallPlugins.ready,
    isDone = _useInstallPlugins.isDone;

  // In case there are no plugins to import.
  (0, _react.useEffect)(function () {
    if (!importContext.data.plugins.length) {
      navigate('/import/');
    }
  }, [importContext.data.plugins]);

  // When import plugins process is done.
  (0, _react.useEffect)(function () {
    if (isDone) {
      importContext.dispatch({
        type: 'SET_IMPORTED_PLUGINS',
        payload: ready
      });
      importContext.dispatch({
        type: 'SET_PLUGINS_STATE',
        payload: 'success'
      });
      sharedContext.dispatch({
        type: 'SET_CURRENT_PAGE_NAME',
        payload: ImportPluginsActivation.name
      });
    }
  }, [isDone]);

  // Once the imported plugins data was updated.
  (0, _react.useEffect)(function () {
    if (importContext.data.importedPlugins.length) {
      navigate('/import/process');
    }
  }, [importContext.data.importedPlugins]);
  return /*#__PURE__*/_react.default.createElement(_layout.default, {
    type: "import"
  }, /*#__PURE__*/_react.default.createElement("section", {
    className: "e-app-import-plugins-activation"
  }, /*#__PURE__*/_react.default.createElement(_fileProcess.default, {
    info: __('Activating plugins:', 'elementor')
  }), /*#__PURE__*/_react.default.createElement(_grid.default, {
    container: true,
    justify: "center"
  }, /*#__PURE__*/_react.default.createElement(_grid.default, {
    item: true,
    className: "e-app-import-plugins-activation__installing-plugins"
  }, !!(bulk !== null && bulk !== void 0 && bulk.length) && /*#__PURE__*/_react.default.createElement(_list.default, null, bulk.map(function (plugin) {
    return /*#__PURE__*/_react.default.createElement(_list.default.Item, {
      className: "e-app-import-plugins-activation__plugin-status-item",
      key: plugin.name
    }, /*#__PURE__*/_react.default.createElement(_pluginStatusItem.default, {
      name: plugin.name,
      status: plugin.status
    }));
  }))))));
}

/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/import/import-plugins/components/existing-plugins/existing-plugins.js":
/*!**************************************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/import/import-plugins/components/existing-plugins/existing-plugins.js ***!
  \**************************************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = ExistingPlugins;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _pluginsSelection = _interopRequireDefault(__webpack_require__(/*! ../../../../../shared/plugins-selection/plugins-selection */ "../app/modules/import-export/assets/js/shared/plugins-selection/plugins-selection.js"));
var _heading = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/heading */ "../app/assets/js/ui/atoms/heading.js"));
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
var layout = [4, 1];
function ExistingPlugins(_ref) {
  var plugins = _ref.plugins;
  if (!(plugins !== null && plugins !== void 0 && plugins.length)) {
    return null;
  }

  // eslint-disable-next-line react-hooks/rules-of-hooks
  var existingPlugins = (0, _react.useMemo)(function () {
      return plugins;
    }, []),
    // eslint-disable-next-line react-hooks/rules-of-hooks
    initialSelected = (0, _react.useMemo)(function () {
      return plugins.map(function (plugin, index) {
        return index;
      });
    }, []);
  return /*#__PURE__*/_react.default.createElement("div", {
    className: "e-app-import-plugins__section"
  }, /*#__PURE__*/_react.default.createElement(_heading.default, {
    variant: "h5",
    tag: "h3",
    className: "e-app-import-plugins__section-heading"
  }, __('Plugins you already have:', 'elementor')), /*#__PURE__*/_react.default.createElement(_pluginsSelection.default, {
    withHeader: false,
    withStatus: false,
    plugins: existingPlugins,
    initialSelected: initialSelected,
    initialDisabled: initialSelected,
    excludeSelections: initialSelected,
    layout: layout
  }));
}
ExistingPlugins.propTypes = {
  plugins: PropTypes.array
};

/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/import/import-plugins/components/import-plugins-footer/import-plugins-footer.js":
/*!************************************************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/import/import-plugins/components/import-plugins-footer/import-plugins-footer.js ***!
  \************************************************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = ImportPluginsFooter;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _importContextProvider = __webpack_require__(/*! ../../../../../context/import-context/import-context-provider */ "../app/modules/import-export/assets/js/context/import-context/import-context-provider.js");
var _actionsFooter = _interopRequireDefault(__webpack_require__(/*! ../../../../../shared/actions-footer/actions-footer */ "../app/modules/import-export/assets/js/shared/actions-footer/actions-footer.js"));
var _button = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/button */ "../app/assets/js/ui/molecules/button.js"));
var _useImportActions2 = _interopRequireDefault(__webpack_require__(/*! ../../../hooks/use-import-actions */ "../app/modules/import-export/assets/js/pages/import/hooks/use-import-actions.js"));
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function ImportPluginsFooter(props) {
  var importContext = (0, _react.useContext)(_importContextProvider.ImportContext),
    _useImportActions = (0, _useImportActions2.default)(),
    navigateToMainScreen = _useImportActions.navigateToMainScreen;
  return /*#__PURE__*/_react.default.createElement(_actionsFooter.default, null, /*#__PURE__*/_react.default.createElement(_button.default, {
    text: __('Previous', 'elementor'),
    variant: "contained",
    onClick: function onClick() {
      var _props$onPreviousClic;
      importContext.dispatch({
        type: 'SET_FILE',
        payload: null
      });
      (_props$onPreviousClic = props.onPreviousClick) === null || _props$onPreviousClic === void 0 ? void 0 : _props$onPreviousClic.call(props);
      navigateToMainScreen();
    }
  }), /*#__PURE__*/_react.default.createElement(_button.default, {
    variant: "contained",
    text: __('Next', 'elementor'),
    color: "primary",
    url: "/import/content",
    onClick: function onClick() {
      var _props$onNextClick;
      (_props$onNextClick = props.onNextClick) === null || _props$onNextClick === void 0 ? void 0 : _props$onNextClick.call(props);
    }
  }));
}
ImportPluginsFooter.propTypes = {
  onPreviousClick: PropTypes.func,
  onNextClick: PropTypes.func
};

/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/import/import-plugins/components/plugins-to-import/plugins-to-import.js":
/*!****************************************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/import/import-plugins/components/plugins-to-import/plugins-to-import.js ***!
  \****************************************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = PluginsToImport;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _importContextProvider = __webpack_require__(/*! ../../../../../context/import-context/import-context-provider */ "../app/modules/import-export/assets/js/context/import-context/import-context-provider.js");
var _pluginsSelection = _interopRequireDefault(__webpack_require__(/*! ../../../../../shared/plugins-selection/plugins-selection */ "../app/modules/import-export/assets/js/shared/plugins-selection/plugins-selection.js"));
var _heading = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/heading */ "../app/assets/js/ui/atoms/heading.js"));
var _usePlugins = __webpack_require__(/*! ../../../../../hooks/use-plugins */ "../app/modules/import-export/assets/js/hooks/use-plugins.js");
var _usePluginsData = __webpack_require__(/*! ../../../../../hooks/use-plugins-data */ "../app/modules/import-export/assets/js/hooks/use-plugins-data.js");
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
var layout = [3, 1, 1];
function PluginsToImport(_ref) {
  var plugins = _ref.plugins;
  if (!(plugins !== null && plugins !== void 0 && plugins.length)) {
    return null;
  }

  // eslint-disable-next-line react-hooks/rules-of-hooks
  var importContext = (0, _react.useContext)(_importContextProvider.ImportContext),
    getPluginsToImport = function getPluginsToImport() {
      var _plugins$ = plugins[0],
        name = _plugins$.name,
        status = _plugins$.status;

      // If Elementor Pro is the first plugin and is not inactive, it should not be displayed.
      if (_usePluginsData.PLUGINS_KEYS.ELEMENTOR_PRO === name && _usePlugins.PLUGIN_STATUS_MAP.INACTIVE !== status) {
        return plugins.splice(1);
      }
      return plugins;
    },
    // eslint-disable-next-line react-hooks/rules-of-hooks
    handleOnSelect = (0, _react.useCallback)(function (selectedPlugins) {
      return importContext.dispatch({
        type: 'SET_PLUGINS',
        payload: selectedPlugins
      });
    }, []),
    // eslint-disable-next-line react-hooks/rules-of-hooks
    pluginsToImport = (0, _react.useMemo)(function () {
      return getPluginsToImport();
    }, [plugins]),
    // eslint-disable-next-line react-hooks/rules-of-hooks
    initialSelected = (0, _react.useMemo)(function () {
      return pluginsToImport.map(function (plugin, index) {
        return index;
      });
    }, [plugins]),
    isAllRequiredPluginsSelected = pluginsToImport.length === importContext.data.plugins.length;
  if (!pluginsToImport.length) {
    return null;
  }
  return /*#__PURE__*/_react.default.createElement("div", {
    className: "e-app-import-plugins__section"
  }, /*#__PURE__*/_react.default.createElement(_heading.default, {
    variant: "h5",
    tag: "h3",
    className: "e-app-import-plugins__section-heading"
  }, isAllRequiredPluginsSelected ? __('Plugins to add:', 'elementor') : __('Missing Required Plugins:', 'elementor')), /*#__PURE__*/_react.default.createElement(_pluginsSelection.default, {
    plugins: pluginsToImport,
    initialSelected: initialSelected,
    onSelect: handleOnSelect,
    layout: layout
  }));
}
PluginsToImport.propTypes = {
  plugins: PropTypes.array
};

/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/import/import-plugins/components/pro-banner/pro-banner.js":
/*!**************************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/import/import-plugins/components/pro-banner/pro-banner.js ***!
  \**************************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = ProBanner;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _slicedToArray2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "../node_modules/@babel/runtime/helpers/slicedToArray.js"));
var _messageBanner = _interopRequireDefault(__webpack_require__(/*! ../../../../../ui/message-banner/message-banner */ "../app/modules/import-export/assets/js/ui/message-banner/message-banner.js"));
var _goProButton = _interopRequireDefault(__webpack_require__(/*! elementor-app/molecules/go-pro-button */ "../app/assets/js/molecules/go-pro-button.js"));
var _dialog = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/dialog/dialog */ "../app/assets/js/ui/dialog/dialog.js"));
__webpack_require__(/*! ./pro-banner.scss */ "../app/modules/import-export/assets/js/pages/import/import-plugins/components/pro-banner/pro-banner.scss");
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function ProBanner(_ref) {
  var onRefresh = _ref.onRefresh;
  var _useState = (0, _react.useState)(false),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    showInfoDialog = _useState2[0],
    setShowInfoDialog = _useState2[1],
    openGoProExternalPage = function openGoProExternalPage() {
      return window.open('https://go.elementor.com/go-pro-import-export/', '_blank');
    },
    onDialogDismiss = function onDialogDismiss() {
      return setShowInfoDialog(false);
    },
    onDialogApprove = function onDialogApprove() {
      setShowInfoDialog(false);
      onRefresh();
    },
    handleGoPro = function handleGoPro() {
      setShowInfoDialog(true);
      openGoProExternalPage();
    };
  return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement(_messageBanner.default, {
    heading: __('Install Elementor Pro', 'elementor'),
    description: __("Without Elementor Pro, importing components like templates, widgets and popups won't work.", 'elementor'),
    button: /*#__PURE__*/_react.default.createElement(_goProButton.default, {
      onClick: handleGoPro
    })
  }), showInfoDialog && /*#__PURE__*/_react.default.createElement(_dialog.default, {
    title: __('Is your Elementor Pro ready?', 'elementor'),
    text: __('If you’ve purchased, installed & activated Elementor Pro, we can continue importing all the parts of this site.', 'elementor'),
    approveButtonColor: "primary",
    approveButtonText: __('Yes', 'elementor'),
    approveButtonOnClick: onDialogApprove,
    dismissButtonText: __('Not yet', 'elementor'),
    dismissButtonOnClick: onDialogDismiss,
    onClose: onDialogDismiss
  }));
}
ProBanner.propTypes = {
  status: PropTypes.string,
  onRefresh: PropTypes.func
};
ProBanner.defaultProps = {
  status: ''
};

/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/import/import-plugins/hooks/use-import-plugins-data.js":
/*!***********************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/import/import-plugins/hooks/use-import-plugins-data.js ***!
  \***********************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = useImportPluginsData;
var _defineProperty2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "../node_modules/@babel/runtime/helpers/defineProperty.js"));
var _react = __webpack_require__(/*! react */ "react");
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
var _usePlugins = __webpack_require__(/*! ../../../../hooks/use-plugins */ "../app/modules/import-export/assets/js/hooks/use-plugins.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { (0, _defineProperty2.default)(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
var MISSING_PLUGINS_KEY = 'missing',
  EXISTING_PLUGINS_KEY = 'existing',
  ELEMENTOR_PRO_PLUGIN_KEY = 'Elementor Pro';
function useImportPluginsData(pluginsToInstall, existingPlugins) {
  var getIsMinVersionExist = function getIsMinVersionExist(installedPluginVersion, kitPluginVersion) {
      return installedPluginVersion.localeCompare(kitPluginVersion) > -1;
    },
    getClassifiedPlugins = function getClassifiedPlugins() {
      var data = {
          missing: [],
          existing: [],
          minVersionMissing: [],
          proData: null
        },
        installedPluginsMap = (0, _utils.arrayToObjectByKey)(existingPlugins, 'name');
      pluginsToInstall.forEach(function (plugin) {
        var installedPluginData = installedPluginsMap[plugin.name],
          group = _usePlugins.PLUGIN_STATUS_MAP.ACTIVE === (installedPluginData === null || installedPluginData === void 0 ? void 0 : installedPluginData.status) ? EXISTING_PLUGINS_KEY : MISSING_PLUGINS_KEY,
          pluginData = installedPluginData || _objectSpread(_objectSpread({}, plugin), {}, {
            status: _usePlugins.PLUGIN_STATUS_MAP.NOT_INSTALLED
          });

        // Verifying that the current installed plugin version is not older than the kit plugin version.
        if (installedPluginData && !getIsMinVersionExist(installedPluginData.version, plugin.version)) {
          data.minVersionMissing.push(plugin);
        }

        // In case that the Pro plugin exist saving the data separately for easily knowing if the pro exist or not.
        if (ELEMENTOR_PRO_PLUGIN_KEY === pluginData.name) {
          data.proData = pluginData;
        }
        data[group].push(pluginData);
      });
      return data;
    },
    classifiedPlugins = (0, _react.useMemo)(function () {
      return getClassifiedPlugins();
    }, [pluginsToInstall, existingPlugins]);
  return {
    importPluginsData: pluginsToInstall.length && existingPlugins.length ? classifiedPlugins : null
  };
}

/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/import/import-plugins/import-plugins.js":
/*!********************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/import/import-plugins/import-plugins.js ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = ImportPlugins;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _router = __webpack_require__(/*! @reach/router */ "../node_modules/@reach/router/es/index.js");
var _importContextProvider = __webpack_require__(/*! ../../../context/import-context/import-context-provider */ "../app/modules/import-export/assets/js/context/import-context/import-context-provider.js");
var _sharedContextProvider = __webpack_require__(/*! ../../../context/shared-context/shared-context-provider */ "../app/modules/import-export/assets/js/context/shared-context/shared-context-provider.js");
var _layout = _interopRequireDefault(__webpack_require__(/*! ../../../templates/layout */ "../app/modules/import-export/assets/js/templates/layout.js"));
var _pageHeader = _interopRequireDefault(__webpack_require__(/*! ../../../ui/page-header/page-header */ "../app/modules/import-export/assets/js/ui/page-header/page-header.js"));
var _pluginsToImport = _interopRequireDefault(__webpack_require__(/*! ./components/plugins-to-import/plugins-to-import */ "../app/modules/import-export/assets/js/pages/import/import-plugins/components/plugins-to-import/plugins-to-import.js"));
var _existingPlugins = _interopRequireDefault(__webpack_require__(/*! ./components/existing-plugins/existing-plugins */ "../app/modules/import-export/assets/js/pages/import/import-plugins/components/existing-plugins/existing-plugins.js"));
var _proBanner = _interopRequireDefault(__webpack_require__(/*! ./components/pro-banner/pro-banner */ "../app/modules/import-export/assets/js/pages/import/import-plugins/components/pro-banner/pro-banner.js"));
var _importPluginsFooter = _interopRequireDefault(__webpack_require__(/*! ./components/import-plugins-footer/import-plugins-footer */ "../app/modules/import-export/assets/js/pages/import/import-plugins/components/import-plugins-footer/import-plugins-footer.js"));
var _loader = _interopRequireDefault(__webpack_require__(/*! ../../../ui/loader/loader */ "../app/modules/import-export/assets/js/ui/loader/loader.js"));
var _notice = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/notice */ "../app/assets/js/ui/molecules/notice.js"));
var _inlineLink = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/inline-link */ "../app/assets/js/ui/molecules/inline-link.js"));
var _usePlugins2 = _interopRequireWildcard(__webpack_require__(/*! ../../../hooks/use-plugins */ "../app/modules/import-export/assets/js/hooks/use-plugins.js"));
var _usePluginsData2 = _interopRequireDefault(__webpack_require__(/*! ../../../hooks/use-plugins-data */ "../app/modules/import-export/assets/js/hooks/use-plugins-data.js"));
var _useImportPluginsData2 = _interopRequireDefault(__webpack_require__(/*! ./hooks/use-import-plugins-data */ "../app/modules/import-export/assets/js/pages/import/import-plugins/hooks/use-import-plugins-data.js"));
var _appsEventTracking = __webpack_require__(/*! elementor-app/event-track/apps-event-tracking */ "../app/assets/js/event-track/apps-event-tracking.js");
__webpack_require__(/*! ./import-plugins.scss */ "../app/modules/import-export/assets/js/pages/import/import-plugins/import-plugins.scss");
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function ImportPlugins() {
  var _importContext$data$u, _importContext$data$u2;
  var importContext = (0, _react.useContext)(_importContextProvider.ImportContext),
    sharedContext = (0, _react.useContext)(_sharedContextProvider.SharedContext),
    navigate = (0, _router.useNavigate)(),
    kitPlugins = ((_importContext$data$u = importContext.data.uploadedData) === null || _importContext$data$u === void 0 ? void 0 : (_importContext$data$u2 = _importContext$data$u.manifest) === null || _importContext$data$u2 === void 0 ? void 0 : _importContext$data$u2.plugins) || [],
    _usePlugins = (0, _usePlugins2.default)(),
    response = _usePlugins.response,
    pluginsActions = _usePlugins.pluginsActions,
    _usePluginsData = (0, _usePluginsData2.default)(response.data),
    pluginsData = _usePluginsData.pluginsData,
    _useImportPluginsData = (0, _useImportPluginsData2.default)(kitPlugins, pluginsData),
    importPluginsData = _useImportPluginsData.importPluginsData,
    _ref = importPluginsData || {},
    missing = _ref.missing,
    existing = _ref.existing,
    minVersionMissing = _ref.minVersionMissing,
    proData = _ref.proData,
    _ref2 = sharedContext.data || {},
    referrer = _ref2.referrer,
    currentPage = _ref2.currentPage,
    handleRequiredPlugins = function handleRequiredPlugins() {
      if (missing.length) {
        // Saving globally the plugins data that the kit requires in order to work properly.
        importContext.dispatch({
          type: 'SET_REQUIRED_PLUGINS',
          payload: missing
        });
      }
    },
    handleRefresh = function handleRefresh() {
      importContext.dispatch({
        type: 'SET_REQUIRED_PLUGINS',
        payload: []
      });
      pluginsActions.fetch();
    },
    handleProInstallationStatus = function handleProInstallationStatus() {
      // In case that the Pro data is now exist but initially in the elementorAppConfig the value was false, it means that the pro was added during the process.
      if (proData && !elementorAppConfig.hasPro) {
        importContext.dispatch({
          type: 'SET_IS_PRO_INSTALLED_DURING_PROCESS',
          payload: true
        });
      }
    },
    eventTracking = function eventTracking(command) {
      if ('kit-library' === referrer) {
        (0, _appsEventTracking.appsEventTrackingDispatch)(command, {
          page_source: 'import',
          step: currentPage,
          event_type: 'click'
        });
      }
    };

  // On load.
  (0, _react.useEffect)(function () {
    if (!kitPlugins.length) {
      navigate('import/content');
    }
    sharedContext.dispatch({
      type: 'SET_CURRENT_PAGE_NAME',
      payload: ImportPlugins.name
    });
  }, []);

  // On plugins data ready.
  (0, _react.useEffect)(function () {
    if (importPluginsData && !importContext.data.requiredPlugins.length) {
      // Saving the required plugins to display them on the next screens.
      handleRequiredPlugins();

      // In case that the pro was installed in the middle of the process, the global state should be updated with the current status.
      handleProInstallationStatus();
    }
  }, [importPluginsData]);
  return /*#__PURE__*/_react.default.createElement(_layout.default, {
    type: "import",
    footer: /*#__PURE__*/_react.default.createElement(_importPluginsFooter.default, {
      onPreviousClick: function onPreviousClick() {
        return eventTracking('kit-library/go-back');
      },
      onNextClick: function onNextClick() {
        return eventTracking('kit-library/approve-selection');
      }
    })
  }, /*#__PURE__*/_react.default.createElement("section", {
    className: "e-app-import-plugins"
  }, !importPluginsData && /*#__PURE__*/_react.default.createElement(_loader.default, {
    absoluteCenter: true
  }), /*#__PURE__*/_react.default.createElement(_pageHeader.default, {
    heading: __('Select the plugins you want to import', 'elementor'),
    description: __('These are the plugins that powers up your kit. You can deselect them, but it can impact the functionality of your site.', 'elementor')
  }), !!(minVersionMissing !== null && minVersionMissing !== void 0 && minVersionMissing.length) && /*#__PURE__*/_react.default.createElement(_notice.default, {
    label: __(' Recommended:', 'elementor'),
    className: "e-app-import-plugins__versions-notice",
    color: "warning"
  }, __('Head over to Updates and make sure that your plugins are updated to the latest version.', 'elementor'), " ", /*#__PURE__*/_react.default.createElement(_inlineLink.default, {
    url: elementorAppConfig.admin_url + 'update-core.php'
  }, __('Take me there', 'elementor'))), _usePlugins2.PLUGIN_STATUS_MAP.NOT_INSTALLED === (proData === null || proData === void 0 ? void 0 : proData.status) && /*#__PURE__*/_react.default.createElement(_proBanner.default, {
    onRefresh: handleRefresh
  }), /*#__PURE__*/_react.default.createElement(_pluginsToImport.default, {
    plugins: missing
  }), /*#__PURE__*/_react.default.createElement(_existingPlugins.default, {
    plugins: existing
  })));
}

/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/import/import-process/import-process.js":
/*!********************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/import/import-process/import-process.js ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = ImportProcess;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _slicedToArray2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "../node_modules/@babel/runtime/helpers/slicedToArray.js"));
var _router = __webpack_require__(/*! @reach/router */ "../node_modules/@reach/router/es/index.js");
var _sharedContextProvider = __webpack_require__(/*! ../../../context/shared-context/shared-context-provider */ "../app/modules/import-export/assets/js/context/shared-context/shared-context-provider.js");
var _importContextProvider = __webpack_require__(/*! ../../../context/import-context/import-context-provider */ "../app/modules/import-export/assets/js/context/import-context/import-context-provider.js");
var _layout = _interopRequireDefault(__webpack_require__(/*! ../../../templates/layout */ "../app/modules/import-export/assets/js/templates/layout.js"));
var _fileProcess = _interopRequireDefault(__webpack_require__(/*! ../../../shared/file-process/file-process */ "../app/modules/import-export/assets/js/shared/file-process/file-process.js"));
var _unfilteredFilesDialog = _interopRequireDefault(__webpack_require__(/*! elementor-app/organisms/unfiltered-files-dialog */ "../app/assets/js/organisms/unfiltered-files-dialog.js"));
var _appsEventTracking = __webpack_require__(/*! elementor-app/event-track/apps-event-tracking */ "../app/assets/js/event-track/apps-event-tracking.js");
var _useQueryParams = _interopRequireDefault(__webpack_require__(/*! elementor-app/hooks/use-query-params */ "../app/assets/js/hooks/use-query-params.js"));
var _useKit2 = _interopRequireDefault(__webpack_require__(/*! ../../../hooks/use-kit */ "../app/modules/import-export/assets/js/hooks/use-kit.js"));
var _useImportActions2 = _interopRequireDefault(__webpack_require__(/*! ../hooks/use-import-actions */ "../app/modules/import-export/assets/js/pages/import/hooks/use-import-actions.js"));
var _useImportKitLibraryApplyAllPlugins = __webpack_require__(/*! ../import-kit/hooks/use-import-kit-library-apply-all-plugins */ "../app/modules/import-export/assets/js/pages/import/import-kit/hooks/use-import-kit-library-apply-all-plugins.js");
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function ImportProcess() {
  var sharedContext = (0, _react.useContext)(_sharedContextProvider.SharedContext),
    importContext = (0, _react.useContext)(_importContextProvider.ImportContext),
    navigate = (0, _router.useNavigate)(),
    _useState = (0, _react.useState)(''),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    errorType = _useState2[0],
    setErrorType = _useState2[1],
    _useState3 = (0, _react.useState)(false),
    _useState4 = (0, _slicedToArray2.default)(_useState3, 2),
    showUnfilteredFilesDialog = _useState4[0],
    setShowUnfilteredFilesDialog = _useState4[1],
    _useState5 = (0, _react.useState)(false),
    _useState6 = (0, _slicedToArray2.default)(_useState5, 2),
    startImport = _useState6[0],
    setStartImport = _useState6[1],
    _useState7 = (0, _react.useState)([]),
    _useState8 = (0, _slicedToArray2.default)(_useState7, 2),
    plugins = _useState8[0],
    setPlugins = _useState8[1],
    missing = (0, _useImportKitLibraryApplyAllPlugins.useImportKitLibraryApplyAllPlugins)(plugins),
    _useKit = (0, _useKit2.default)(),
    kitState = _useKit.kitState,
    kitActions = _useKit.kitActions,
    KIT_STATUS_MAP = _useKit.KIT_STATUS_MAP,
    _useQueryParams$getAl = (0, _useQueryParams.default)().getAll(),
    id = _useQueryParams$getAl.id,
    referrer = _useQueryParams$getAl.referrer,
    fileURL = _useQueryParams$getAl.file_url,
    actionType = _useQueryParams$getAl.action_type,
    nonce = _useQueryParams$getAl.nonce,
    _ref = sharedContext.data || {},
    includes = _ref.includes,
    selectedCustomPostTypes = _ref.selectedCustomPostTypes,
    currentPage = _ref.currentPage,
    _ref2 = importContext.data || {},
    file = _ref2.file,
    uploadedData = _ref2.uploadedData,
    importedData = _ref2.importedData,
    overrideConditions = _ref2.overrideConditions,
    isResolvedData = _ref2.isResolvedData,
    isKitHasSvgAssets = (0, _react.useMemo)(function () {
      return includes.some(function (item) {
        return ['templates', 'content'].includes(item);
      });
    }, [includes]),
    _useImportActions = (0, _useImportActions2.default)(),
    navigateToMainScreen = _useImportActions.navigateToMainScreen,
    uploadKit = function uploadKit() {
      var decodedFileURL = decodeURIComponent(fileURL);
      importContext.dispatch({
        type: 'SET_ID',
        payload: id
      });
      importContext.dispatch({
        type: 'SET_FILE',
        payload: decodedFileURL
      });
      kitActions.upload({
        kitId: id,
        file: decodedFileURL,
        kitLibraryNonce: nonce
      });
    },
    importKit = function importKit() {
      if (elementorAppConfig['import-export'].isUnfilteredFilesEnabled || !isKitHasSvgAssets) {
        setStartImport(true);
      } else {
        setShowUnfilteredFilesDialog(true);
      }
    },
    applyAllSetCpt = function applyAllSetCpt() {
      var _kitState$data, _importContext$data, _importContext$data$u;
      var cpt = ((_kitState$data = kitState.data) === null || _kitState$data === void 0 ? void 0 : _kitState$data.manifest['custom-post-type-title']) || ((_importContext$data = importContext.data) === null || _importContext$data === void 0 ? void 0 : (_importContext$data$u = _importContext$data.uploadedData) === null || _importContext$data$u === void 0 ? void 0 : _importContext$data$u.manifest['custom-post-type-title']);
      if (cpt) {
        var cptArray = Object.keys(cpt);
        sharedContext.dispatch({
          type: 'SET_SELECTED_CPT',
          payload: cptArray
        });
      }
    },
    applyAllImportPlugins = function applyAllImportPlugins() {
      var _kitState$data2, _kitState$data2$manif;
      var allPlugins = ((_kitState$data2 = kitState.data) === null || _kitState$data2 === void 0 ? void 0 : (_kitState$data2$manif = _kitState$data2.manifest) === null || _kitState$data2$manif === void 0 ? void 0 : _kitState$data2$manif.plugins) || importContext.data.uploadedData.manifest.plugins;
      setPlugins(allPlugins);
    },
    onCancelProcess = function onCancelProcess() {
      importContext.dispatch({
        type: 'SET_FILE',
        payload: null
      });
      navigateToMainScreen();
    },
    _onReady = function onReady() {
      setShowUnfilteredFilesDialog(false);
      setStartImport(true);
    },
    eventTracking = function eventTracking(command) {
      var eventType = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'click';
      if ('kit-library' === sharedContext.data.referrer) {
        (0, _appsEventTracking.appsEventTrackingDispatch)(command, {
          page_source: 'import',
          step: currentPage,
          modal_type: 'unfiltered_file',
          event_type: eventType
        });
      }
    };

  // On load.
  (0, _react.useEffect)(function () {
    // Saving the referrer value globally.
    if (referrer) {
      sharedContext.dispatch({
        type: 'SET_REFERRER',
        payload: referrer
      });
    }
    if (actionType) {
      importContext.dispatch({
        type: 'SET_ACTION_TYPE',
        payload: actionType
      });
    }
    if (fileURL && !file) {
      // When the starting point of the app is the import/process screen and importing via file_url.
      uploadKit();
    } else if (uploadedData) {
      // When the import/process is the second step of the kit import process, after selecting the kit content.
      importKit();
    } else {
      navigate('import');
    }
    sharedContext.dispatch({
      type: 'SET_CURRENT_PAGE_NAME',
      payload: ImportProcess.name
    });
  }, []);

  // Starting the import process.
  (0, _react.useEffect)(function () {
    if (startImport) {
      kitActions.import({
        id: importContext.data.id,
        session: uploadedData.session,
        include: includes,
        overrideConditions: overrideConditions,
        referrer: referrer,
        selectedCustomPostTypes: selectedCustomPostTypes
      });
    }
  }, [startImport]);

  // Updating the kit data after upload/import.
  (0, _react.useEffect)(function () {
    if (KIT_STATUS_MAP.INITIAL !== kitState.status) {
      switch (kitState.status) {
        case KIT_STATUS_MAP.IMPORTED:
          importContext.dispatch({
            type: 'SET_IMPORTED_DATA',
            payload: kitState.data
          });
          break;
        case KIT_STATUS_MAP.UPLOADED:
          importContext.dispatch({
            type: 'SET_UPLOADED_DATA',
            payload: kitState.data
          });
          break;
        case KIT_STATUS_MAP.ERROR:
          setErrorType(kitState.data);
          break;
      }
    }
  }, [kitState.status]);

  // Actions after the kit upload/import data was updated.
  (0, _react.useEffect)(function () {
    if (KIT_STATUS_MAP.INITIAL !== kitState.status || isResolvedData && 'apply-all' === importContext.data.actionType) {
      if (importedData) {
        // After kit upload.
        navigate('/import/complete');
      } else if ('apply-all' === importContext.data.actionType) {
        var _kitState$data3, _kitState$data3$manif, _importContext$data$u2;
        // Forcing apply-all kit content.
        if ((_kitState$data3 = kitState.data) !== null && _kitState$data3 !== void 0 && (_kitState$data3$manif = _kitState$data3.manifest) !== null && _kitState$data3$manif !== void 0 && _kitState$data3$manif.plugins || (_importContext$data$u2 = importContext.data.uploadedData) !== null && _importContext$data$u2 !== void 0 && _importContext$data$u2.manifest.plugins) {
          importContext.dispatch({
            type: 'SET_PLUGINS_STATE',
            payload: 'have'
          });
        }
        if (uploadedData.conflicts && Object.keys(uploadedData.conflicts).length && !isResolvedData) {
          navigate('/import/resolver');
        } else {
          // The kitState must be reset due to staying in the same page, so that the useEffect will be re-triggered.
          kitActions.reset();
          if ('have' === importContext.data.pluginsState) {
            applyAllImportPlugins();
          }
          if ('' === importContext.data.pluginsState || 'success' === importContext.data.pluginsState) {
            applyAllSetCpt();
            importKit();
          }
        }
      } else {
        navigate('/import/plugins');
      }
    }
  }, [uploadedData, importedData, importContext.data.pluginsState]);
  (0, _react.useEffect)(function () {
    if ((missing === null || missing === void 0 ? void 0 : missing.length) > 0) {
      importContext.dispatch({
        type: 'SET_PLUGINS',
        payload: missing
      });
      navigate('import/plugins-activation');
    }
  }, [missing]);
  return /*#__PURE__*/_react.default.createElement(_layout.default, {
    type: "import"
  }, /*#__PURE__*/_react.default.createElement("section", null, /*#__PURE__*/_react.default.createElement(_fileProcess.default, {
    info: uploadedData && __('Importing your content, templates and site settings', 'elementor'),
    errorType: errorType,
    onDialogApprove: onCancelProcess,
    onDialogDismiss: onCancelProcess
  }), /*#__PURE__*/_react.default.createElement(_unfilteredFilesDialog.default, {
    show: showUnfilteredFilesDialog,
    setShow: setShowUnfilteredFilesDialog,
    confirmModalText: __('This allows Elementor to scan your SVGs for malicious content. Otherwise, you can skip any SVGs in this import.', 'elementor'),
    errorModalText: __('Nothing to worry about, just continue without importing SVGs or go back and start the import again.', 'elementor'),
    onReady: function onReady() {
      return _onReady();
    },
    onCancel: function onCancel() {
      setShowUnfilteredFilesDialog(false);
      onCancelProcess();
    },
    onLoad: function onLoad() {
      return eventTracking('kit-library/modal-load', 'load');
    },
    onClose: function onClose() {
      eventTracking('kit-library/close');
      _onReady();
    },
    onDismiss: function onDismiss() {
      _onReady();
      eventTracking('kit-library/skip');
    },
    onEnable: function onEnable() {
      return eventTracking('kit-library/enable');
    }
  })));
}

/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/import/import-resolver/components/conflict/components/conflict-checkbox/conflict-checkbox.js":
/*!*************************************************************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/import/import-resolver/components/conflict/components/conflict-checkbox/conflict-checkbox.js ***!
  \*************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = ConflictCheckbox;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _importContextProvider = __webpack_require__(/*! ../../../../../../../context/import-context/import-context-provider */ "../app/modules/import-export/assets/js/context/import-context/import-context-provider.js");
var _checkbox = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/checkbox */ "../app/assets/js/ui/atoms/checkbox.js"));
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function ConflictCheckbox(props) {
  var importContext = (0, _react.useContext)(_importContextProvider.ImportContext),
    isSelected = function isSelected() {
      return importContext.data.overrideConditions.includes(props.id);
    },
    updateOverrideCondition = function updateOverrideCondition(event) {
      var isChecked = event.target.checked,
        actionType = isChecked ? 'ADD_OVERRIDE_CONDITION' : 'REMOVE_OVERRIDE_CONDITION';
      if (props.onCheck) {
        props.onCheck(isChecked);
      }
      importContext.dispatch({
        type: actionType,
        payload: props.id
      });
    };
  (0, _react.useEffect)(function () {
    if (!importContext.data.overrideConditions.length) {
      importContext.dispatch({
        type: 'ADD_OVERRIDE_CONDITION',
        payload: props.id
      });
    }
  }, []);
  return /*#__PURE__*/_react.default.createElement(_checkbox.default, {
    checked: isSelected(),
    onChange: updateOverrideCondition,
    className: props.className
  });
}
ConflictCheckbox.propTypes = {
  className: PropTypes.string,
  id: PropTypes.number.isRequired,
  onCheck: PropTypes.func
};
ConflictCheckbox.defaultProps = {
  className: ''
};

/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/import/import-resolver/components/conflict/conflict.js":
/*!***********************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/import/import-resolver/components/conflict/conflict.js ***!
  \***********************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = Conflict;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _importContextProvider = __webpack_require__(/*! ../../../../../context/import-context/import-context-provider */ "../app/modules/import-export/assets/js/context/import-context/import-context-provider.js");
var _sharedContextProvider = __webpack_require__(/*! ../../../../../context/shared-context/shared-context-provider */ "../app/modules/import-export/assets/js/context/shared-context/shared-context-provider.js");
var _conflictCheckbox = _interopRequireDefault(__webpack_require__(/*! ./components/conflict-checkbox/conflict-checkbox */ "../app/modules/import-export/assets/js/pages/import/import-resolver/components/conflict/components/conflict-checkbox/conflict-checkbox.js"));
var _heading = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/heading */ "../app/assets/js/ui/atoms/heading.js"));
var _text = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/text */ "../app/assets/js/ui/atoms/text.js"));
var _grid = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/grid/grid */ "../app/assets/js/ui/grid/grid.js"));
var _button = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/button */ "../app/assets/js/ui/molecules/button.js"));
var _appsEventTracking = __webpack_require__(/*! elementor-app/event-track/apps-event-tracking */ "../app/assets/js/event-track/apps-event-tracking.js");
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function Conflict(props) {
  var _importContext$data$u;
  var importContext = (0, _react.useContext)(_importContextProvider.ImportContext),
    sharedContext = (0, _react.useContext)(_sharedContextProvider.SharedContext),
    manifest = (_importContext$data$u = importContext.data.uploadedData) === null || _importContext$data$u === void 0 ? void 0 : _importContext$data$u.manifest,
    currentPage = sharedContext.data.currentPage,
    getConflictTitle = function getConflictTitle(id) {
      var _elementorAppConfig$i;
      var templateType = manifest.templates[id].doc_type,
        summaryTitle = (_elementorAppConfig$i = elementorAppConfig['import-export'].summaryTitles.templates) === null || _elementorAppConfig$i === void 0 ? void 0 : _elementorAppConfig$i[templateType];
      return (summaryTitle === null || summaryTitle === void 0 ? void 0 : summaryTitle.single) || templateType;
    },
    getEditTemplateButton = function getEditTemplateButton(editUrl, title) {
      return /*#__PURE__*/_react.default.createElement(_button.default, {
        className: "e-app-import-resolver-conflicts__edit-template",
        url: editUrl,
        target: "_blank",
        icon: "eicon-editor-external-link",
        text: __('Edit Template', 'elementor'),
        hideText: true,
        onClick: function onClick() {
          if (props.onClick) {
            props.onClick(title);
          }
        }
      });
    },
    isImportedAssetSelected = function isImportedAssetSelected(importedAssetId) {
      return importContext.data.overrideConditions.includes(importedAssetId);
    },
    getAssetClassName = function getAssetClassName(isActive) {
      var classes = ['e-app-import-resolver-conflicts__asset'];
      if (isActive) {
        classes.push('active');
      }
      return classes.join(' ');
    },
    getImportedAssetClasses = function getImportedAssetClasses(importedAssetId) {
      return getAssetClassName(isImportedAssetSelected(importedAssetId));
    },
    getExistingAssetClasses = function getExistingAssetClasses(importedAssetId) {
      return getAssetClassName(!isImportedAssetSelected(importedAssetId));
    },
    eventTracking = function eventTracking(command, title) {
      return (0, _appsEventTracking.appsEventTrackingDispatch)("kit-library/".concat(command), {
        item: title,
        page_source: 'import',
        step: currentPage,
        event_type: 'click'
      });
    };
  return /*#__PURE__*/_react.default.createElement(_grid.default, {
    container: true,
    noWrap: true
  }, /*#__PURE__*/_react.default.createElement(_conflictCheckbox.default, {
    id: props.importedId,
    type: "main-type",
    className: "e-app-import-resolver-conflicts__checkbox",
    onCheck: function onCheck(isChecked) {
      var command = isChecked && isChecked ? 'check' : 'uncheck';
      eventTracking(command, props.conflictData.template_title);
    }
  }), /*#__PURE__*/_react.default.createElement(_grid.default, {
    item: true
  }, /*#__PURE__*/_react.default.createElement(_heading.default, {
    variant: "h5",
    tag: "h4",
    className: "e-app-import-resolver-conflicts__title"
  }, getConflictTitle(props.importedId)), /*#__PURE__*/_react.default.createElement(_grid.default, {
    item: true
  }, /*#__PURE__*/_react.default.createElement(_text.default, {
    variant: "sm",
    tag: "span",
    className: getImportedAssetClasses(props.importedId)
  }, __('Imported', 'elementor'), ": ", manifest.templates[props.importedId].title), /*#__PURE__*/_react.default.createElement(_text.default, {
    style: true,
    variant: "sm",
    tag: "span",
    className: getExistingAssetClasses(props.importedId)
  }, __('Existing', 'elementor'), ": ", props.conflictData.template_title, " ", getEditTemplateButton(props.conflictData.edit_url, props.conflictData.template_title)))));
}
Conflict.propTypes = {
  importedId: PropTypes.number,
  conflictData: PropTypes.object,
  onClick: PropTypes.func
};

/***/ }),

/***/ "../app/modules/import-export/assets/js/pages/import/import-resolver/import-resolver.js":
/*!**********************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/pages/import/import-resolver/import-resolver.js ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = ImportResolver;
var _slicedToArray2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "../node_modules/@babel/runtime/helpers/slicedToArray.js"));
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _router = __webpack_require__(/*! @reach/router */ "../node_modules/@reach/router/es/index.js");
var _sharedContextProvider = __webpack_require__(/*! ../../../context/shared-context/shared-context-provider */ "../app/modules/import-export/assets/js/context/shared-context/shared-context-provider.js");
var _importContextProvider = __webpack_require__(/*! ../../../context/import-context/import-context-provider */ "../app/modules/import-export/assets/js/context/import-context/import-context-provider.js");
var _layout = _interopRequireDefault(__webpack_require__(/*! ../../../templates/layout */ "../app/modules/import-export/assets/js/templates/layout.js"));
var _pageHeader = _interopRequireDefault(__webpack_require__(/*! ../../../ui/page-header/page-header */ "../app/modules/import-export/assets/js/ui/page-header/page-header.js"));
var _conflict = _interopRequireDefault(__webpack_require__(/*! ./components/conflict/conflict */ "../app/modules/import-export/assets/js/pages/import/import-resolver/components/conflict/conflict.js"));
var _actionsFooter = _interopRequireDefault(__webpack_require__(/*! ../../../shared/actions-footer/actions-footer */ "../app/modules/import-export/assets/js/shared/actions-footer/actions-footer.js"));
var _panel = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/panel/panel */ "../app/assets/js/ui/panel/panel.js"));
var _notice = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/notice */ "../app/assets/js/ui/molecules/notice.js"));
var _inlineLink = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/inline-link */ "../app/assets/js/ui/molecules/inline-link.js"));
var _button = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/button */ "../app/assets/js/ui/molecules/button.js"));
var _box = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/box */ "../app/assets/js/ui/atoms/box.js"));
var _list = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/list */ "../app/assets/js/ui/molecules/list.js"));
var _appsEventTracking = __webpack_require__(/*! elementor-app/event-track/apps-event-tracking */ "../app/assets/js/event-track/apps-event-tracking.js");
__webpack_require__(/*! ./import-resolver.scss */ "../app/modules/import-export/assets/js/pages/import/import-resolver/import-resolver.scss");
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function ImportResolver() {
  var _importContext$data, _importContext$data$u;
  var sharedContext = (0, _react.useContext)(_sharedContextProvider.SharedContext),
    importContext = (0, _react.useContext)(_importContextProvider.ImportContext),
    navigate = (0, _router.useNavigate)(),
    conflicts = ((_importContext$data = importContext.data) === null || _importContext$data === void 0 ? void 0 : (_importContext$data$u = _importContext$data.uploadedData) === null || _importContext$data$u === void 0 ? void 0 : _importContext$data$u.conflicts) || {},
    _ref = sharedContext.data || {},
    referrer = _ref.referrer,
    currentPage = _ref.currentPage,
    eventTracking = function eventTracking(command) {
      var sitePart = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
      if ('kit-library' === referrer) {
        (0, _appsEventTracking.appsEventTrackingDispatch)(command, {
          site_part: sitePart,
          page_source: 'import',
          step: currentPage,
          event_type: 'click'
        });
      }
    },
    getFooter = function getFooter() {
      return /*#__PURE__*/_react.default.createElement(_actionsFooter.default, null, /*#__PURE__*/_react.default.createElement(_button.default, {
        text: __('Previous', 'elementor'),
        variant: "contained",
        onClick: function onClick() {
          eventTracking('kit-library/go-back');
          navigate('import/content');
        }
      }), /*#__PURE__*/_react.default.createElement(_button.default, {
        text: __('Next', 'elementor'),
        variant: "contained",
        color: "primary",
        onClick: function onClick() {
          eventTracking('kit-library/approve-selection');
          var url = importContext.data.plugins.length ? 'import/plugins-activation' : 'import/process';
          importContext.dispatch({
            type: 'SET_IS_RESOLVED',
            payload: true
          });
          navigate(url);
        }
      }));
    },
    getLearnMoreLink = function getLearnMoreLink() {
      return /*#__PURE__*/_react.default.createElement(_inlineLink.default, {
        url: "https://go.elementor.com/app-what-are-kits",
        italic: true,
        onClick: function onClick() {
          return eventTracking('kit-library/seek-more-info');
        }
      }, __('Learn More', 'elementor'));
    },
    isHomePageOverride = function isHomePageOverride() {
      if (sharedContext.data.includes.includes('content')) {
        var _importContext$data2, _importContext$data2$, _importContext$data2$2;
        var pages = ((_importContext$data2 = importContext.data) === null || _importContext$data2 === void 0 ? void 0 : (_importContext$data2$ = _importContext$data2.uploadedData) === null || _importContext$data2$ === void 0 ? void 0 : (_importContext$data2$2 = _importContext$data2$.manifest.content) === null || _importContext$data2$2 === void 0 ? void 0 : _importContext$data2$2.page) || {};
        return Object.entries(pages).find(function (pageData) {
          return pageData[1].show_on_front;
        });
      }
      return false;
    };
  (0, _react.useEffect)(function () {
    if (!importContext.data.uploadedData) {
      navigate('import');
    }
    sharedContext.dispatch({
      type: 'SET_CURRENT_PAGE_NAME',
      payload: ImportResolver.name
    });
  }, []);
  return /*#__PURE__*/_react.default.createElement(_layout.default, {
    type: "import",
    footer: getFooter()
  }, /*#__PURE__*/_react.default.createElement("section", {
    className: "e-app-import-resolver"
  }, /*#__PURE__*/_react.default.createElement(_pageHeader.default, {
    heading: __('Import a Website Kit to your site', 'elementor'),
    description: [/*#__PURE__*/_react.default.createElement(_react.default.Fragment, {
      key: "description-first-line"
    }, __('Parts of this kit overlap with your site’s templates, design and settings. The items you leave checked on this list will replace your current design.', 'elementor'), " ", getLearnMoreLink())]
  }), isHomePageOverride() && /*#__PURE__*/_react.default.createElement(_notice.default, {
    className: "e-app-import-resolver__notice",
    label: __('Note:', 'elementor'),
    color: "warning"
  }, __("Your site's homepage will be determined by the kit. You can change this later.", 'elementor')), /*#__PURE__*/_react.default.createElement(_panel.default, {
    isOpened: true
  }, /*#__PURE__*/_react.default.createElement(_panel.default.Header, {
    toggle: false
  }, /*#__PURE__*/_react.default.createElement(_panel.default.Headline, null, __('Select the items you want to keep and apply:', 'elementor'))), /*#__PURE__*/_react.default.createElement(_panel.default.Body, {
    padding: "20"
  }, /*#__PURE__*/_react.default.createElement(_box.default, {
    className: "e-app-import-resolver-conflicts__container"
  }, /*#__PURE__*/_react.default.createElement(_list.default, {
    separated: true,
    className: "e-app-import-resolver-conflicts"
  }, Object.entries(conflicts).map(function (_ref2, index) {
    var _ref3 = (0, _slicedToArray2.default)(_ref2, 2),
      id = _ref3[0],
      conflict = _ref3[1];
    return /*#__PURE__*/_react.default.createElement(_list.default.Item, {
      padding: "20",
      key: index,
      className: "e-app-import-resolver-conflicts__item"
    }, /*#__PURE__*/_react.default.createElement(_conflict.default, {
      importedId: parseInt(id),
      conflictData: conflict[0],
      onClick: function onClick(title) {
        return eventTracking('kit-library/check-item', title);
      }
    }));
  })))))));
}

/***/ }),

/***/ "../app/modules/import-export/assets/js/shared/actions-footer/actions-footer.js":
/*!**************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/shared/actions-footer/actions-footer.js ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = ActionsFooter;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _wizardFooter = _interopRequireDefault(__webpack_require__(/*! elementor-app/organisms/wizard-footer */ "../app/assets/js/organisms/wizard-footer.js"));
function ActionsFooter(props) {
  return /*#__PURE__*/_react.default.createElement(_wizardFooter.default, {
    separator: true,
    justify: "end"
  }, props.children);
}
ActionsFooter.propTypes = {
  children: PropTypes.any
};

/***/ }),

/***/ "../app/modules/import-export/assets/js/shared/content-layout/content-layout.js":
/*!**************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/shared/content-layout/content-layout.js ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = ContentLayout;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
__webpack_require__(/*! ./content-layout.scss */ "../app/modules/import-export/assets/js/shared/content-layout/content-layout.scss");
function ContentLayout(props) {
  return /*#__PURE__*/_react.default.createElement("div", {
    className: "e-app-import-export-content-layout"
  }, /*#__PURE__*/_react.default.createElement("div", {
    className: "e-app-import-export-content-layout__container"
  }, props.children));
}
ContentLayout.propTypes = {
  children: PropTypes.any.isRequired
};

/***/ }),

/***/ "../app/modules/import-export/assets/js/shared/cpt-select-box/cpt-object-to-options-array.js":
/*!***************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/shared/cpt-select-box/cpt-object-to-options-array.js ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.cptObjectToOptionsArray = void 0;
var cptObjectToOptionsArray = function cptObjectToOptionsArray(cptObject) {
  var label = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'label';
  var cptOptionsArray = [];
  // eslint-disable-next-line no-unused-expressions
  if (cptObject && label) {
    Object.keys(cptObject).forEach(function (key) {
      return cptOptionsArray.push({
        label: cptObject[key][label],
        value: key
      });
    });
  }
  return cptOptionsArray;
};
exports.cptObjectToOptionsArray = cptObjectToOptionsArray;

/***/ }),

/***/ "../app/modules/import-export/assets/js/shared/cpt-select-box/cpt-select-box.js":
/*!**************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/shared/cpt-select-box/cpt-select-box.js ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = CptSelectBox;
var _slicedToArray2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "../node_modules/@babel/runtime/helpers/slicedToArray.js"));
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _sharedContextProvider = __webpack_require__(/*! ../../context/shared-context/shared-context-provider */ "../app/modules/import-export/assets/js/context/shared-context/shared-context-provider.js");
var _select = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/select2 */ "../app/assets/js/ui/molecules/select2.js"));
var _text = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/text */ "../app/assets/js/ui/atoms/text.js"));
var _textField = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/text-field */ "../app/assets/js/ui/atoms/text-field.js"));
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function CptSelectBox() {
  var sharedContext = (0, _react.useContext)(_sharedContextProvider.SharedContext),
    _ref = sharedContext.data || [],
    customPostTypes = _ref.customPostTypes,
    _useState = (0, _react.useState)([]),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    selected = _useState2[0],
    setSelected = _useState2[1];
  (0, _react.useEffect)(function () {
    setSelected(arrayValueIterator(customPostTypes));
  }, [customPostTypes]);
  (0, _react.useEffect)(function () {
    sharedContext.dispatch({
      type: 'SET_SELECTED_CPT',
      payload: selected
    });
  }, [selected]);
  var arrayValueIterator = function arrayValueIterator(array) {
    return array.map(function (_ref2) {
      var value = _ref2.value;
      return value;
    });
  };
  var selectedCpt = function selectedCpt(selectedValue) {
    setSelected(arrayValueIterator(Array.from(selectedValue)));
  };
  return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement(_text.default, {
    variant: "sm",
    tag: "p",
    className: "e-app-export-kit-content__description"
  }, __('Custom Post Type', 'elementor')), customPostTypes.length > 0 ? /*#__PURE__*/_react.default.createElement(_select.default, {
    multiple: true,
    settings: {
      width: '100%'
    },
    options: customPostTypes,
    onChange: function onChange(e) {
      return selectedCpt(e.target.selectedOptions);
    },
    value: selected,
    placeholder: __('Click to select custom post types', 'elementor')
  }) : /*#__PURE__*/_react.default.createElement(_textField.default, {
    variant: "outlined"
    // eslint-disable-next-line @wordpress/i18n-ellipsis
    ,
    placeholder: __('No custom post types in your site...', 'elementor'),
    className: "e-app-export-kit-content__disabled"
  }), /*#__PURE__*/_react.default.createElement(_text.default, {
    variant: "sm",
    tag: "span",
    className: "e-app-export-kit-content__small-notice"
  }, __('Add the custom posts types to export. The latest 20 items from each type will be included.', 'elementor')));
}

/***/ }),

/***/ "../app/modules/import-export/assets/js/shared/file-process/file-process.js":
/*!**********************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/shared/file-process/file-process.js ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = FileProcess;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
var _processFailedDialog = _interopRequireDefault(__webpack_require__(/*! ../process-failed-dialog/process-failed-dialog */ "../app/modules/import-export/assets/js/shared/process-failed-dialog/process-failed-dialog.js"));
var _wizardStep = _interopRequireDefault(__webpack_require__(/*! ../../ui/wizard-step/wizard-step */ "../app/modules/import-export/assets/js/ui/wizard-step/wizard-step.js"));
function FileProcess(props) {
  return /*#__PURE__*/_react.default.createElement(_wizardStep.default, {
    className: (0, _utils.arrayToClassName)(['e-app-import-export-file-process', props.className]),
    icon: "eicon-loading eicon-animation-spin"
    // eslint-disable-next-line @wordpress/i18n-ellipsis
    ,
    heading: __('Setting up your kit...', 'elementor'),
    description: /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, __('This usually takes a few moments.', 'elementor'), /*#__PURE__*/_react.default.createElement("br", null), __("Don't close this window until the process is finished.", 'elementor')),
    info: props.info
  }, !!props.errorType && /*#__PURE__*/_react.default.createElement(_processFailedDialog.default, {
    onApprove: props.onDialogApprove,
    onDismiss: props.onDialogDismiss,
    errorType: props.errorType
  }));
}
FileProcess.propTypes = {
  className: PropTypes.string,
  onDialogApprove: PropTypes.func,
  onDialogDismiss: PropTypes.func,
  errorType: PropTypes.string,
  info: PropTypes.string
};
FileProcess.defaultProps = {
  className: ''
};

/***/ }),

/***/ "../app/modules/import-export/assets/js/shared/info-modal/export-info-modal.js":
/*!*************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/shared/info-modal/export-info-modal.js ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = ExportInfoModal;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _extends2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/extends */ "../node_modules/@babel/runtime/helpers/extends.js"));
var _inlineLink = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/inline-link */ "../app/assets/js/ui/molecules/inline-link.js"));
var _infoModal = _interopRequireDefault(__webpack_require__(/*! ./info-modal */ "../app/modules/import-export/assets/js/shared/info-modal/info-modal.js"));
function ExportInfoModal(props) {
  return /*#__PURE__*/_react.default.createElement(_infoModal.default, (0, _extends2.default)({}, props, {
    title: __('Export a Website Kit', 'elementor')
  }), /*#__PURE__*/_react.default.createElement(_infoModal.default.Section, null, /*#__PURE__*/_react.default.createElement(_infoModal.default.Heading, null, __('What’s a Website Kit?', 'elementor')), /*#__PURE__*/_react.default.createElement(_infoModal.default.Text, null, /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, __('A Website Kit is a .zip file that contains all the parts of a complete site. It’s an easy way to get a site up and running quickly.', 'elementor'), /*#__PURE__*/_react.default.createElement("br", null), /*#__PURE__*/_react.default.createElement("br", null), /*#__PURE__*/_react.default.createElement(_inlineLink.default, {
    url: "https://go.elementor.com/app-what-are-kits"
  }, __(' Learn more about Website Kits', 'elementor'))))), /*#__PURE__*/_react.default.createElement(_infoModal.default.Section, null, /*#__PURE__*/_react.default.createElement(_infoModal.default.Heading, null, __('How does exporting work?', 'elementor')), /*#__PURE__*/_react.default.createElement(_infoModal.default.Text, null, /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, __('To turn your site into a Website Kit, select the templates, content, settings and plugins you want to include. Once it’s ready, you’ll get a .zip file that you can import to other sites.', 'elementor'), /*#__PURE__*/_react.default.createElement("br", null), /*#__PURE__*/_react.default.createElement("br", null), /*#__PURE__*/_react.default.createElement(_inlineLink.default, {
    url: "https://go.elementor.com/app-export-kit"
  }, __('Learn More', 'elementor'))))));
}

/***/ }),

/***/ "../app/modules/import-export/assets/js/shared/info-modal/import-info-modal.js":
/*!*************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/shared/info-modal/import-info-modal.js ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = ImportInfoModal;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _extends2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/extends */ "../node_modules/@babel/runtime/helpers/extends.js"));
var _inlineLink = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/inline-link */ "../app/assets/js/ui/molecules/inline-link.js"));
var _infoModal = _interopRequireDefault(__webpack_require__(/*! ./info-modal */ "../app/modules/import-export/assets/js/shared/info-modal/info-modal.js"));
var _appsEventTracking = __webpack_require__(/*! elementor-app/event-track/apps-event-tracking */ "../app/assets/js/event-track/apps-event-tracking.js");
function ImportInfoModal(props) {
  var eventTracking = function eventTracking(element) {
    return (0, _appsEventTracking.appsEventTrackingDispatch)('kit-library/seek-more-info', {
      page_source: 'import',
      modal_type: 'info',
      event_type: 'click',
      element: element
    });
  };
  return /*#__PURE__*/_react.default.createElement(_infoModal.default, (0, _extends2.default)({}, props, {
    title: __('Import a Website Kit', 'elementor')
  }), /*#__PURE__*/_react.default.createElement(_infoModal.default.Section, null, /*#__PURE__*/_react.default.createElement(_infoModal.default.Heading, null, __('What’s a Website Kit?', 'elementor')), /*#__PURE__*/_react.default.createElement(_infoModal.default.Text, null, /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, __('A Website Kit is a .zip file that contains all the parts of a complete site. It’s an easy way to get a site up and running quickly.', 'elementor'), /*#__PURE__*/_react.default.createElement("br", null), /*#__PURE__*/_react.default.createElement("br", null), /*#__PURE__*/_react.default.createElement(_inlineLink.default, {
    url: "https://go.elementor.com/app-what-are-kits",
    onClick: function onClick() {
      return eventTracking('Learn more about website kits');
    }
  }, __(' Learn more about Website Kits', 'elementor'))))), /*#__PURE__*/_react.default.createElement(_infoModal.default.Section, null, /*#__PURE__*/_react.default.createElement(_infoModal.default.Heading, null, __('How does importing work?', 'elementor')), /*#__PURE__*/_react.default.createElement(_infoModal.default.Text, null, /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, __('Start by uploading the file and selecting the parts and plugins you want to apply. If there are any overlaps between the kit and your current design, you’ll be able to choose which imported parts you want to apply or ignore. Once the file is ready, the kit will be applied to your site and you’ll be able to see it live.', 'elementor'), /*#__PURE__*/_react.default.createElement("br", null), /*#__PURE__*/_react.default.createElement("br", null), /*#__PURE__*/_react.default.createElement(_inlineLink.default, {
    url: "https://go.elementor.com/app-import-kit",
    onClick: function onClick() {
      return eventTracking('learn more');
    }
  }, __('Learn More', 'elementor'))))));
}

/***/ }),

/***/ "../app/modules/import-export/assets/js/shared/info-modal/info-modal-heading.js":
/*!**************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/shared/info-modal/info-modal-heading.js ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = InfoModalHeading;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
var _heading = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/heading */ "../app/assets/js/ui/atoms/heading.js"));
function InfoModalHeading(props) {
  return /*#__PURE__*/_react.default.createElement(_heading.default, {
    variant: "h3",
    tag: "h2",
    className: (0, _utils.arrayToClassName)(['e-app-import-export-info-modal__heading', props.className])
  }, props.children);
}
InfoModalHeading.propTypes = {
  className: PropTypes.string,
  children: PropTypes.oneOfType([PropTypes.string, PropTypes.object, PropTypes.arrayOf(PropTypes.object)]).isRequired
};
InfoModalHeading.defaultProps = {
  className: ''
};

/***/ }),

/***/ "../app/modules/import-export/assets/js/shared/info-modal/info-modal-section.js":
/*!**************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/shared/info-modal/info-modal-section.js ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = InfoModalSection;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
var _modal = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/modal/modal */ "../app/assets/js/ui/modal/modal.js"));
function InfoModalSection(props) {
  return /*#__PURE__*/_react.default.createElement(_modal.default.Section, {
    className: (0, _utils.arrayToClassName)(['e-app-import-export-info-modal__section', props.className])
  }, props.children);
}
InfoModalSection.propTypes = {
  className: PropTypes.string,
  children: PropTypes.any
};
InfoModalSection.defaultProps = {
  className: ''
};

/***/ }),

/***/ "../app/modules/import-export/assets/js/shared/info-modal/info-modal-text.js":
/*!***********************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/shared/info-modal/info-modal-text.js ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = InfoModalText;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
var _text = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/text */ "../app/assets/js/ui/atoms/text.js"));
function InfoModalText(props) {
  return /*#__PURE__*/_react.default.createElement(_text.default, {
    variant: "sm",
    className: (0, _utils.arrayToClassName)(['e-app-import-export-info-modal__text', props.className])
  }, props.children);
}
InfoModalText.propTypes = {
  className: PropTypes.string,
  children: PropTypes.any.isRequired
};
InfoModalText.defaultProps = {
  className: ''
};

/***/ }),

/***/ "../app/modules/import-export/assets/js/shared/info-modal/info-modal-tip.js":
/*!**********************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/shared/info-modal/info-modal-tip.js ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = InfoModalTip;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _extends2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/extends */ "../node_modules/@babel/runtime/helpers/extends.js"));
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
var _modal = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/modal/modal */ "../app/assets/js/ui/modal/modal.js"));
function InfoModalTip(props) {
  return /*#__PURE__*/_react.default.createElement(_modal.default.Tip, (0, _extends2.default)({}, props, {
    className: (0, _utils.arrayToClassName)(['e-app-import-export-info-modal__tip', props.className])
  }));
}
InfoModalTip.propTypes = {
  className: PropTypes.string
};
InfoModalTip.defaultProps = {
  className: ''
};

/***/ }),

/***/ "../app/modules/import-export/assets/js/shared/info-modal/info-modal.js":
/*!******************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/shared/info-modal/info-modal.js ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = InfoModal;
exports.infoButtonProps = void 0;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _extends2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/extends */ "../node_modules/@babel/runtime/helpers/extends.js"));
var _modal = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/modal/modal */ "../app/assets/js/ui/modal/modal.js"));
var _infoModalSection = _interopRequireDefault(__webpack_require__(/*! ./info-modal-section */ "../app/modules/import-export/assets/js/shared/info-modal/info-modal-section.js"));
var _infoModalHeading = _interopRequireDefault(__webpack_require__(/*! ./info-modal-heading */ "../app/modules/import-export/assets/js/shared/info-modal/info-modal-heading.js"));
var _infoModalText = _interopRequireDefault(__webpack_require__(/*! ./info-modal-text */ "../app/modules/import-export/assets/js/shared/info-modal/info-modal-text.js"));
var _infoModalTip = _interopRequireDefault(__webpack_require__(/*! ./info-modal-tip */ "../app/modules/import-export/assets/js/shared/info-modal/info-modal-tip.js"));
__webpack_require__(/*! ./info-modal.scss */ "../app/modules/import-export/assets/js/shared/info-modal/info-modal.scss");
var infoButtonProps = {
  id: 'info-modal',
  className: 'e-app-export-kit-information__info-icon',
  icon: 'eicon-info-circle',
  text: __('Kit Info', 'elementor'),
  color: 'secondary',
  hideText: true
};
exports.infoButtonProps = infoButtonProps;
function InfoModal(props) {
  var attrs = {
    className: 'e-app-import-export-info-modal',
    setShow: props.setShow,
    onOpen: props.onOpen,
    onClose: props.onClose,
    referrer: props.referrer
  };
  if (Object.prototype.hasOwnProperty.call(props, 'show')) {
    attrs.show = props.show;
  } else {
    attrs.toggleButtonProps = infoButtonProps;
  }
  return /*#__PURE__*/_react.default.createElement(_modal.default, (0, _extends2.default)({}, attrs, {
    title: props.title
  }), props.children);
}
InfoModal.propTypes = {
  show: PropTypes.bool,
  setShow: PropTypes.func,
  title: PropTypes.string,
  children: PropTypes.any.isRequired,
  onOpen: PropTypes.func,
  onClose: PropTypes.func,
  referrer: PropTypes.string
};
InfoModal.Section = _infoModalSection.default;
InfoModal.Heading = _infoModalHeading.default;
InfoModal.Text = _infoModalText.default;
InfoModal.Tip = _infoModalTip.default;

/***/ }),

/***/ "../app/modules/import-export/assets/js/shared/kit-content-data/kit-content-data.js":
/*!******************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/shared/kit-content-data/kit-content-data.js ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var kitContentData = [{
  type: 'templates',
  data: {
    title: __('Templates', 'elementor'),
    features: {
      open: [__('Saved Templates', 'elementor')],
      locked: [__('Headers', 'elementor'), __('Footers', 'elementor'), __('Archives', 'elementor'), __('Single Posts', 'elementor'), __('Single Pages', 'elementor'), __('Search Results', 'elementor'), __('404 Error Page', 'elementor'), __('Popups', 'elementor'), __('Global widgets', 'elementor')],
      tooltip: __('To import or export these components, you’ll need Elementor Pro.', 'elementor')
    }
  }
}, {
  type: 'content',
  data: {
    title: __('Content', 'elementor'),
    features: {
      open: [__('Elementor Pages', 'elementor'), __('Landing Pages', 'elementor'), __('Elementor Posts', 'elementor'), __('WP Pages', 'elementor'), __('WP Posts', 'elementor'), __('WP Menus', 'elementor'), __('Custom Post Types', 'elementor')]
    }
  }
}, {
  type: 'settings',
  data: {
    title: __('Site Settings', 'elementor'),
    features: {
      open: [__('Global Colors', 'elementor'), __('Global Fonts', 'elementor'), __('Theme Style settings', 'elementor'), __('Layout Settings', 'elementor'), __('Lightbox Settings', 'elementor'), __('Background Settings', 'elementor')]
    }
  }
}];
var _default = kitContentData;
exports["default"] = _default;

/***/ }),

/***/ "../app/modules/import-export/assets/js/shared/kit-content/components/kit-content-checkbox/kit-content-checkbox.js":
/*!*************************************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/shared/kit-content/components/kit-content-checkbox/kit-content-checkbox.js ***!
  \*************************************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = KitContentCheckbox;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _sharedContextProvider = __webpack_require__(/*! ../../../../context/shared-context/shared-context-provider */ "../app/modules/import-export/assets/js/context/shared-context/shared-context-provider.js");
var _checkbox = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/checkbox */ "../app/assets/js/ui/atoms/checkbox.js"));
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function KitContentCheckbox(props) {
  var sharedContext = (0, _react.useContext)(_sharedContextProvider.SharedContext),
    isSelected = function isSelected() {
      return sharedContext.data.includes.includes(props.type);
    },
    setIncludes = function setIncludes(event) {
      var _props$onCheck;
      var isChecked = event.target.checked,
        actionType = isChecked ? 'ADD_INCLUDE' : 'REMOVE_INCLUDE';
      (_props$onCheck = props.onCheck) === null || _props$onCheck === void 0 ? void 0 : _props$onCheck.call(props, event, props.type);
      sharedContext.dispatch({
        type: actionType,
        payload: props.type
      });
    };
  (0, _react.useEffect)(function () {
    if (!sharedContext.data.includes.length) {
      sharedContext.dispatch({
        type: 'ADD_INCLUDE',
        payload: props.type
      });
    }
  }, []);
  return (0, _react.useMemo)(function () {
    return /*#__PURE__*/_react.default.createElement(_checkbox.default, {
      checked: isSelected(),
      onChange: setIncludes,
      className: props.className
    });
  }, [sharedContext.data.includes]);
}
KitContentCheckbox.propTypes = {
  className: PropTypes.string,
  type: PropTypes.string.isRequired
};
KitContentCheckbox.defaultProps = {
  className: ''
};

/***/ }),

/***/ "../app/modules/import-export/assets/js/shared/kit-content/components/templates-features/templates-features.js":
/*!*********************************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/shared/kit-content/components/templates-features/templates-features.js ***!
  \*********************************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = TemplatesFeatures;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _tooltip = _interopRequireDefault(__webpack_require__(/*! elementor-app/molecules/tooltip */ "../app/assets/js/molecules/tooltip.js"));
__webpack_require__(/*! ./templates-features.scss */ "../app/modules/import-export/assets/js/shared/kit-content/components/templates-features/templates-features.scss");
function TemplatesFeatures(props) {
  var _props$features$locke;
  var isLockedFeatures = (_props$features$locke = props.features.locked) === null || _props$features$locke === void 0 ? void 0 : _props$features$locke.length,
    getLockedFeatures = function getLockedFeatures() {
      if (!isLockedFeatures) {
        return;
      }
      return /*#__PURE__*/_react.default.createElement(_tooltip.default, {
        tag: "span",
        offset: 19,
        show: props.showTooltip,
        title: props.features.tooltip,
        disabled: !props.isLocked,
        className: props.isLocked ? 'e-app-export-templates-features__locked' : ''
      }, ', ' + props.features.locked.join(', '));
    },
    getOpenFeatures = function getOpenFeatures() {
      var _props$features$open;
      return (_props$features$open = props.features.open) === null || _props$features$open === void 0 ? void 0 : _props$features$open.join(', ');
    };
  return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, getOpenFeatures(), getLockedFeatures());
}
TemplatesFeatures.propTypes = {
  features: PropTypes.object,
  isLocked: PropTypes.bool,
  showTooltip: PropTypes.bool
};
TemplatesFeatures.defaultProps = {
  showTooltip: false
};

/***/ }),

/***/ "../app/modules/import-export/assets/js/shared/kit-content/kit-content.js":
/*!********************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/shared/kit-content/kit-content.js ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = KitContent;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _defineProperty2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "../node_modules/@babel/runtime/helpers/defineProperty.js"));
var _slicedToArray2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "../node_modules/@babel/runtime/helpers/slicedToArray.js"));
var _templatesFeatures = _interopRequireDefault(__webpack_require__(/*! ./components/templates-features/templates-features */ "../app/modules/import-export/assets/js/shared/kit-content/components/templates-features/templates-features.js"));
var _kitContentCheckbox = _interopRequireDefault(__webpack_require__(/*! ./components/kit-content-checkbox/kit-content-checkbox */ "../app/modules/import-export/assets/js/shared/kit-content/components/kit-content-checkbox/kit-content-checkbox.js"));
var _cptSelectBox = _interopRequireDefault(__webpack_require__(/*! ../cpt-select-box/cpt-select-box */ "../app/modules/import-export/assets/js/shared/cpt-select-box/cpt-select-box.js"));
var _goProButton = _interopRequireDefault(__webpack_require__(/*! elementor-app/molecules/go-pro-button */ "../app/assets/js/molecules/go-pro-button.js"));
var _box = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/box */ "../app/assets/js/ui/atoms/box.js"));
var _list = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/list */ "../app/assets/js/ui/molecules/list.js"));
var _heading = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/heading */ "../app/assets/js/ui/atoms/heading.js"));
var _text = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/text */ "../app/assets/js/ui/atoms/text.js"));
var _grid = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/grid/grid */ "../app/assets/js/ui/grid/grid.js"));
var _appsEventTracking = __webpack_require__(/*! elementor-app/event-track/apps-event-tracking */ "../app/assets/js/event-track/apps-event-tracking.js");
var _sharedContextProvider = __webpack_require__(/*! ./../../context/shared-context/shared-context-provider.js */ "../app/modules/import-export/assets/js/context/shared-context/shared-context-provider.js");
__webpack_require__(/*! ./kit-content.scss */ "../app/modules/import-export/assets/js/shared/kit-content/kit-content.scss");
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { (0, _defineProperty2.default)(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function KitContent(_ref) {
  var contentData = _ref.contentData,
    hasPro = _ref.hasPro;
  var _useState = (0, _react.useState)({}),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    containerHover = _useState2[0],
    setContainerHover = _useState2[1],
    sharedContext = (0, _react.useContext)(_sharedContextProvider.SharedContext),
    _sharedContext$data = sharedContext.data,
    referrer = _sharedContext$data.referrer,
    currentPage = _sharedContext$data.currentPage,
    isProExist = hasPro || elementorAppConfig.hasPro,
    getTemplateFeatures = function getTemplateFeatures(features, index) {
      if (!features) {
        return;
      }
      return /*#__PURE__*/_react.default.createElement(_templatesFeatures.default, {
        features: features,
        isLocked: !isProExist,
        showTooltip: containerHover[index]
      });
    },
    setContainerHoverState = function setContainerHoverState(index, state) {
      setContainerHover(function (prevState) {
        return _objectSpread(_objectSpread({}, prevState), {}, (0, _defineProperty2.default)({}, index, state));
      });
    },
    eventTracking = function eventTracking(event, chosenPart) {
      if ('kit-library' === referrer) {
        var command = event.target.checked && event.target.checked ? 'check' : 'uncheck';
        (0, _appsEventTracking.appsEventTrackingDispatch)("kit-library/".concat(command), {
          page_source: 'import',
          step: currentPage,
          event_type: 'click',
          site_part: chosenPart
        });
      }
    };
  if (!contentData.length) {
    return null;
  }
  return /*#__PURE__*/_react.default.createElement(_box.default, null, /*#__PURE__*/_react.default.createElement(_list.default, {
    separated: true,
    className: "e-app-export-kit-content"
  }, contentData.map(function (_ref2, index) {
    var _data$features;
    var type = _ref2.type,
      data = _ref2.data;
    var isLockedFeaturesNoPro = ((_data$features = data.features) === null || _data$features === void 0 ? void 0 : _data$features.locked) && !isProExist;
    return /*#__PURE__*/_react.default.createElement(_list.default.Item, {
      padding: "20",
      key: type,
      className: "e-app-export-kit-content__item"
    }, /*#__PURE__*/_react.default.createElement("div", {
      onMouseEnter: function onMouseEnter() {
        return isLockedFeaturesNoPro && setContainerHoverState(index, true);
      },
      onMouseLeave: function onMouseLeave() {
        return isLockedFeaturesNoPro && setContainerHoverState(index, false);
      }
    }, /*#__PURE__*/_react.default.createElement(_grid.default, {
      container: true,
      noWrap: true
    }, /*#__PURE__*/_react.default.createElement(_kitContentCheckbox.default, {
      type: type,
      className: "e-app-export-kit-content__checkbox",
      onCheck: function onCheck(event, chosenPart) {
        eventTracking(event, chosenPart);
      }
    }), /*#__PURE__*/_react.default.createElement(_grid.default, {
      item: true,
      container: true
    }, /*#__PURE__*/_react.default.createElement(_heading.default, {
      variant: "h4",
      tag: "h3",
      className: "e-app-export-kit-content__title"
    }, data.title), /*#__PURE__*/_react.default.createElement(_grid.default, {
      item: true,
      container: true,
      direction: isLockedFeaturesNoPro ? 'row' : 'column',
      alignItems: 'baseline'
    }, /*#__PURE__*/_react.default.createElement(_text.default, {
      variant: "sm",
      tag: "p",
      className: "e-app-export-kit-content__description"
    }, data.description || getTemplateFeatures(data.features, index)), 'content' === type && /*#__PURE__*/_react.default.createElement(_cptSelectBox.default, null), isLockedFeaturesNoPro && /*#__PURE__*/_react.default.createElement(_goProButton.default, {
      className: "e-app-export-kit-content__go-pro-button",
      url: "https://go.elementor.com/go-pro-import-export"
    }))))));
  })));
}
KitContent.propTypes = {
  className: PropTypes.string,
  contentData: PropTypes.array.isRequired,
  hasPro: PropTypes.bool
};
KitContent.defaultProps = {
  className: ''
};

/***/ }),

/***/ "../app/modules/import-export/assets/js/shared/kit-data/components/included/included.js":
/*!**********************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/shared/kit-data/components/included/included.js ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = Included;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _text = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/text */ "../app/assets/js/ui/atoms/text.js"));
function Included(_ref) {
  var data = _ref.data;
  return /*#__PURE__*/_react.default.createElement(_text.default, {
    className: "e-app-import-export-kit-data__included"
  }, data.filter(function (value) {
    return value;
  }).join(' | '));
}
Included.propTypes = {
  data: PropTypes.array
};

/***/ }),

/***/ "../app/modules/import-export/assets/js/shared/kit-data/components/site-area/site-area.js":
/*!************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/shared/kit-data/components/site-area/site-area.js ***!
  \************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = SiteArea;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _text = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/text */ "../app/assets/js/ui/atoms/text.js"));
var _icon = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/icon */ "../app/assets/js/ui/atoms/icon.js"));
var _inlineLink = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/inline-link */ "../app/assets/js/ui/molecules/inline-link.js"));
var _appsEventTracking = __webpack_require__(/*! elementor-app/event-track/apps-event-tracking */ "../app/assets/js/event-track/apps-event-tracking.js");
function SiteArea(_ref) {
  var text = _ref.text,
    link = _ref.link;
  var eventTracking = function eventTracking(command) {
    var eventType = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'click';
    (0, _appsEventTracking.appsEventTrackingDispatch)(command, {
      site_area: text,
      page_source: 'import complete',
      event_type: eventType
    });
  };
  return /*#__PURE__*/_react.default.createElement(_inlineLink.default, {
    url: link,
    color: "secondary",
    underline: "none",
    onClick: function onClick() {
      return eventTracking('kit-library/open-site-area');
    }
  }, /*#__PURE__*/_react.default.createElement(_text.default, {
    className: "e-app-import-export-kit-data__site-area"
  }, text, " ", link && /*#__PURE__*/_react.default.createElement(_icon.default, {
    className: "eicon-editor-external-link"
  })));
}
SiteArea.propTypes = {
  text: PropTypes.string,
  link: PropTypes.string
};

/***/ }),

/***/ "../app/modules/import-export/assets/js/shared/kit-data/hooks/use-kit-data.js":
/*!************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/shared/kit-data/hooks/use-kit-data.js ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = useKitData;
var _defineProperty2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "../node_modules/@babel/runtime/helpers/defineProperty.js"));
var _slicedToArray2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "../node_modules/@babel/runtime/helpers/slicedToArray.js"));
var _react = __webpack_require__(/*! react */ "react");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { (0, _defineProperty2.default)(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function useKitData(kitData) {
  var getLabel = function getLabel(type, key, amount) {
      var _kitData$configData;
      // The summary-titles data will not exist in the kitData as part of the export process, and therefore should be taken from the elementorAppConfig.
      var summaryTitlesData = (kitData === null || kitData === void 0 ? void 0 : (_kitData$configData = kitData.configData) === null || _kitData$configData === void 0 ? void 0 : _kitData$configData.summaryTitles) || elementorAppConfig['import-export'].summaryTitles,
        label = summaryTitlesData[type][key];
      if (label !== null && label !== void 0 && label.single) {
        if (!amount) {
          return '';
        }
        var title = amount > 1 ? label.plural : label.single;
        return amount + ' ' + title;
      }
      return label;
    },
    getTemplates = function getTemplates() {
      var templates = {};
      for (var key in kitData === null || kitData === void 0 ? void 0 : kitData.templates) {
        var type = kitData.templates[key].doc_type;
        if (!templates[type]) {
          templates[type] = 0;
        }
        templates[type]++;
      }
      return Object.entries(templates).map(function (_ref) {
        var _ref2 = (0, _slicedToArray2.default)(_ref, 2),
          key = _ref2[0],
          amount = _ref2[1];
        return getLabel('templates', key, amount);
      }).filter(function (value) {
        return value;
      });
    },
    getSiteSettings = function getSiteSettings() {
      var siteSettings = (kitData === null || kitData === void 0 ? void 0 : kitData['site-settings']) || {};
      return Object.values(siteSettings).map(function (item) {
        return getLabel('site-settings', item);
      });
    },
    getContent = function getContent() {
      var content = (kitData === null || kitData === void 0 ? void 0 : kitData.content) || {},
        wpContent = (kitData === null || kitData === void 0 ? void 0 : kitData['wp-content']) || {};
      var mergedContent = _objectSpread({}, content);
      for (var key in mergedContent) {
        mergedContent[key] = Object.keys(mergedContent[key]).concat(wpContent[key] || []);
      }

      // In case that wpContent has properties that doesn't exist in the content object.
      mergedContent = _objectSpread(_objectSpread({}, wpContent), mergedContent);
      return Object.entries(mergedContent).map(function (_ref3) {
        var _ref4 = (0, _slicedToArray2.default)(_ref3, 2),
          key = _ref4[0],
          data = _ref4[1];
        return getLabel('content', key, data.length);
      }).filter(function (value) {
        return value;
      });
    },
    getPlugins = function getPlugins() {
      return kitData !== null && kitData !== void 0 && kitData.plugins ? kitData.plugins.map(function (_ref5) {
        var name = _ref5.name;
        return name;
      }) : [];
    };
  return (0, _react.useMemo)(function () {
    return {
      templates: getTemplates(),
      siteSettings: getSiteSettings(),
      content: getContent(),
      plugins: getPlugins()
    };
  }, [kitData]);
}

/***/ }),

/***/ "../app/modules/import-export/assets/js/shared/kit-data/kit-data.js":
/*!**************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/shared/kit-data/kit-data.js ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _siteArea = _interopRequireDefault(__webpack_require__(/*! ./components/site-area/site-area */ "../app/modules/import-export/assets/js/shared/kit-data/components/site-area/site-area.js"));
var _included = _interopRequireDefault(__webpack_require__(/*! ./components/included/included */ "../app/modules/import-export/assets/js/shared/kit-data/components/included/included.js"));
var _dataTable = _interopRequireDefault(__webpack_require__(/*! elementor-app/molecules/data-table */ "../app/assets/js/molecules/data-table.js"));
var _useKitData2 = _interopRequireDefault(__webpack_require__(/*! ./hooks/use-kit-data */ "../app/modules/import-export/assets/js/shared/kit-data/hooks/use-kit-data.js"));
__webpack_require__(/*! ./kit-data.scss */ "../app/modules/import-export/assets/js/shared/kit-data/kit-data.scss");
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
var siteEditorPath = elementorAppConfig.hasPro ? '#/site-editor' : '#/site-editor/promotion';
function KitData(_ref) {
  var data = _ref.data;
  var _useKitData = (0, _useKitData2.default)(data),
    templates = _useKitData.templates,
    siteSettings = _useKitData.siteSettings,
    content = _useKitData.content,
    plugins = _useKitData.plugins,
    _ref2 = (data === null || data === void 0 ? void 0 : data.configData) || elementorAppConfig['import-export'],
    elementorHomePageUrl = _ref2.elementorHomePageUrl,
    recentlyEditedElementorPageUrl = _ref2.recentlyEditedElementorPageUrl,
    siteSettingsUrl = elementorHomePageUrl || recentlyEditedElementorPageUrl,
    headers = [__('Site Area', 'elementor'), __('Included', 'elementor')],
    rowsData = [{
      siteArea: __('Elementor Templates', 'elementor'),
      link: elementorAppConfig.base_url + siteEditorPath,
      included: templates
    }, {
      siteArea: __('Site Settings', 'elementor'),
      link: siteSettingsUrl ? siteSettingsUrl + '#e:run:panel/global/open' : '',
      included: siteSettings
    }, {
      siteArea: __('Content', 'elementor'),
      link: elementorAppConfig.admin_url + 'edit.php?post_type=page',
      included: content
    }, {
      siteArea: __('Plugins', 'elementor'),
      link: elementorAppConfig.admin_url + 'plugins.php',
      included: plugins
    }],
    rows = rowsData.map(function (_ref3) {
      var siteArea = _ref3.siteArea,
        included = _ref3.included,
        link = _ref3.link;
      if (!included.length) {
        // eslint-disable-next-line array-callback-return
        return;
      }
      return [/*#__PURE__*/_react.default.createElement(_siteArea.default, {
        key: siteArea,
        text: siteArea,
        link: link
      }), /*#__PURE__*/_react.default.createElement(_included.default, {
        key: included,
        data: included
      })];
    }).filter(function (row) {
      return row;
    });
  if (!rows.length) {
    return null;
  }
  return /*#__PURE__*/_react.default.createElement(_dataTable.default, {
    className: "e-app-import-export-kit-data",
    headers: headers,
    rows: rows,
    layout: [1, 3]
  });
}
KitData.propTypes = {
  data: PropTypes.object
};
var _default = (0, _react.memo)(KitData);
exports["default"] = _default;

/***/ }),

/***/ "../app/modules/import-export/assets/js/shared/plugins-selection/components/plugins-table.js":
/*!***************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/shared/plugins-selection/components/plugins-table.js ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _dataTable = _interopRequireDefault(__webpack_require__(/*! elementor-app/molecules/data-table */ "../app/assets/js/molecules/data-table.js"));
var _text = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/text */ "../app/assets/js/ui/atoms/text.js"));
var _inlineLink = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/inline-link */ "../app/assets/js/ui/molecules/inline-link.js"));
var _icon = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/icon */ "../app/assets/js/ui/atoms/icon.js"));
__webpack_require__(/*! ./plugins-table.scss */ "../app/modules/import-export/assets/js/shared/plugins-selection/components/plugins-table.scss");
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function PluginsTable(_ref) {
  var plugins = _ref.plugins,
    layout = _ref.layout,
    withHeader = _ref.withHeader,
    withStatus = _ref.withStatus,
    onSelect = _ref.onSelect,
    initialSelected = _ref.initialSelected,
    initialDisabled = _ref.initialDisabled;
  var CellText = function CellText(cellTextProps) {
      return /*#__PURE__*/_react.default.createElement(_text.default, {
        className: "e-app-import-export-plugins-table__cell-content"
      }, cellTextProps.text);
    },
    CellLink = function CellLink(cellLinkProps) {
      return /*#__PURE__*/_react.default.createElement(_inlineLink.default, {
        url: cellLinkProps.url,
        underline: "none"
      }, "".concat(__('Version'), " ").concat(cellLinkProps.text), " ", /*#__PURE__*/_react.default.createElement(_icon.default, {
        className: "eicon-editor-external-link"
      }));
    },
    getHeaders = function getHeaders() {
      if (!withHeader) {
        return [];
      }
      var headers = ['Plugin Name', 'Version'];
      if (withStatus) {
        headers.splice(1, 0, 'Status');
      }
      return headers;
    },
    rows = plugins.map(function (_ref2) {
      var name = _ref2.name,
        status = _ref2.status,
        version = _ref2.version,
        pluginUrl = _ref2.plugin_uri;
      var row = [/*#__PURE__*/_react.default.createElement(CellText, {
        text: name,
        key: name
      }), /*#__PURE__*/_react.default.createElement(CellLink, {
        text: version,
        url: pluginUrl,
        key: name
      })];
      if (withStatus) {
        row.splice(1, 0, /*#__PURE__*/_react.default.createElement(CellText, {
          text: status,
          key: name
        }));
      }
      return row;
    });
  return /*#__PURE__*/_react.default.createElement(_dataTable.default, {
    selection: true,
    headers: getHeaders(),
    rows: rows,
    onSelect: onSelect,
    initialSelected: initialSelected,
    initialDisabled: initialDisabled,
    layout: layout,
    className: "e-app-import-export-plugins-table"
  });
}
PluginsTable.propTypes = {
  onSelect: PropTypes.func,
  initialDisabled: PropTypes.array,
  initialSelected: PropTypes.array,
  plugins: PropTypes.array,
  withHeader: PropTypes.bool,
  withStatus: PropTypes.bool,
  layout: PropTypes.array
};
PluginsTable.defaultProps = {
  initialDisabled: [],
  initialSelected: [],
  plugins: [],
  withHeader: true,
  withStatus: true
};
var _default = (0, _react.memo)(PluginsTable);
exports["default"] = _default;

/***/ }),

/***/ "../app/modules/import-export/assets/js/shared/plugins-selection/plugins-selection.js":
/*!********************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/shared/plugins-selection/plugins-selection.js ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _pluginsTable = _interopRequireDefault(__webpack_require__(/*! ./components/plugins-table */ "../app/modules/import-export/assets/js/shared/plugins-selection/components/plugins-table.js"));
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function PluginsSelection(_ref) {
  var plugins = _ref.plugins,
    initialSelected = _ref.initialSelected,
    initialDisabled = _ref.initialDisabled,
    withHeader = _ref.withHeader,
    withStatus = _ref.withStatus,
    layout = _ref.layout,
    onSelect = _ref.onSelect;
  if (!plugins.length) {
    return null;
  }

  // eslint-disable-next-line react-hooks/rules-of-hooks
  var cachedPlugins = (0, _react.useMemo)(function () {
      return plugins;
    }, [plugins]),
    // eslint-disable-next-line react-hooks/rules-of-hooks
    cachedInitialSelected = (0, _react.useMemo)(function () {
      return initialSelected;
    }, [plugins]),
    // eslint-disable-next-line react-hooks/rules-of-hooks
    cachedInitialDisabled = (0, _react.useMemo)(function () {
      return initialDisabled;
    }, [plugins]),
    handleOnSelect = function handleOnSelect(selectedIndexes) {
      if (!onSelect) {
        return;
      }
      var selectedPlugins = selectedIndexes.map(function (pluginIndex) {
        return plugins[pluginIndex];
      });
      onSelect(selectedPlugins);
    };
  return /*#__PURE__*/_react.default.createElement(_pluginsTable.default, {
    plugins: cachedPlugins,
    initialDisabled: cachedInitialDisabled,
    initialSelected: cachedInitialSelected,
    onSelect: handleOnSelect,
    withHeader: withHeader,
    withStatus: withStatus,
    layout: layout
  });
}
PluginsSelection.propTypes = {
  initialDisabled: PropTypes.array,
  initialSelected: PropTypes.array,
  layout: PropTypes.array,
  onSelect: PropTypes.func,
  plugins: PropTypes.array,
  selection: PropTypes.bool,
  withHeader: PropTypes.bool,
  withStatus: PropTypes.bool
};
PluginsSelection.defaultProps = {
  initialDisabled: [],
  initialSelected: [],
  plugins: [],
  selection: true,
  withHeader: true,
  withStatus: true
};
var _default = (0, _react.memo)(PluginsSelection);
exports["default"] = _default;

/***/ }),

/***/ "../app/modules/import-export/assets/js/shared/process-failed-dialog/process-failed-dialog.js":
/*!****************************************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/shared/process-failed-dialog/process-failed-dialog.js ***!
  \****************************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = ProcessFailedDialog;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _router = __webpack_require__(/*! @reach/router */ "../node_modules/@reach/router/es/index.js");
var _dialog = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/dialog/dialog */ "../app/assets/js/ui/dialog/dialog.js"));
var _useQueryParams = _interopRequireDefault(__webpack_require__(/*! elementor-app/hooks/use-query-params */ "../app/assets/js/hooks/use-query-params.js"));
var _useAction = _interopRequireDefault(__webpack_require__(/*! elementor-app/hooks/use-action */ "../app/assets/js/hooks/use-action.js"));
var _inlineLink = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/molecules/inline-link */ "../app/assets/js/ui/molecules/inline-link.js"));
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
var messagesContent = {
  general: {
    title: __('Unable to download the Kit', 'elementor'),
    text: /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, __('We couldn’t download the Kit due to technical difficulties on our part. Try again and if the problem persists contact ', 'elementor'), /*#__PURE__*/_react.default.createElement(_inlineLink.default, {
      url: "https://my.elementor.com/support-center/"
    }, __('Support', 'elementor')))
  },
  'zip-archive-module-missing': {
    title: __('Couldn’t handle the Kit', 'elementor'),
    text: __('Seems like your server is missing the PHP zip module. Install it on your server or contact your site host for further instructions.', 'elementor')
  },
  'invalid-zip-file': {
    title: __('Couldn’t use the Kit', 'elementor'),
    text: /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, __('Seems like there is a problem with the Kit’s files. Try installing again and if the problem persists contact ', 'elementor'), /*#__PURE__*/_react.default.createElement(_inlineLink.default, {
      url: "https://my.elementor.com/support-center/"
    }, __('Support', 'elementor')))
  },
  timeout: {
    title: __('Unable to download the Kit', 'elementor'),
    text: /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, __('It took too much time to download your Kit and we were unable to complete the process. If all the Kit’s parts don’t appear in ', 'elementor'), /*#__PURE__*/_react.default.createElement(_inlineLink.default, {
      url: elementorAppConfig.pages_url
    }, __('Pages', 'elementor')), __(', try again and if the problem persists contact ', 'elementor'), /*#__PURE__*/_react.default.createElement(_inlineLink.default, {
      url: "https://my.elementor.com/support-center/"
    }, __('Support', 'elementor')))
  },
  'invalid-kit-library-zip-error': {
    title: __('Unable to download the Kit', 'elementor'),
    text: /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, __('We couldn’t download the Kit due to technical difficulty on our part. Try again in a few minutes and if the problem persists contact ', 'elementor'), /*#__PURE__*/_react.default.createElement(_inlineLink.default, {
      url: "https://my.elementor.com/support-center/"
    }, __('Support', 'elementor')))
  },
  'no-write-permissions': {
    title: __('Couldn’t access the file', 'elementor'),
    text: __('Seems like Elementor isn’t authorized to access relevant files for installing this Kit. Contact your site host to get permission.', 'elementor')
  },
  'plugin-installation-permissions-error': {
    title: __('Couldn’t install the Kit', 'elementor'),
    text: __('The Kit includes plugins you don’t have permission to install. Contact your site admin to change your permissions.', 'elementor')
  }
};
function ProcessFailedDialog(_ref) {
  var errorType = _ref.errorType,
    onApprove = _ref.onApprove,
    onDismiss = _ref.onDismiss,
    approveButton = _ref.approveButton,
    dismissButton = _ref.dismissButton,
    onModalClose = _ref.onModalClose,
    onError = _ref.onError,
    onLearnMore = _ref.onLearnMore;
  var action = (0, _useAction.default)(),
    navigate = (0, _router.useNavigate)(),
    _useQueryParams$getAl = (0, _useQueryParams.default)().getAll(),
    referrer = _useQueryParams$getAl.referrer,
    error = 'string' === typeof errorType && messagesContent[errorType] ? errorType : 'general',
    _messagesContent$erro = messagesContent[error],
    title = _messagesContent$erro.title,
    text = _messagesContent$erro.text,
    tryAgainText = __('Try Again', 'elementor'),
    isTryAgainAction = 'general' === error && onApprove,
    handleOnApprove = function handleOnApprove() {
      /*
      * When the errorType is general, there should be an option to trigger the onApprove function.
      * All other error messages should open the learn-more link.
      */
      if (isTryAgainAction) {
        onApprove();
      } else {
        window.open('https://go.elementor.com/app-import-download-failed', '_blank');
      }
      onLearnMore === null || onLearnMore === void 0 ? void 0 : onLearnMore();
    },
    handleOnDismiss = function handleOnDismiss(event) {
      if ('general' === error && onDismiss) {
        onDismiss();
      } else if ('kit-library' === referrer) {
        onModalClose === null || onModalClose === void 0 ? void 0 : onModalClose(event);
        navigate('/kit-library');
      } else {
        action.backToDashboard();
      }
    };
  (0, _react.useEffect)(function () {
    onError === null || onError === void 0 ? void 0 : onError();
  }, []);
  return /*#__PURE__*/_react.default.createElement(_dialog.default, {
    title: title,
    text: text,
    approveButtonColor: "link",
    approveButtonText: isTryAgainAction ? tryAgainText : approveButton,
    approveButtonOnClick: handleOnApprove,
    dismissButtonText: dismissButton,
    dismissButtonOnClick: function dismissButtonOnClick(event) {
      return handleOnDismiss(event);
    },
    onClose: handleOnDismiss
  });
}
ProcessFailedDialog.propTypes = {
  onApprove: PropTypes.func,
  onDismiss: PropTypes.func,
  errorType: PropTypes.string,
  approveButton: PropTypes.string,
  dismissButton: PropTypes.string,
  onModalClose: PropTypes.func,
  onError: PropTypes.func,
  onLearnMore: PropTypes.func
};
ProcessFailedDialog.defaultProps = {
  errorType: 'general',
  approveButton: __('Learn More', 'elementor'),
  dismissButton: __('Close', 'elementor')
};

/***/ }),

/***/ "../app/modules/import-export/assets/js/templates/layout.js":
/*!******************************************************************!*\
  !*** ../app/modules/import-export/assets/js/templates/layout.js ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var __ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n")["__"];
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = Layout;
var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));
var _toConsumableArray2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/toConsumableArray */ "../node_modules/@babel/runtime/helpers/toConsumableArray.js"));
var _defineProperty2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "../node_modules/@babel/runtime/helpers/defineProperty.js"));
var _slicedToArray2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "../node_modules/@babel/runtime/helpers/slicedToArray.js"));
var _page = _interopRequireDefault(__webpack_require__(/*! elementor-app/layout/page */ "../app/assets/js/layout/page.js"));
var _contentLayout = _interopRequireDefault(__webpack_require__(/*! ../shared/content-layout/content-layout */ "../app/modules/import-export/assets/js/shared/content-layout/content-layout.js"));
var _infoModal = __webpack_require__(/*! ../shared/info-modal/info-modal */ "../app/modules/import-export/assets/js/shared/info-modal/info-modal.js");
var _importInfoModal = _interopRequireDefault(__webpack_require__(/*! ../shared/info-modal/import-info-modal */ "../app/modules/import-export/assets/js/shared/info-modal/import-info-modal.js"));
var _exportInfoModal = _interopRequireDefault(__webpack_require__(/*! ../shared/info-modal/export-info-modal */ "../app/modules/import-export/assets/js/shared/info-modal/export-info-modal.js"));
var _sharedContextProvider = __webpack_require__(/*! ../context/shared-context/shared-context-provider */ "../app/modules/import-export/assets/js/context/shared-context/shared-context-provider.js");
var _appsEventTracking = __webpack_require__(/*! elementor-app/event-track/apps-event-tracking */ "../app/assets/js/event-track/apps-event-tracking.js");
var _useQueryParams = _interopRequireDefault(__webpack_require__(/*! elementor-app/hooks/use-query-params */ "../app/assets/js/hooks/use-query-params.js"));
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { (0, _defineProperty2.default)(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function Layout(props) {
  var _useState = (0, _react.useState)(false),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    showInfoModal = _useState2[0],
    setShowInfoModal = _useState2[1],
    _useQueryParams$getAl = (0, _useQueryParams.default)().getAll(),
    referrer = _useQueryParams$getAl.referrer,
    sharedContext = (0, _react.useContext)(_sharedContextProvider.SharedContext),
    currentPage = sharedContext.data.currentPage,
    eventTracking = function eventTracking(command) {
      var elementPosition = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
      var element = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : null;
      var eventType = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 'click';
      var modalType = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : null;
      if ('kit-library' === sharedContext.data.referrer || referrer) {
        (0, _appsEventTracking.appsEventTrackingDispatch)(command, {
          element: element,
          page_source: 'import',
          event_type: eventType,
          step: currentPage,
          element_position: elementPosition,
          modal_type: modalType
        });
      }
    },
    onModalClose = function onModalClose(e, command) {
      var element = e.target.classList.contains('eps-modal__overlay') ? 'overlay' : 'x';
      eventTracking(command, element, null, 'info');
    },
    getContent = function getContent() {
      var infoModalProps = {
        show: showInfoModal,
        setShow: setShowInfoModal
      };
      if ('kit-library' === sharedContext.data.referrer || referrer) {
        infoModalProps = _objectSpread(_objectSpread({
          referrer: referrer
        }, infoModalProps), {}, {
          onOpen: function onOpen() {
            return eventTracking('kit-library/modal-open', null, null, 'load', 'info');
          },
          onClose: function onClose(e) {
            return onModalClose(e, 'kit-library/modal-close');
          }
        });
      }
      return /*#__PURE__*/_react.default.createElement(_contentLayout.default, null, props.children, 'import' === props.type ? /*#__PURE__*/_react.default.createElement(_importInfoModal.default, infoModalProps) : /*#__PURE__*/_react.default.createElement(_exportInfoModal.default, infoModalProps));
    },
    getInfoButtonProps = function getInfoButtonProps() {
      return _objectSpread(_objectSpread({}, _infoModal.infoButtonProps), {}, {
        onClick: function onClick() {
          eventTracking('kit-library/seek-more-info', 'app_header');
          setShowInfoModal(true);
        }
      });
    },
    _onClose = function onClose() {
      eventTracking('kit-library/close', 'app_header', null, 'click');
      window.top.location = elementorAppConfig.admin_url;
    },
    config = {
      title: 'import' === props.type ? __('Import', 'elementor') : __('Export', 'elementor'),
      headerButtons: [getInfoButtonProps()].concat((0, _toConsumableArray2.default)(props.headerButtons)),
      content: getContent(),
      footer: props.footer,
      onClose: function onClose() {
        return _onClose();
      }
    },
    moduleAdminTab = '#tab-import-export-kit';

  // Targeting the return_url value to the import-export dedicated admin tab (only when there is no specific referrer).
  if (!referrer && -1 === elementorAppConfig.return_url.indexOf(moduleAdminTab) && elementorAppConfig.return_url.includes('page=elementor-tools')) {
    elementorAppConfig.return_url += moduleAdminTab;
  }
  (0, _react.useEffect)(function () {
    if (referrer) {
      sharedContext.dispatch({
        type: 'SET_REFERRER',
        payload: referrer
      });
    }
  }, [referrer]);
  return /*#__PURE__*/_react.default.createElement(_page.default, config);
}
Layout.propTypes = {
  type: PropTypes.oneOf(['import', 'export']),
  headerButtons: PropTypes.arrayOf(PropTypes.object),
  children: PropTypes.object.isRequired,
  footer: PropTypes.object
};
Layout.defaultProps = {
  headerButtons: []
};

/***/ }),

/***/ "../app/modules/import-export/assets/js/ui/loader/loader.js":
/*!******************************************************************!*\
  !*** ../app/modules/import-export/assets/js/ui/loader/loader.js ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = Loader;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
var _icon = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/icon */ "../app/assets/js/ui/atoms/icon.js"));
__webpack_require__(/*! ./loader.scss */ "../app/modules/import-export/assets/js/ui/loader/loader.scss");
function Loader(_ref) {
  var absoluteCenter = _ref.absoluteCenter;
  var baseClassName = 'e-app-import-export-loader',
    classes = [baseClassName, 'eicon-loading eicon-animation-spin'];
  if (absoluteCenter) {
    classes.push(baseClassName + '--absolute-center');
  }
  return /*#__PURE__*/_react.default.createElement(_icon.default, {
    className: (0, _utils.arrayToClassName)(classes)
  });
}
Loader.propTypes = {
  absoluteCenter: PropTypes.bool
};
Loader.defaultProps = {
  absoluteCenter: false
};

/***/ }),

/***/ "../app/modules/import-export/assets/js/ui/message-banner/message-banner.js":
/*!**********************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/ui/message-banner/message-banner.js ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = MessageBanner;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _heading = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/heading */ "../app/assets/js/ui/atoms/heading.js"));
var _text = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/text */ "../app/assets/js/ui/atoms/text.js"));
var _box = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/box */ "../app/assets/js/ui/atoms/box.js"));
var _grid = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/grid/grid */ "../app/assets/js/ui/grid/grid.js"));
__webpack_require__(/*! ./message-banner.scss */ "../app/modules/import-export/assets/js/ui/message-banner/message-banner.scss");
function MessageBanner(_ref) {
  var heading = _ref.heading,
    description = _ref.description,
    button = _ref.button;
  var getDescriptionContent = function getDescriptionContent() {
    if (Array.isArray(description)) {
      return description.join( /*#__PURE__*/_react.default.createElement("br", null));
    }
    return description;
  };
  return /*#__PURE__*/_react.default.createElement(_box.default, {
    className: "e-app-import-export-message-banner",
    padding: "20"
  }, /*#__PURE__*/_react.default.createElement(_grid.default, {
    container: true,
    alignItems: "center",
    justify: "space-between"
  }, /*#__PURE__*/_react.default.createElement(_grid.default, {
    item: true
  }, heading && /*#__PURE__*/_react.default.createElement(_heading.default, {
    className: "e-app-import-export-message-banner__heading",
    variant: "h3",
    tag: "h3"
  }, heading), description && /*#__PURE__*/_react.default.createElement(_text.default, {
    className: "e-app-import-export-message-banner__description"
  }, getDescriptionContent())), button && /*#__PURE__*/_react.default.createElement(_grid.default, {
    item: true
  }, button)));
}
MessageBanner.propTypes = {
  heading: PropTypes.string,
  description: PropTypes.oneOfType([PropTypes.string, PropTypes.array]),
  button: PropTypes.object
};

/***/ }),

/***/ "../app/modules/import-export/assets/js/ui/page-header/page-header.js":
/*!****************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/ui/page-header/page-header.js ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = PageHeader;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
var _grid = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/grid/grid */ "../app/assets/js/ui/grid/grid.js"));
var _heading = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/heading */ "../app/assets/js/ui/atoms/heading.js"));
var _text = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/text */ "../app/assets/js/ui/atoms/text.js"));
__webpack_require__(/*! ./page-header.scss */ "../app/modules/import-export/assets/js/ui/page-header/page-header.scss");
// Page header.
function PageHeader(props) {
  var baseClassName = 'e-app-import-export-page-header',
    classes = [baseClassName, props.className];
  var handleMultiLine = function handleMultiLine(content) {
    if (Array.isArray(content)) {
      var multiLineArray = [];
      content.forEach(function (line, index) {
        if (index) {
          multiLineArray.push( /*#__PURE__*/_react.default.createElement("br", {
            key: index
          }));
        }
        multiLineArray.push(line);
      });
      return multiLineArray;
    }
    return content;
  };
  return /*#__PURE__*/_react.default.createElement("div", {
    className: (0, _utils.arrayToClassName)(classes)
  }, /*#__PURE__*/_react.default.createElement(_grid.default, {
    container: true
  }, /*#__PURE__*/_react.default.createElement(_grid.default, {
    item: true,
    className: "e-app-import-export-page-header__content-wrapper"
  }, props.heading && /*#__PURE__*/_react.default.createElement(_heading.default, {
    variant: "display-3",
    className: "e-app-import-export-page-header__heading"
  }, props.heading), props.description && /*#__PURE__*/_react.default.createElement(_text.default, {
    className: "e-app-import-export-page-header__description"
  }, handleMultiLine(props.description)))));
}
PageHeader.propTypes = {
  className: PropTypes.string,
  heading: PropTypes.string,
  description: PropTypes.oneOfType([PropTypes.string, PropTypes.array, PropTypes.object])
};
PageHeader.defaultProps = {
  className: ''
};

/***/ }),

/***/ "../app/modules/import-export/assets/js/ui/wizard-step/wizard-step.js":
/*!****************************************************************************!*\
  !*** ../app/modules/import-export/assets/js/ui/wizard-step/wizard-step.js ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var PropTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = WizardStep;
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _utils = __webpack_require__(/*! elementor-app/utils/utils.js */ "../app/assets/js/utils/utils.js");
var _grid = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/grid/grid */ "../app/assets/js/ui/grid/grid.js"));
var _icon = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/icon */ "../app/assets/js/ui/atoms/icon.js"));
var _heading = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/heading */ "../app/assets/js/ui/atoms/heading.js"));
var _text = _interopRequireDefault(__webpack_require__(/*! elementor-app/ui/atoms/text */ "../app/assets/js/ui/atoms/text.js"));
__webpack_require__(/*! ./wizard-step.scss */ "../app/modules/import-export/assets/js/ui/wizard-step/wizard-step.scss");
function WizardStep(props) {
  var baseClassName = 'e-app-import-export-wizard-step',
    classes = [baseClassName, props.className];
  return /*#__PURE__*/_react.default.createElement(_grid.default, {
    className: (0, _utils.arrayToClassName)(classes),
    justify: "center",
    container: true
  }, /*#__PURE__*/_react.default.createElement(_grid.default, {
    item: true
  }, (props.image || props.icon) && /*#__PURE__*/_react.default.createElement(_grid.default, {
    className: "e-app-import-export-wizard-step__media-container",
    justify: "center",
    alignItems: "end",
    container: true
  }, props.image &&
  /*#__PURE__*/
  // eslint-disable-next-line jsx-a11y/alt-text
  _react.default.createElement("img", {
    className: "e-app-import-export-wizard-step__image",
    src: props.image
  }), props.icon && /*#__PURE__*/_react.default.createElement(_icon.default, {
    className: "e-app-import-export-wizard-step__icon ".concat(props.icon)
  })), props.heading && /*#__PURE__*/_react.default.createElement(_heading.default, {
    variant: "display-3",
    className: "e-app-import-export-wizard-step__heading"
  }, props.heading), props.description && /*#__PURE__*/_react.default.createElement(_text.default, {
    variant: "xl",
    className: "e-app-import-export-wizard-step__description"
  }, props.description), props.info && /*#__PURE__*/_react.default.createElement(_text.default, {
    variant: "xl",
    className: "e-app-import-export-wizard-step__info"
  }, props.info), props.children && /*#__PURE__*/_react.default.createElement(_grid.default, {
    item: true,
    className: "e-app-import-export-wizard-step__content"
  }, props.children), props.notice && /*#__PURE__*/_react.default.createElement(_text.default, {
    variant: "xs",
    className: "e-app-import-export-wizard-step__notice"
  }, props.notice)));
}
WizardStep.propTypes = {
  className: PropTypes.string,
  image: PropTypes.string,
  icon: PropTypes.string,
  heading: PropTypes.string,
  description: PropTypes.oneOfType([PropTypes.string, PropTypes.object]),
  info: PropTypes.oneOfType([PropTypes.string, PropTypes.object]),
  notice: PropTypes.oneOfType([PropTypes.string, PropTypes.object]),
  children: PropTypes.any
};
WizardStep.defaultProps = {
  className: ''
};

/***/ }),

/***/ "../app/modules/kit-library/assets/js/data/kits/commands-data/download-link.js":
/*!*************************************************************************************!*\
  !*** ../app/modules/kit-library/assets/js/data/kits/commands-data/download-link.js ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.DownloadLink = void 0;
var _classCallCheck2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "../node_modules/@babel/runtime/helpers/classCallCheck.js"));
var _createClass2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/createClass */ "../node_modules/@babel/runtime/helpers/createClass.js"));
var _inherits2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/inherits */ "../node_modules/@babel/runtime/helpers/inherits.js"));
var _possibleConstructorReturn2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/possibleConstructorReturn */ "../node_modules/@babel/runtime/helpers/possibleConstructorReturn.js"));
var _getPrototypeOf2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/getPrototypeOf */ "../node_modules/@babel/runtime/helpers/getPrototypeOf.js"));
function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0, _getPrototypeOf2.default)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0, _getPrototypeOf2.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0, _possibleConstructorReturn2.default)(this, result); }; }
function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var DownloadLink = /*#__PURE__*/function (_$e$modules$CommandDa) {
  (0, _inherits2.default)(DownloadLink, _$e$modules$CommandDa);
  var _super = _createSuper(DownloadLink);
  function DownloadLink() {
    (0, _classCallCheck2.default)(this, DownloadLink);
    return _super.apply(this, arguments);
  }
  (0, _createClass2.default)(DownloadLink, null, [{
    key: "getEndpointFormat",
    value: function getEndpointFormat() {
      return 'kits/download-link/{id}';
    }
  }]);
  return DownloadLink;
}($e.modules.CommandData);
exports.DownloadLink = DownloadLink;

/***/ }),

/***/ "../app/modules/kit-library/assets/js/data/kits/commands-data/favorites.js":
/*!*********************************************************************************!*\
  !*** ../app/modules/kit-library/assets/js/data/kits/commands-data/favorites.js ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.Favorites = void 0;
var _classCallCheck2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "../node_modules/@babel/runtime/helpers/classCallCheck.js"));
var _createClass2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/createClass */ "../node_modules/@babel/runtime/helpers/createClass.js"));
var _inherits2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/inherits */ "../node_modules/@babel/runtime/helpers/inherits.js"));
var _possibleConstructorReturn2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/possibleConstructorReturn */ "../node_modules/@babel/runtime/helpers/possibleConstructorReturn.js"));
var _getPrototypeOf2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/getPrototypeOf */ "../node_modules/@babel/runtime/helpers/getPrototypeOf.js"));
function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0, _getPrototypeOf2.default)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0, _getPrototypeOf2.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0, _possibleConstructorReturn2.default)(this, result); }; }
function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var Favorites = /*#__PURE__*/function (_$e$modules$CommandDa) {
  (0, _inherits2.default)(Favorites, _$e$modules$CommandDa);
  var _super = _createSuper(Favorites);
  function Favorites() {
    (0, _classCallCheck2.default)(this, Favorites);
    return _super.apply(this, arguments);
  }
  (0, _createClass2.default)(Favorites, null, [{
    key: "getEndpointFormat",
    value: function getEndpointFormat() {
      return 'kits/favorites/{id}';
    }
  }]);
  return Favorites;
}($e.modules.CommandData);
exports.Favorites = Favorites;

/***/ }),

/***/ "../app/modules/kit-library/assets/js/data/kits/commands-data/index.js":
/*!*****************************************************************************!*\
  !*** ../app/modules/kit-library/assets/js/data/kits/commands-data/index.js ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
Object.defineProperty(exports, "DownloadLink", ({
  enumerable: true,
  get: function get() {
    return _downloadLink.DownloadLink;
  }
}));
Object.defineProperty(exports, "Favorites", ({
  enumerable: true,
  get: function get() {
    return _favorites.Favorites;
  }
}));
exports.Index = void 0;
var _classCallCheck2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "../node_modules/@babel/runtime/helpers/classCallCheck.js"));
var _createClass2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/createClass */ "../node_modules/@babel/runtime/helpers/createClass.js"));
var _inherits2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/inherits */ "../node_modules/@babel/runtime/helpers/inherits.js"));
var _possibleConstructorReturn2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/possibleConstructorReturn */ "../node_modules/@babel/runtime/helpers/possibleConstructorReturn.js"));
var _getPrototypeOf2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/getPrototypeOf */ "../node_modules/@babel/runtime/helpers/getPrototypeOf.js"));
var _downloadLink = __webpack_require__(/*! ./download-link */ "../app/modules/kit-library/assets/js/data/kits/commands-data/download-link.js");
var _favorites = __webpack_require__(/*! ./favorites */ "../app/modules/kit-library/assets/js/data/kits/commands-data/favorites.js");
function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0, _getPrototypeOf2.default)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0, _getPrototypeOf2.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0, _possibleConstructorReturn2.default)(this, result); }; }
function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var Index = /*#__PURE__*/function (_$e$modules$CommandDa) {
  (0, _inherits2.default)(Index, _$e$modules$CommandDa);
  var _super = _createSuper(Index);
  function Index() {
    (0, _classCallCheck2.default)(this, Index);
    return _super.apply(this, arguments);
  }
  (0, _createClass2.default)(Index, null, [{
    key: "getEndpointFormat",
    value: function getEndpointFormat() {
      return 'kits/{id}';
    }
  }]);
  return Index;
}($e.modules.CommandData);
exports.Index = Index;

/***/ }),

/***/ "../app/modules/kit-library/assets/js/data/kits/component.js":
/*!*******************************************************************!*\
  !*** ../app/modules/kit-library/assets/js/data/kits/component.js ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _classCallCheck2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "../node_modules/@babel/runtime/helpers/classCallCheck.js"));
var _createClass2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/createClass */ "../node_modules/@babel/runtime/helpers/createClass.js"));
var _inherits2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/inherits */ "../node_modules/@babel/runtime/helpers/inherits.js"));
var _possibleConstructorReturn2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/possibleConstructorReturn */ "../node_modules/@babel/runtime/helpers/possibleConstructorReturn.js"));
var _getPrototypeOf2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/getPrototypeOf */ "../node_modules/@babel/runtime/helpers/getPrototypeOf.js"));
var commandsData = _interopRequireWildcard(__webpack_require__(/*! ./commands-data/ */ "../app/modules/kit-library/assets/js/data/kits/commands-data/index.js"));
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0, _getPrototypeOf2.default)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0, _getPrototypeOf2.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0, _possibleConstructorReturn2.default)(this, result); }; }
function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var Component = /*#__PURE__*/function (_$e$modules$Component) {
  (0, _inherits2.default)(Component, _$e$modules$Component);
  var _super = _createSuper(Component);
  function Component() {
    (0, _classCallCheck2.default)(this, Component);
    return _super.apply(this, arguments);
  }
  (0, _createClass2.default)(Component, [{
    key: "getNamespace",
    value: function getNamespace() {
      return 'kits';
    }
  }, {
    key: "defaultData",
    value: function defaultData() {
      return this.importCommands(commandsData);
    }
  }]);
  return Component;
}($e.modules.ComponentBase);
exports["default"] = Component;

/***/ }),

/***/ "../app/modules/kit-library/assets/js/data/taxonomies/commands-data/index.js":
/*!***********************************************************************************!*\
  !*** ../app/modules/kit-library/assets/js/data/taxonomies/commands-data/index.js ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.Index = void 0;
var _classCallCheck2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "../node_modules/@babel/runtime/helpers/classCallCheck.js"));
var _createClass2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/createClass */ "../node_modules/@babel/runtime/helpers/createClass.js"));
var _inherits2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/inherits */ "../node_modules/@babel/runtime/helpers/inherits.js"));
var _possibleConstructorReturn2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/possibleConstructorReturn */ "../node_modules/@babel/runtime/helpers/possibleConstructorReturn.js"));
var _getPrototypeOf2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/getPrototypeOf */ "../node_modules/@babel/runtime/helpers/getPrototypeOf.js"));
function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0, _getPrototypeOf2.default)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0, _getPrototypeOf2.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0, _possibleConstructorReturn2.default)(this, result); }; }
function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var Index = /*#__PURE__*/function (_$e$modules$CommandDa) {
  (0, _inherits2.default)(Index, _$e$modules$CommandDa);
  var _super = _createSuper(Index);
  function Index() {
    (0, _classCallCheck2.default)(this, Index);
    return _super.apply(this, arguments);
  }
  (0, _createClass2.default)(Index, null, [{
    key: "getEndpointFormat",
    value: function getEndpointFormat() {
      return 'kit-taxonomies/{id}';
    }
  }]);
  return Index;
}($e.modules.CommandData);
exports.Index = Index;

/***/ }),

/***/ "../app/modules/kit-library/assets/js/data/taxonomies/component.js":
/*!*************************************************************************!*\
  !*** ../app/modules/kit-library/assets/js/data/taxonomies/component.js ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/@babel/runtime/helpers/typeof.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _classCallCheck2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "../node_modules/@babel/runtime/helpers/classCallCheck.js"));
var _createClass2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/createClass */ "../node_modules/@babel/runtime/helpers/createClass.js"));
var _inherits2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/inherits */ "../node_modules/@babel/runtime/helpers/inherits.js"));
var _possibleConstructorReturn2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/possibleConstructorReturn */ "../node_modules/@babel/runtime/helpers/possibleConstructorReturn.js"));
var _getPrototypeOf2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/getPrototypeOf */ "../node_modules/@babel/runtime/helpers/getPrototypeOf.js"));
var commandsData = _interopRequireWildcard(__webpack_require__(/*! ./commands-data/ */ "../app/modules/kit-library/assets/js/data/taxonomies/commands-data/index.js"));
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0, _getPrototypeOf2.default)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0, _getPrototypeOf2.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0, _possibleConstructorReturn2.default)(this, result); }; }
function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var Component = /*#__PURE__*/function (_$e$modules$Component) {
  (0, _inherits2.default)(Component, _$e$modules$Component);
  var _super = _createSuper(Component);
  function Component() {
    (0, _classCallCheck2.default)(this, Component);
    return _super.apply(this, arguments);
  }
  (0, _createClass2.default)(Component, [{
    key: "getNamespace",
    value: function getNamespace() {
      return 'kit-taxonomies';
    }
  }, {
    key: "defaultData",
    value: function defaultData() {
      return this.importCommands(commandsData);
    }
  }]);
  return Component;
}($e.modules.ComponentBase);
exports["default"] = Component;

/***/ }),

/***/ "../app/modules/kit-library/assets/js/e-component.js":
/*!***********************************************************!*\
  !*** ../app/modules/kit-library/assets/js/e-component.js ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _defineProperty2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "../node_modules/@babel/runtime/helpers/defineProperty.js"));
var _classCallCheck2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "../node_modules/@babel/runtime/helpers/classCallCheck.js"));
var _createClass2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/createClass */ "../node_modules/@babel/runtime/helpers/createClass.js"));
var _inherits2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/inherits */ "../node_modules/@babel/runtime/helpers/inherits.js"));
var _possibleConstructorReturn2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/possibleConstructorReturn */ "../node_modules/@babel/runtime/helpers/possibleConstructorReturn.js"));
var _getPrototypeOf2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/getPrototypeOf */ "../node_modules/@babel/runtime/helpers/getPrototypeOf.js"));
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { (0, _defineProperty2.default)(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0, _getPrototypeOf2.default)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0, _getPrototypeOf2.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0, _possibleConstructorReturn2.default)(this, result); }; }
function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
var EComponent = /*#__PURE__*/function (_$e$modules$Component) {
  (0, _inherits2.default)(EComponent, _$e$modules$Component);
  var _super = _createSuper(EComponent);
  function EComponent() {
    (0, _classCallCheck2.default)(this, EComponent);
    return _super.apply(this, arguments);
  }
  (0, _createClass2.default)(EComponent, [{
    key: "getNamespace",
    value:
    /**
     * @return {string} the namespace of the component
     */
    function getNamespace() {
      return 'kit-library';
    }

    /**
     * @return {*} All the commands of the components
     */
  }, {
    key: "defaultCommands",
    value: function defaultCommands() {
      var trackingCommands = ['apply-kit', 'approve-import', 'approve-selection', 'back-to-library', 'browse', 'change-sort-direction', 'change-sort-type', 'change-sort-value', 'check', 'check-item', 'check-out-kit', 'checking-a-checkbox', 'check-kits-on-theme-forest', 'checkbox-filtration', 'collapse', 'choose-file', 'choose-site-parts-to-import', 'clear-filter', 'close', 'drop', 'enable', 'expand', 'file-upload', 'filter', 'filter-selection', 'favorite-icon', 'go-back', 'go-back-to-view-kits', 'kit-free-search', 'kit-is-live-load', 'kit-import', 'logo', 'mark-as-favorite', 'modal-close', 'modal-load', 'modal-open', 'modal-error', 'open-site-area', 'refetch', 'responsive-controls', 'see-it-live', 'seek-more-info', 'sidebar-tag-filter', 'skip', 'select-organizing-category', 'top-bar-change-view', 'uncheck', 'unchecking-a-checkbox', 'view-demo-page', 'view-demo-part', 'view-overview-page'].reduce(function (allCommands, command) {
        return _objectSpread(_objectSpread({}, allCommands), {}, (0, _defineProperty2.default)({}, command, function () {}));
      }, {});
      return _objectSpread({}, trackingCommands);
    }
  }]);
  return EComponent;
}($e.modules.ComponentBase);
exports["default"] = EComponent;

/***/ }),

/***/ "../app/modules/kit-library/assets/js/module.js":
/*!******************************************************!*\
  !*** ../app/modules/kit-library/assets/js/module.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var React = __webpack_require__(/*! react */ "react");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _classCallCheck2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "../node_modules/@babel/runtime/helpers/classCallCheck.js"));
var _createClass2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/createClass */ "../node_modules/@babel/runtime/helpers/createClass.js"));
var _component = _interopRequireDefault(__webpack_require__(/*! ./data/kits/component */ "../app/modules/kit-library/assets/js/data/kits/component.js"));
var _router = _interopRequireDefault(__webpack_require__(/*! @elementor/router */ "@elementor/router"));
var _component2 = _interopRequireDefault(__webpack_require__(/*! ./data/taxonomies/component */ "../app/modules/kit-library/assets/js/data/taxonomies/component.js"));
var _eComponent = _interopRequireDefault(__webpack_require__(/*! ./e-component */ "../app/modules/kit-library/assets/js/e-component.js"));
var KitLibrary = /*#__PURE__*/function () {
  function KitLibrary() {
    (0, _classCallCheck2.default)(this, KitLibrary);
    if (!this.hasAccessToModule()) {
      return;
    }
    $e.components.register(new _component.default());
    $e.components.register(new _component2.default());
    $e.components.register(new _eComponent.default());
    _router.default.addRoute({
      path: '/kit-library/*',
      component: React.lazy(function () {
        return Promise.all(/*! import() | kit-library */[__webpack_require__.e("vendors-node_modules_react-query_devtools_index_js"), __webpack_require__.e("kit-library")]).then(__webpack_require__.bind(__webpack_require__, /*! ./app */ "../app/modules/kit-library/assets/js/app.js"));
      })
    });
  }
  (0, _createClass2.default)(KitLibrary, [{
    key: "hasAccessToModule",
    value: function hasAccessToModule() {
      var _elementorAppConfig$k;
      return (_elementorAppConfig$k = elementorAppConfig['kit-library']) === null || _elementorAppConfig$k === void 0 ? void 0 : _elementorAppConfig$k.has_access_to_module;
    }
  }]);
  return KitLibrary;
}();
exports["default"] = KitLibrary;

/***/ }),

/***/ "../app/modules/onboarding/assets/js/module.js":
/*!*****************************************************!*\
  !*** ../app/modules/onboarding/assets/js/module.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
/* provided dependency */ var React = __webpack_require__(/*! react */ "react");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _createClass2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/createClass */ "../node_modules/@babel/runtime/helpers/createClass.js"));
var _classCallCheck2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "../node_modules/@babel/runtime/helpers/classCallCheck.js"));
var _router = _interopRequireDefault(__webpack_require__(/*! @elementor/router */ "@elementor/router"));
var Onboarding = /*#__PURE__*/(0, _createClass2.default)(function Onboarding() {
  (0, _classCallCheck2.default)(this, Onboarding);
  _router.default.addRoute({
    path: '/onboarding/*',
    component: React.lazy(function () {
      return __webpack_require__.e(/*! import() | onboarding */ "onboarding").then(__webpack_require__.bind(__webpack_require__, /*! ./app */ "../app/modules/onboarding/assets/js/app.js"));
    })
  });
});
exports["default"] = Onboarding;

/***/ }),

/***/ "../node_modules/create-react-context/lib/implementation.js":
/*!******************************************************************!*\
  !*** ../node_modules/create-react-context/lib/implementation.js ***!
  \******************************************************************/
/***/ ((module, exports, __webpack_require__) => {

"use strict";


exports.__esModule = true;

var _react = __webpack_require__(/*! react */ "react");

var _react2 = _interopRequireDefault(_react);

var _propTypes = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");

var _propTypes2 = _interopRequireDefault(_propTypes);

var _gud = __webpack_require__(/*! gud */ "../node_modules/gud/index.js");

var _gud2 = _interopRequireDefault(_gud);

var _warning = __webpack_require__(/*! warning */ "../node_modules/warning/warning.js");

var _warning2 = _interopRequireDefault(_warning);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var MAX_SIGNED_31_BIT_INT = 1073741823;

// Inlined Object.is polyfill.
// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/is
function objectIs(x, y) {
  if (x === y) {
    return x !== 0 || 1 / x === 1 / y;
  } else {
    return x !== x && y !== y;
  }
}

function createEventEmitter(value) {
  var handlers = [];
  return {
    on: function on(handler) {
      handlers.push(handler);
    },
    off: function off(handler) {
      handlers = handlers.filter(function (h) {
        return h !== handler;
      });
    },
    get: function get() {
      return value;
    },
    set: function set(newValue, changedBits) {
      value = newValue;
      handlers.forEach(function (handler) {
        return handler(value, changedBits);
      });
    }
  };
}

function onlyChild(children) {
  return Array.isArray(children) ? children[0] : children;
}

function createReactContext(defaultValue, calculateChangedBits) {
  var _Provider$childContex, _Consumer$contextType;

  var contextProp = '__create-react-context-' + (0, _gud2.default)() + '__';

  var Provider = function (_Component) {
    _inherits(Provider, _Component);

    function Provider() {
      var _temp, _this, _ret;

      _classCallCheck(this, Provider);

      for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      return _ret = (_temp = (_this = _possibleConstructorReturn(this, _Component.call.apply(_Component, [this].concat(args))), _this), _this.emitter = createEventEmitter(_this.props.value), _temp), _possibleConstructorReturn(_this, _ret);
    }

    Provider.prototype.getChildContext = function getChildContext() {
      var _ref;

      return _ref = {}, _ref[contextProp] = this.emitter, _ref;
    };

    Provider.prototype.componentWillReceiveProps = function componentWillReceiveProps(nextProps) {
      if (this.props.value !== nextProps.value) {
        var oldValue = this.props.value;
        var newValue = nextProps.value;
        var changedBits = void 0;

        if (objectIs(oldValue, newValue)) {
          changedBits = 0; // No change
        } else {
          changedBits = typeof calculateChangedBits === 'function' ? calculateChangedBits(oldValue, newValue) : MAX_SIGNED_31_BIT_INT;
          if (true) {
            (0, _warning2.default)((changedBits & MAX_SIGNED_31_BIT_INT) === changedBits, 'calculateChangedBits: Expected the return value to be a ' + '31-bit integer. Instead received: %s', changedBits);
          }

          changedBits |= 0;

          if (changedBits !== 0) {
            this.emitter.set(nextProps.value, changedBits);
          }
        }
      }
    };

    Provider.prototype.render = function render() {
      return this.props.children;
    };

    return Provider;
  }(_react.Component);

  Provider.childContextTypes = (_Provider$childContex = {}, _Provider$childContex[contextProp] = _propTypes2.default.object.isRequired, _Provider$childContex);

  var Consumer = function (_Component2) {
    _inherits(Consumer, _Component2);

    function Consumer() {
      var _temp2, _this2, _ret2;

      _classCallCheck(this, Consumer);

      for (var _len2 = arguments.length, args = Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
        args[_key2] = arguments[_key2];
      }

      return _ret2 = (_temp2 = (_this2 = _possibleConstructorReturn(this, _Component2.call.apply(_Component2, [this].concat(args))), _this2), _this2.state = {
        value: _this2.getValue()
      }, _this2.onUpdate = function (newValue, changedBits) {
        var observedBits = _this2.observedBits | 0;
        if ((observedBits & changedBits) !== 0) {
          _this2.setState({ value: _this2.getValue() });
        }
      }, _temp2), _possibleConstructorReturn(_this2, _ret2);
    }

    Consumer.prototype.componentWillReceiveProps = function componentWillReceiveProps(nextProps) {
      var observedBits = nextProps.observedBits;

      this.observedBits = observedBits === undefined || observedBits === null ? MAX_SIGNED_31_BIT_INT // Subscribe to all changes by default
      : observedBits;
    };

    Consumer.prototype.componentDidMount = function componentDidMount() {
      if (this.context[contextProp]) {
        this.context[contextProp].on(this.onUpdate);
      }
      var observedBits = this.props.observedBits;

      this.observedBits = observedBits === undefined || observedBits === null ? MAX_SIGNED_31_BIT_INT // Subscribe to all changes by default
      : observedBits;
    };

    Consumer.prototype.componentWillUnmount = function componentWillUnmount() {
      if (this.context[contextProp]) {
        this.context[contextProp].off(this.onUpdate);
      }
    };

    Consumer.prototype.getValue = function getValue() {
      if (this.context[contextProp]) {
        return this.context[contextProp].get();
      } else {
        return defaultValue;
      }
    };

    Consumer.prototype.render = function render() {
      return onlyChild(this.props.children)(this.state.value);
    };

    return Consumer;
  }(_react.Component);

  Consumer.contextTypes = (_Consumer$contextType = {}, _Consumer$contextType[contextProp] = _propTypes2.default.object, _Consumer$contextType);


  return {
    Provider: Provider,
    Consumer: Consumer
  };
}

exports["default"] = createReactContext;
module.exports = exports['default'];

/***/ }),

/***/ "../node_modules/create-react-context/lib/index.js":
/*!*********************************************************!*\
  !*** ../node_modules/create-react-context/lib/index.js ***!
  \*********************************************************/
/***/ ((module, exports, __webpack_require__) => {

"use strict";


exports.__esModule = true;

var _react = __webpack_require__(/*! react */ "react");

var _react2 = _interopRequireDefault(_react);

var _implementation = __webpack_require__(/*! ./implementation */ "../node_modules/create-react-context/lib/implementation.js");

var _implementation2 = _interopRequireDefault(_implementation);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports["default"] = _react2.default.createContext || _implementation2.default;
module.exports = exports['default'];

/***/ }),

/***/ "../node_modules/gud/index.js":
/*!************************************!*\
  !*** ../node_modules/gud/index.js ***!
  \************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
// @flow


var key = '__global_unique_id__';

module.exports = function() {
  return __webpack_require__.g[key] = (__webpack_require__.g[key] || 0) + 1;
};


/***/ }),

/***/ "../node_modules/hoist-non-react-statics/dist/hoist-non-react-statics.cjs.js":
/*!***********************************************************************************!*\
  !*** ../node_modules/hoist-non-react-statics/dist/hoist-non-react-statics.cjs.js ***!
  \***********************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var reactIs = __webpack_require__(/*! react-is */ "../node_modules/hoist-non-react-statics/node_modules/react-is/index.js");

/**
 * Copyright 2015, Yahoo! Inc.
 * Copyrights licensed under the New BSD License. See the accompanying LICENSE file for terms.
 */
var REACT_STATICS = {
  childContextTypes: true,
  contextType: true,
  contextTypes: true,
  defaultProps: true,
  displayName: true,
  getDefaultProps: true,
  getDerivedStateFromError: true,
  getDerivedStateFromProps: true,
  mixins: true,
  propTypes: true,
  type: true
};
var KNOWN_STATICS = {
  name: true,
  length: true,
  prototype: true,
  caller: true,
  callee: true,
  arguments: true,
  arity: true
};
var FORWARD_REF_STATICS = {
  '$$typeof': true,
  render: true,
  defaultProps: true,
  displayName: true,
  propTypes: true
};
var MEMO_STATICS = {
  '$$typeof': true,
  compare: true,
  defaultProps: true,
  displayName: true,
  propTypes: true,
  type: true
};
var TYPE_STATICS = {};
TYPE_STATICS[reactIs.ForwardRef] = FORWARD_REF_STATICS;
TYPE_STATICS[reactIs.Memo] = MEMO_STATICS;

function getStatics(component) {
  // React v16.11 and below
  if (reactIs.isMemo(component)) {
    return MEMO_STATICS;
  } // React v16.12 and above


  return TYPE_STATICS[component['$$typeof']] || REACT_STATICS;
}

var defineProperty = Object.defineProperty;
var getOwnPropertyNames = Object.getOwnPropertyNames;
var getOwnPropertySymbols = Object.getOwnPropertySymbols;
var getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
var getPrototypeOf = Object.getPrototypeOf;
var objectPrototype = Object.prototype;
function hoistNonReactStatics(targetComponent, sourceComponent, blacklist) {
  if (typeof sourceComponent !== 'string') {
    // don't hoist over string (html) components
    if (objectPrototype) {
      var inheritedComponent = getPrototypeOf(sourceComponent);

      if (inheritedComponent && inheritedComponent !== objectPrototype) {
        hoistNonReactStatics(targetComponent, inheritedComponent, blacklist);
      }
    }

    var keys = getOwnPropertyNames(sourceComponent);

    if (getOwnPropertySymbols) {
      keys = keys.concat(getOwnPropertySymbols(sourceComponent));
    }

    var targetStatics = getStatics(targetComponent);
    var sourceStatics = getStatics(sourceComponent);

    for (var i = 0; i < keys.length; ++i) {
      var key = keys[i];

      if (!KNOWN_STATICS[key] && !(blacklist && blacklist[key]) && !(sourceStatics && sourceStatics[key]) && !(targetStatics && targetStatics[key])) {
        var descriptor = getOwnPropertyDescriptor(sourceComponent, key);

        try {
          // Avoid failures from read-only properties
          defineProperty(targetComponent, key, descriptor);
        } catch (e) {}
      }
    }
  }

  return targetComponent;
}

module.exports = hoistNonReactStatics;


/***/ }),

/***/ "../node_modules/hoist-non-react-statics/node_modules/react-is/cjs/react-is.development.js":
/*!*************************************************************************************************!*\
  !*** ../node_modules/hoist-non-react-statics/node_modules/react-is/cjs/react-is.development.js ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";
/** @license React v16.13.1
 * react-is.development.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */





if (true) {
  (function() {
'use strict';

// The Symbol used to tag the ReactElement-like types. If there is no native Symbol
// nor polyfill, then a plain number is used for performance.
var hasSymbol = typeof Symbol === 'function' && Symbol.for;
var REACT_ELEMENT_TYPE = hasSymbol ? Symbol.for('react.element') : 0xeac7;
var REACT_PORTAL_TYPE = hasSymbol ? Symbol.for('react.portal') : 0xeaca;
var REACT_FRAGMENT_TYPE = hasSymbol ? Symbol.for('react.fragment') : 0xeacb;
var REACT_STRICT_MODE_TYPE = hasSymbol ? Symbol.for('react.strict_mode') : 0xeacc;
var REACT_PROFILER_TYPE = hasSymbol ? Symbol.for('react.profiler') : 0xead2;
var REACT_PROVIDER_TYPE = hasSymbol ? Symbol.for('react.provider') : 0xeacd;
var REACT_CONTEXT_TYPE = hasSymbol ? Symbol.for('react.context') : 0xeace; // TODO: We don't use AsyncMode or ConcurrentMode anymore. They were temporary
// (unstable) APIs that have been removed. Can we remove the symbols?

var REACT_ASYNC_MODE_TYPE = hasSymbol ? Symbol.for('react.async_mode') : 0xeacf;
var REACT_CONCURRENT_MODE_TYPE = hasSymbol ? Symbol.for('react.concurrent_mode') : 0xeacf;
var REACT_FORWARD_REF_TYPE = hasSymbol ? Symbol.for('react.forward_ref') : 0xead0;
var REACT_SUSPENSE_TYPE = hasSymbol ? Symbol.for('react.suspense') : 0xead1;
var REACT_SUSPENSE_LIST_TYPE = hasSymbol ? Symbol.for('react.suspense_list') : 0xead8;
var REACT_MEMO_TYPE = hasSymbol ? Symbol.for('react.memo') : 0xead3;
var REACT_LAZY_TYPE = hasSymbol ? Symbol.for('react.lazy') : 0xead4;
var REACT_BLOCK_TYPE = hasSymbol ? Symbol.for('react.block') : 0xead9;
var REACT_FUNDAMENTAL_TYPE = hasSymbol ? Symbol.for('react.fundamental') : 0xead5;
var REACT_RESPONDER_TYPE = hasSymbol ? Symbol.for('react.responder') : 0xead6;
var REACT_SCOPE_TYPE = hasSymbol ? Symbol.for('react.scope') : 0xead7;

function isValidElementType(type) {
  return typeof type === 'string' || typeof type === 'function' || // Note: its typeof might be other than 'symbol' or 'number' if it's a polyfill.
  type === REACT_FRAGMENT_TYPE || type === REACT_CONCURRENT_MODE_TYPE || type === REACT_PROFILER_TYPE || type === REACT_STRICT_MODE_TYPE || type === REACT_SUSPENSE_TYPE || type === REACT_SUSPENSE_LIST_TYPE || typeof type === 'object' && type !== null && (type.$$typeof === REACT_LAZY_TYPE || type.$$typeof === REACT_MEMO_TYPE || type.$$typeof === REACT_PROVIDER_TYPE || type.$$typeof === REACT_CONTEXT_TYPE || type.$$typeof === REACT_FORWARD_REF_TYPE || type.$$typeof === REACT_FUNDAMENTAL_TYPE || type.$$typeof === REACT_RESPONDER_TYPE || type.$$typeof === REACT_SCOPE_TYPE || type.$$typeof === REACT_BLOCK_TYPE);
}

function typeOf(object) {
  if (typeof object === 'object' && object !== null) {
    var $$typeof = object.$$typeof;

    switch ($$typeof) {
      case REACT_ELEMENT_TYPE:
        var type = object.type;

        switch (type) {
          case REACT_ASYNC_MODE_TYPE:
          case REACT_CONCURRENT_MODE_TYPE:
          case REACT_FRAGMENT_TYPE:
          case REACT_PROFILER_TYPE:
          case REACT_STRICT_MODE_TYPE:
          case REACT_SUSPENSE_TYPE:
            return type;

          default:
            var $$typeofType = type && type.$$typeof;

            switch ($$typeofType) {
              case REACT_CONTEXT_TYPE:
              case REACT_FORWARD_REF_TYPE:
              case REACT_LAZY_TYPE:
              case REACT_MEMO_TYPE:
              case REACT_PROVIDER_TYPE:
                return $$typeofType;

              default:
                return $$typeof;
            }

        }

      case REACT_PORTAL_TYPE:
        return $$typeof;
    }
  }

  return undefined;
} // AsyncMode is deprecated along with isAsyncMode

var AsyncMode = REACT_ASYNC_MODE_TYPE;
var ConcurrentMode = REACT_CONCURRENT_MODE_TYPE;
var ContextConsumer = REACT_CONTEXT_TYPE;
var ContextProvider = REACT_PROVIDER_TYPE;
var Element = REACT_ELEMENT_TYPE;
var ForwardRef = REACT_FORWARD_REF_TYPE;
var Fragment = REACT_FRAGMENT_TYPE;
var Lazy = REACT_LAZY_TYPE;
var Memo = REACT_MEMO_TYPE;
var Portal = REACT_PORTAL_TYPE;
var Profiler = REACT_PROFILER_TYPE;
var StrictMode = REACT_STRICT_MODE_TYPE;
var Suspense = REACT_SUSPENSE_TYPE;
var hasWarnedAboutDeprecatedIsAsyncMode = false; // AsyncMode should be deprecated

function isAsyncMode(object) {
  {
    if (!hasWarnedAboutDeprecatedIsAsyncMode) {
      hasWarnedAboutDeprecatedIsAsyncMode = true; // Using console['warn'] to evade Babel and ESLint

      console['warn']('The ReactIs.isAsyncMode() alias has been deprecated, ' + 'and will be removed in React 17+. Update your code to use ' + 'ReactIs.isConcurrentMode() instead. It has the exact same API.');
    }
  }

  return isConcurrentMode(object) || typeOf(object) === REACT_ASYNC_MODE_TYPE;
}
function isConcurrentMode(object) {
  return typeOf(object) === REACT_CONCURRENT_MODE_TYPE;
}
function isContextConsumer(object) {
  return typeOf(object) === REACT_CONTEXT_TYPE;
}
function isContextProvider(object) {
  return typeOf(object) === REACT_PROVIDER_TYPE;
}
function isElement(object) {
  return typeof object === 'object' && object !== null && object.$$typeof === REACT_ELEMENT_TYPE;
}
function isForwardRef(object) {
  return typeOf(object) === REACT_FORWARD_REF_TYPE;
}
function isFragment(object) {
  return typeOf(object) === REACT_FRAGMENT_TYPE;
}
function isLazy(object) {
  return typeOf(object) === REACT_LAZY_TYPE;
}
function isMemo(object) {
  return typeOf(object) === REACT_MEMO_TYPE;
}
function isPortal(object) {
  return typeOf(object) === REACT_PORTAL_TYPE;
}
function isProfiler(object) {
  return typeOf(object) === REACT_PROFILER_TYPE;
}
function isStrictMode(object) {
  return typeOf(object) === REACT_STRICT_MODE_TYPE;
}
function isSuspense(object) {
  return typeOf(object) === REACT_SUSPENSE_TYPE;
}

exports.AsyncMode = AsyncMode;
exports.ConcurrentMode = ConcurrentMode;
exports.ContextConsumer = ContextConsumer;
exports.ContextProvider = ContextProvider;
exports.Element = Element;
exports.ForwardRef = ForwardRef;
exports.Fragment = Fragment;
exports.Lazy = Lazy;
exports.Memo = Memo;
exports.Portal = Portal;
exports.Profiler = Profiler;
exports.StrictMode = StrictMode;
exports.Suspense = Suspense;
exports.isAsyncMode = isAsyncMode;
exports.isConcurrentMode = isConcurrentMode;
exports.isContextConsumer = isContextConsumer;
exports.isContextProvider = isContextProvider;
exports.isElement = isElement;
exports.isForwardRef = isForwardRef;
exports.isFragment = isFragment;
exports.isLazy = isLazy;
exports.isMemo = isMemo;
exports.isPortal = isPortal;
exports.isProfiler = isProfiler;
exports.isStrictMode = isStrictMode;
exports.isSuspense = isSuspense;
exports.isValidElementType = isValidElementType;
exports.typeOf = typeOf;
  })();
}


/***/ }),

/***/ "../node_modules/hoist-non-react-statics/node_modules/react-is/index.js":
/*!******************************************************************************!*\
  !*** ../node_modules/hoist-non-react-statics/node_modules/react-is/index.js ***!
  \******************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


if (false) {} else {
  module.exports = __webpack_require__(/*! ./cjs/react-is.development.js */ "../node_modules/hoist-non-react-statics/node_modules/react-is/cjs/react-is.development.js");
}


/***/ }),

/***/ "../node_modules/invariant/browser.js":
/*!********************************************!*\
  !*** ../node_modules/invariant/browser.js ***!
  \********************************************/
/***/ ((module) => {

"use strict";
/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



/**
 * Use invariant() to assert state which your program assumes to be true.
 *
 * Provide sprintf-style format (only %s is supported) and arguments
 * to provide information about what broke and what you were
 * expecting.
 *
 * The invariant message will be stripped in production, but the invariant
 * will remain to ensure logic does not differ in production.
 */

var invariant = function(condition, format, a, b, c, d, e, f) {
  if (true) {
    if (format === undefined) {
      throw new Error('invariant requires an error message argument');
    }
  }

  if (!condition) {
    var error;
    if (format === undefined) {
      error = new Error(
        'Minified exception occurred; use the non-minified dev environment ' +
        'for the full error message and additional helpful warnings.'
      );
    } else {
      var args = [a, b, c, d, e, f];
      var argIndex = 0;
      error = new Error(
        format.replace(/%s/g, function() { return args[argIndex++]; })
      );
      error.name = 'Invariant Violation';
    }

    error.framesToPop = 1; // we don't care about invariant's own frame
    throw error;
  }
};

module.exports = invariant;


/***/ }),

/***/ "../node_modules/object-assign/index.js":
/*!**********************************************!*\
  !*** ../node_modules/object-assign/index.js ***!
  \**********************************************/
/***/ ((module) => {

"use strict";
/*
object-assign
(c) Sindre Sorhus
@license MIT
*/


/* eslint-disable no-unused-vars */
var getOwnPropertySymbols = Object.getOwnPropertySymbols;
var hasOwnProperty = Object.prototype.hasOwnProperty;
var propIsEnumerable = Object.prototype.propertyIsEnumerable;

function toObject(val) {
	if (val === null || val === undefined) {
		throw new TypeError('Object.assign cannot be called with null or undefined');
	}

	return Object(val);
}

function shouldUseNative() {
	try {
		if (!Object.assign) {
			return false;
		}

		// Detect buggy property enumeration order in older V8 versions.

		// https://bugs.chromium.org/p/v8/issues/detail?id=4118
		var test1 = new String('abc');  // eslint-disable-line no-new-wrappers
		test1[5] = 'de';
		if (Object.getOwnPropertyNames(test1)[0] === '5') {
			return false;
		}

		// https://bugs.chromium.org/p/v8/issues/detail?id=3056
		var test2 = {};
		for (var i = 0; i < 10; i++) {
			test2['_' + String.fromCharCode(i)] = i;
		}
		var order2 = Object.getOwnPropertyNames(test2).map(function (n) {
			return test2[n];
		});
		if (order2.join('') !== '0123456789') {
			return false;
		}

		// https://bugs.chromium.org/p/v8/issues/detail?id=3056
		var test3 = {};
		'abcdefghijklmnopqrst'.split('').forEach(function (letter) {
			test3[letter] = letter;
		});
		if (Object.keys(Object.assign({}, test3)).join('') !==
				'abcdefghijklmnopqrst') {
			return false;
		}

		return true;
	} catch (err) {
		// We don't expect any of the above to throw, but better to be safe.
		return false;
	}
}

module.exports = shouldUseNative() ? Object.assign : function (target, source) {
	var from;
	var to = toObject(target);
	var symbols;

	for (var s = 1; s < arguments.length; s++) {
		from = Object(arguments[s]);

		for (var key in from) {
			if (hasOwnProperty.call(from, key)) {
				to[key] = from[key];
			}
		}

		if (getOwnPropertySymbols) {
			symbols = getOwnPropertySymbols(from);
			for (var i = 0; i < symbols.length; i++) {
				if (propIsEnumerable.call(from, symbols[i])) {
					to[symbols[i]] = from[symbols[i]];
				}
			}
		}
	}

	return to;
};


/***/ }),

/***/ "../node_modules/prop-types/checkPropTypes.js":
/*!****************************************************!*\
  !*** ../node_modules/prop-types/checkPropTypes.js ***!
  \****************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



var printWarning = function() {};

if (true) {
  var ReactPropTypesSecret = __webpack_require__(/*! ./lib/ReactPropTypesSecret */ "../node_modules/prop-types/lib/ReactPropTypesSecret.js");
  var loggedTypeFailures = {};
  var has = __webpack_require__(/*! ./lib/has */ "../node_modules/prop-types/lib/has.js");

  printWarning = function(text) {
    var message = 'Warning: ' + text;
    if (typeof console !== 'undefined') {
      console.error(message);
    }
    try {
      // --- Welcome to debugging React ---
      // This error was thrown as a convenience so that you can use this stack
      // to find the callsite that caused this warning to fire.
      throw new Error(message);
    } catch (x) { /**/ }
  };
}

/**
 * Assert that the values match with the type specs.
 * Error messages are memorized and will only be shown once.
 *
 * @param {object} typeSpecs Map of name to a ReactPropType
 * @param {object} values Runtime values that need to be type-checked
 * @param {string} location e.g. "prop", "context", "child context"
 * @param {string} componentName Name of the component for error messages.
 * @param {?Function} getStack Returns the component stack.
 * @private
 */
function checkPropTypes(typeSpecs, values, location, componentName, getStack) {
  if (true) {
    for (var typeSpecName in typeSpecs) {
      if (has(typeSpecs, typeSpecName)) {
        var error;
        // Prop type validation may throw. In case they do, we don't want to
        // fail the render phase where it didn't fail before. So we log it.
        // After these have been cleaned up, we'll let them throw.
        try {
          // This is intentionally an invariant that gets caught. It's the same
          // behavior as without this statement except with a better message.
          if (typeof typeSpecs[typeSpecName] !== 'function') {
            var err = Error(
              (componentName || 'React class') + ': ' + location + ' type `' + typeSpecName + '` is invalid; ' +
              'it must be a function, usually from the `prop-types` package, but received `' + typeof typeSpecs[typeSpecName] + '`.' +
              'This often happens because of typos such as `PropTypes.function` instead of `PropTypes.func`.'
            );
            err.name = 'Invariant Violation';
            throw err;
          }
          error = typeSpecs[typeSpecName](values, typeSpecName, componentName, location, null, ReactPropTypesSecret);
        } catch (ex) {
          error = ex;
        }
        if (error && !(error instanceof Error)) {
          printWarning(
            (componentName || 'React class') + ': type specification of ' +
            location + ' `' + typeSpecName + '` is invalid; the type checker ' +
            'function must return `null` or an `Error` but returned a ' + typeof error + '. ' +
            'You may have forgotten to pass an argument to the type checker ' +
            'creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and ' +
            'shape all require an argument).'
          );
        }
        if (error instanceof Error && !(error.message in loggedTypeFailures)) {
          // Only monitor this failure once because there tends to be a lot of the
          // same error.
          loggedTypeFailures[error.message] = true;

          var stack = getStack ? getStack() : '';

          printWarning(
            'Failed ' + location + ' type: ' + error.message + (stack != null ? stack : '')
          );
        }
      }
    }
  }
}

/**
 * Resets warning cache when testing.
 *
 * @private
 */
checkPropTypes.resetWarningCache = function() {
  if (true) {
    loggedTypeFailures = {};
  }
}

module.exports = checkPropTypes;


/***/ }),

/***/ "../node_modules/prop-types/factoryWithTypeCheckers.js":
/*!*************************************************************!*\
  !*** ../node_modules/prop-types/factoryWithTypeCheckers.js ***!
  \*************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



var ReactIs = __webpack_require__(/*! react-is */ "../node_modules/prop-types/node_modules/react-is/index.js");
var assign = __webpack_require__(/*! object-assign */ "../node_modules/object-assign/index.js");

var ReactPropTypesSecret = __webpack_require__(/*! ./lib/ReactPropTypesSecret */ "../node_modules/prop-types/lib/ReactPropTypesSecret.js");
var has = __webpack_require__(/*! ./lib/has */ "../node_modules/prop-types/lib/has.js");
var checkPropTypes = __webpack_require__(/*! ./checkPropTypes */ "../node_modules/prop-types/checkPropTypes.js");

var printWarning = function() {};

if (true) {
  printWarning = function(text) {
    var message = 'Warning: ' + text;
    if (typeof console !== 'undefined') {
      console.error(message);
    }
    try {
      // --- Welcome to debugging React ---
      // This error was thrown as a convenience so that you can use this stack
      // to find the callsite that caused this warning to fire.
      throw new Error(message);
    } catch (x) {}
  };
}

function emptyFunctionThatReturnsNull() {
  return null;
}

module.exports = function(isValidElement, throwOnDirectAccess) {
  /* global Symbol */
  var ITERATOR_SYMBOL = typeof Symbol === 'function' && Symbol.iterator;
  var FAUX_ITERATOR_SYMBOL = '@@iterator'; // Before Symbol spec.

  /**
   * Returns the iterator method function contained on the iterable object.
   *
   * Be sure to invoke the function with the iterable as context:
   *
   *     var iteratorFn = getIteratorFn(myIterable);
   *     if (iteratorFn) {
   *       var iterator = iteratorFn.call(myIterable);
   *       ...
   *     }
   *
   * @param {?object} maybeIterable
   * @return {?function}
   */
  function getIteratorFn(maybeIterable) {
    var iteratorFn = maybeIterable && (ITERATOR_SYMBOL && maybeIterable[ITERATOR_SYMBOL] || maybeIterable[FAUX_ITERATOR_SYMBOL]);
    if (typeof iteratorFn === 'function') {
      return iteratorFn;
    }
  }

  /**
   * Collection of methods that allow declaration and validation of props that are
   * supplied to React components. Example usage:
   *
   *   var Props = require('ReactPropTypes');
   *   var MyArticle = React.createClass({
   *     propTypes: {
   *       // An optional string prop named "description".
   *       description: Props.string,
   *
   *       // A required enum prop named "category".
   *       category: Props.oneOf(['News','Photos']).isRequired,
   *
   *       // A prop named "dialog" that requires an instance of Dialog.
   *       dialog: Props.instanceOf(Dialog).isRequired
   *     },
   *     render: function() { ... }
   *   });
   *
   * A more formal specification of how these methods are used:
   *
   *   type := array|bool|func|object|number|string|oneOf([...])|instanceOf(...)
   *   decl := ReactPropTypes.{type}(.isRequired)?
   *
   * Each and every declaration produces a function with the same signature. This
   * allows the creation of custom validation functions. For example:
   *
   *  var MyLink = React.createClass({
   *    propTypes: {
   *      // An optional string or URI prop named "href".
   *      href: function(props, propName, componentName) {
   *        var propValue = props[propName];
   *        if (propValue != null && typeof propValue !== 'string' &&
   *            !(propValue instanceof URI)) {
   *          return new Error(
   *            'Expected a string or an URI for ' + propName + ' in ' +
   *            componentName
   *          );
   *        }
   *      }
   *    },
   *    render: function() {...}
   *  });
   *
   * @internal
   */

  var ANONYMOUS = '<<anonymous>>';

  // Important!
  // Keep this list in sync with production version in `./factoryWithThrowingShims.js`.
  var ReactPropTypes = {
    array: createPrimitiveTypeChecker('array'),
    bigint: createPrimitiveTypeChecker('bigint'),
    bool: createPrimitiveTypeChecker('boolean'),
    func: createPrimitiveTypeChecker('function'),
    number: createPrimitiveTypeChecker('number'),
    object: createPrimitiveTypeChecker('object'),
    string: createPrimitiveTypeChecker('string'),
    symbol: createPrimitiveTypeChecker('symbol'),

    any: createAnyTypeChecker(),
    arrayOf: createArrayOfTypeChecker,
    element: createElementTypeChecker(),
    elementType: createElementTypeTypeChecker(),
    instanceOf: createInstanceTypeChecker,
    node: createNodeChecker(),
    objectOf: createObjectOfTypeChecker,
    oneOf: createEnumTypeChecker,
    oneOfType: createUnionTypeChecker,
    shape: createShapeTypeChecker,
    exact: createStrictShapeTypeChecker,
  };

  /**
   * inlined Object.is polyfill to avoid requiring consumers ship their own
   * https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/is
   */
  /*eslint-disable no-self-compare*/
  function is(x, y) {
    // SameValue algorithm
    if (x === y) {
      // Steps 1-5, 7-10
      // Steps 6.b-6.e: +0 != -0
      return x !== 0 || 1 / x === 1 / y;
    } else {
      // Step 6.a: NaN == NaN
      return x !== x && y !== y;
    }
  }
  /*eslint-enable no-self-compare*/

  /**
   * We use an Error-like object for backward compatibility as people may call
   * PropTypes directly and inspect their output. However, we don't use real
   * Errors anymore. We don't inspect their stack anyway, and creating them
   * is prohibitively expensive if they are created too often, such as what
   * happens in oneOfType() for any type before the one that matched.
   */
  function PropTypeError(message, data) {
    this.message = message;
    this.data = data && typeof data === 'object' ? data: {};
    this.stack = '';
  }
  // Make `instanceof Error` still work for returned errors.
  PropTypeError.prototype = Error.prototype;

  function createChainableTypeChecker(validate) {
    if (true) {
      var manualPropTypeCallCache = {};
      var manualPropTypeWarningCount = 0;
    }
    function checkType(isRequired, props, propName, componentName, location, propFullName, secret) {
      componentName = componentName || ANONYMOUS;
      propFullName = propFullName || propName;

      if (secret !== ReactPropTypesSecret) {
        if (throwOnDirectAccess) {
          // New behavior only for users of `prop-types` package
          var err = new Error(
            'Calling PropTypes validators directly is not supported by the `prop-types` package. ' +
            'Use `PropTypes.checkPropTypes()` to call them. ' +
            'Read more at http://fb.me/use-check-prop-types'
          );
          err.name = 'Invariant Violation';
          throw err;
        } else if ( true && typeof console !== 'undefined') {
          // Old behavior for people using React.PropTypes
          var cacheKey = componentName + ':' + propName;
          if (
            !manualPropTypeCallCache[cacheKey] &&
            // Avoid spamming the console because they are often not actionable except for lib authors
            manualPropTypeWarningCount < 3
          ) {
            printWarning(
              'You are manually calling a React.PropTypes validation ' +
              'function for the `' + propFullName + '` prop on `' + componentName + '`. This is deprecated ' +
              'and will throw in the standalone `prop-types` package. ' +
              'You may be seeing this warning due to a third-party PropTypes ' +
              'library. See https://fb.me/react-warning-dont-call-proptypes ' + 'for details.'
            );
            manualPropTypeCallCache[cacheKey] = true;
            manualPropTypeWarningCount++;
          }
        }
      }
      if (props[propName] == null) {
        if (isRequired) {
          if (props[propName] === null) {
            return new PropTypeError('The ' + location + ' `' + propFullName + '` is marked as required ' + ('in `' + componentName + '`, but its value is `null`.'));
          }
          return new PropTypeError('The ' + location + ' `' + propFullName + '` is marked as required in ' + ('`' + componentName + '`, but its value is `undefined`.'));
        }
        return null;
      } else {
        return validate(props, propName, componentName, location, propFullName);
      }
    }

    var chainedCheckType = checkType.bind(null, false);
    chainedCheckType.isRequired = checkType.bind(null, true);

    return chainedCheckType;
  }

  function createPrimitiveTypeChecker(expectedType) {
    function validate(props, propName, componentName, location, propFullName, secret) {
      var propValue = props[propName];
      var propType = getPropType(propValue);
      if (propType !== expectedType) {
        // `propValue` being instance of, say, date/regexp, pass the 'object'
        // check, but we can offer a more precise error message here rather than
        // 'of type `object`'.
        var preciseType = getPreciseType(propValue);

        return new PropTypeError(
          'Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + preciseType + '` supplied to `' + componentName + '`, expected ') + ('`' + expectedType + '`.'),
          {expectedType: expectedType}
        );
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createAnyTypeChecker() {
    return createChainableTypeChecker(emptyFunctionThatReturnsNull);
  }

  function createArrayOfTypeChecker(typeChecker) {
    function validate(props, propName, componentName, location, propFullName) {
      if (typeof typeChecker !== 'function') {
        return new PropTypeError('Property `' + propFullName + '` of component `' + componentName + '` has invalid PropType notation inside arrayOf.');
      }
      var propValue = props[propName];
      if (!Array.isArray(propValue)) {
        var propType = getPropType(propValue);
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected an array.'));
      }
      for (var i = 0; i < propValue.length; i++) {
        var error = typeChecker(propValue, i, componentName, location, propFullName + '[' + i + ']', ReactPropTypesSecret);
        if (error instanceof Error) {
          return error;
        }
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createElementTypeChecker() {
    function validate(props, propName, componentName, location, propFullName) {
      var propValue = props[propName];
      if (!isValidElement(propValue)) {
        var propType = getPropType(propValue);
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected a single ReactElement.'));
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createElementTypeTypeChecker() {
    function validate(props, propName, componentName, location, propFullName) {
      var propValue = props[propName];
      if (!ReactIs.isValidElementType(propValue)) {
        var propType = getPropType(propValue);
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected a single ReactElement type.'));
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createInstanceTypeChecker(expectedClass) {
    function validate(props, propName, componentName, location, propFullName) {
      if (!(props[propName] instanceof expectedClass)) {
        var expectedClassName = expectedClass.name || ANONYMOUS;
        var actualClassName = getClassName(props[propName]);
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + actualClassName + '` supplied to `' + componentName + '`, expected ') + ('instance of `' + expectedClassName + '`.'));
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createEnumTypeChecker(expectedValues) {
    if (!Array.isArray(expectedValues)) {
      if (true) {
        if (arguments.length > 1) {
          printWarning(
            'Invalid arguments supplied to oneOf, expected an array, got ' + arguments.length + ' arguments. ' +
            'A common mistake is to write oneOf(x, y, z) instead of oneOf([x, y, z]).'
          );
        } else {
          printWarning('Invalid argument supplied to oneOf, expected an array.');
        }
      }
      return emptyFunctionThatReturnsNull;
    }

    function validate(props, propName, componentName, location, propFullName) {
      var propValue = props[propName];
      for (var i = 0; i < expectedValues.length; i++) {
        if (is(propValue, expectedValues[i])) {
          return null;
        }
      }

      var valuesString = JSON.stringify(expectedValues, function replacer(key, value) {
        var type = getPreciseType(value);
        if (type === 'symbol') {
          return String(value);
        }
        return value;
      });
      return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of value `' + String(propValue) + '` ' + ('supplied to `' + componentName + '`, expected one of ' + valuesString + '.'));
    }
    return createChainableTypeChecker(validate);
  }

  function createObjectOfTypeChecker(typeChecker) {
    function validate(props, propName, componentName, location, propFullName) {
      if (typeof typeChecker !== 'function') {
        return new PropTypeError('Property `' + propFullName + '` of component `' + componentName + '` has invalid PropType notation inside objectOf.');
      }
      var propValue = props[propName];
      var propType = getPropType(propValue);
      if (propType !== 'object') {
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected an object.'));
      }
      for (var key in propValue) {
        if (has(propValue, key)) {
          var error = typeChecker(propValue, key, componentName, location, propFullName + '.' + key, ReactPropTypesSecret);
          if (error instanceof Error) {
            return error;
          }
        }
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createUnionTypeChecker(arrayOfTypeCheckers) {
    if (!Array.isArray(arrayOfTypeCheckers)) {
       true ? printWarning('Invalid argument supplied to oneOfType, expected an instance of array.') : 0;
      return emptyFunctionThatReturnsNull;
    }

    for (var i = 0; i < arrayOfTypeCheckers.length; i++) {
      var checker = arrayOfTypeCheckers[i];
      if (typeof checker !== 'function') {
        printWarning(
          'Invalid argument supplied to oneOfType. Expected an array of check functions, but ' +
          'received ' + getPostfixForTypeWarning(checker) + ' at index ' + i + '.'
        );
        return emptyFunctionThatReturnsNull;
      }
    }

    function validate(props, propName, componentName, location, propFullName) {
      var expectedTypes = [];
      for (var i = 0; i < arrayOfTypeCheckers.length; i++) {
        var checker = arrayOfTypeCheckers[i];
        var checkerResult = checker(props, propName, componentName, location, propFullName, ReactPropTypesSecret);
        if (checkerResult == null) {
          return null;
        }
        if (checkerResult.data && has(checkerResult.data, 'expectedType')) {
          expectedTypes.push(checkerResult.data.expectedType);
        }
      }
      var expectedTypesMessage = (expectedTypes.length > 0) ? ', expected one of type [' + expectedTypes.join(', ') + ']': '';
      return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` supplied to ' + ('`' + componentName + '`' + expectedTypesMessage + '.'));
    }
    return createChainableTypeChecker(validate);
  }

  function createNodeChecker() {
    function validate(props, propName, componentName, location, propFullName) {
      if (!isNode(props[propName])) {
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` supplied to ' + ('`' + componentName + '`, expected a ReactNode.'));
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function invalidValidatorError(componentName, location, propFullName, key, type) {
    return new PropTypeError(
      (componentName || 'React class') + ': ' + location + ' type `' + propFullName + '.' + key + '` is invalid; ' +
      'it must be a function, usually from the `prop-types` package, but received `' + type + '`.'
    );
  }

  function createShapeTypeChecker(shapeTypes) {
    function validate(props, propName, componentName, location, propFullName) {
      var propValue = props[propName];
      var propType = getPropType(propValue);
      if (propType !== 'object') {
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type `' + propType + '` ' + ('supplied to `' + componentName + '`, expected `object`.'));
      }
      for (var key in shapeTypes) {
        var checker = shapeTypes[key];
        if (typeof checker !== 'function') {
          return invalidValidatorError(componentName, location, propFullName, key, getPreciseType(checker));
        }
        var error = checker(propValue, key, componentName, location, propFullName + '.' + key, ReactPropTypesSecret);
        if (error) {
          return error;
        }
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createStrictShapeTypeChecker(shapeTypes) {
    function validate(props, propName, componentName, location, propFullName) {
      var propValue = props[propName];
      var propType = getPropType(propValue);
      if (propType !== 'object') {
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type `' + propType + '` ' + ('supplied to `' + componentName + '`, expected `object`.'));
      }
      // We need to check all keys in case some are required but missing from props.
      var allKeys = assign({}, props[propName], shapeTypes);
      for (var key in allKeys) {
        var checker = shapeTypes[key];
        if (has(shapeTypes, key) && typeof checker !== 'function') {
          return invalidValidatorError(componentName, location, propFullName, key, getPreciseType(checker));
        }
        if (!checker) {
          return new PropTypeError(
            'Invalid ' + location + ' `' + propFullName + '` key `' + key + '` supplied to `' + componentName + '`.' +
            '\nBad object: ' + JSON.stringify(props[propName], null, '  ') +
            '\nValid keys: ' + JSON.stringify(Object.keys(shapeTypes), null, '  ')
          );
        }
        var error = checker(propValue, key, componentName, location, propFullName + '.' + key, ReactPropTypesSecret);
        if (error) {
          return error;
        }
      }
      return null;
    }

    return createChainableTypeChecker(validate);
  }

  function isNode(propValue) {
    switch (typeof propValue) {
      case 'number':
      case 'string':
      case 'undefined':
        return true;
      case 'boolean':
        return !propValue;
      case 'object':
        if (Array.isArray(propValue)) {
          return propValue.every(isNode);
        }
        if (propValue === null || isValidElement(propValue)) {
          return true;
        }

        var iteratorFn = getIteratorFn(propValue);
        if (iteratorFn) {
          var iterator = iteratorFn.call(propValue);
          var step;
          if (iteratorFn !== propValue.entries) {
            while (!(step = iterator.next()).done) {
              if (!isNode(step.value)) {
                return false;
              }
            }
          } else {
            // Iterator will provide entry [k,v] tuples rather than values.
            while (!(step = iterator.next()).done) {
              var entry = step.value;
              if (entry) {
                if (!isNode(entry[1])) {
                  return false;
                }
              }
            }
          }
        } else {
          return false;
        }

        return true;
      default:
        return false;
    }
  }

  function isSymbol(propType, propValue) {
    // Native Symbol.
    if (propType === 'symbol') {
      return true;
    }

    // falsy value can't be a Symbol
    if (!propValue) {
      return false;
    }

    // 19.4.3.5 Symbol.prototype[@@toStringTag] === 'Symbol'
    if (propValue['@@toStringTag'] === 'Symbol') {
      return true;
    }

    // Fallback for non-spec compliant Symbols which are polyfilled.
    if (typeof Symbol === 'function' && propValue instanceof Symbol) {
      return true;
    }

    return false;
  }

  // Equivalent of `typeof` but with special handling for array and regexp.
  function getPropType(propValue) {
    var propType = typeof propValue;
    if (Array.isArray(propValue)) {
      return 'array';
    }
    if (propValue instanceof RegExp) {
      // Old webkits (at least until Android 4.0) return 'function' rather than
      // 'object' for typeof a RegExp. We'll normalize this here so that /bla/
      // passes PropTypes.object.
      return 'object';
    }
    if (isSymbol(propType, propValue)) {
      return 'symbol';
    }
    return propType;
  }

  // This handles more types than `getPropType`. Only used for error messages.
  // See `createPrimitiveTypeChecker`.
  function getPreciseType(propValue) {
    if (typeof propValue === 'undefined' || propValue === null) {
      return '' + propValue;
    }
    var propType = getPropType(propValue);
    if (propType === 'object') {
      if (propValue instanceof Date) {
        return 'date';
      } else if (propValue instanceof RegExp) {
        return 'regexp';
      }
    }
    return propType;
  }

  // Returns a string that is postfixed to a warning about an invalid type.
  // For example, "undefined" or "of type array"
  function getPostfixForTypeWarning(value) {
    var type = getPreciseType(value);
    switch (type) {
      case 'array':
      case 'object':
        return 'an ' + type;
      case 'boolean':
      case 'date':
      case 'regexp':
        return 'a ' + type;
      default:
        return type;
    }
  }

  // Returns class name of the object, if any.
  function getClassName(propValue) {
    if (!propValue.constructor || !propValue.constructor.name) {
      return ANONYMOUS;
    }
    return propValue.constructor.name;
  }

  ReactPropTypes.checkPropTypes = checkPropTypes;
  ReactPropTypes.resetWarningCache = checkPropTypes.resetWarningCache;
  ReactPropTypes.PropTypes = ReactPropTypes;

  return ReactPropTypes;
};


/***/ }),

/***/ "../node_modules/prop-types/index.js":
/*!*******************************************!*\
  !*** ../node_modules/prop-types/index.js ***!
  \*******************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

if (true) {
  var ReactIs = __webpack_require__(/*! react-is */ "../node_modules/prop-types/node_modules/react-is/index.js");

  // By explicitly using `prop-types` you are opting into new development behavior.
  // http://fb.me/prop-types-in-prod
  var throwOnDirectAccess = true;
  module.exports = __webpack_require__(/*! ./factoryWithTypeCheckers */ "../node_modules/prop-types/factoryWithTypeCheckers.js")(ReactIs.isElement, throwOnDirectAccess);
} else {}


/***/ }),

/***/ "../node_modules/prop-types/lib/ReactPropTypesSecret.js":
/*!**************************************************************!*\
  !*** ../node_modules/prop-types/lib/ReactPropTypesSecret.js ***!
  \**************************************************************/
/***/ ((module) => {

"use strict";
/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



var ReactPropTypesSecret = 'SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED';

module.exports = ReactPropTypesSecret;


/***/ }),

/***/ "../node_modules/prop-types/lib/has.js":
/*!*********************************************!*\
  !*** ../node_modules/prop-types/lib/has.js ***!
  \*********************************************/
/***/ ((module) => {

module.exports = Function.call.bind(Object.prototype.hasOwnProperty);


/***/ }),

/***/ "../node_modules/prop-types/node_modules/react-is/cjs/react-is.development.js":
/*!************************************************************************************!*\
  !*** ../node_modules/prop-types/node_modules/react-is/cjs/react-is.development.js ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";
/** @license React v16.13.1
 * react-is.development.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */





if (true) {
  (function() {
'use strict';

// The Symbol used to tag the ReactElement-like types. If there is no native Symbol
// nor polyfill, then a plain number is used for performance.
var hasSymbol = typeof Symbol === 'function' && Symbol.for;
var REACT_ELEMENT_TYPE = hasSymbol ? Symbol.for('react.element') : 0xeac7;
var REACT_PORTAL_TYPE = hasSymbol ? Symbol.for('react.portal') : 0xeaca;
var REACT_FRAGMENT_TYPE = hasSymbol ? Symbol.for('react.fragment') : 0xeacb;
var REACT_STRICT_MODE_TYPE = hasSymbol ? Symbol.for('react.strict_mode') : 0xeacc;
var REACT_PROFILER_TYPE = hasSymbol ? Symbol.for('react.profiler') : 0xead2;
var REACT_PROVIDER_TYPE = hasSymbol ? Symbol.for('react.provider') : 0xeacd;
var REACT_CONTEXT_TYPE = hasSymbol ? Symbol.for('react.context') : 0xeace; // TODO: We don't use AsyncMode or ConcurrentMode anymore. They were temporary
// (unstable) APIs that have been removed. Can we remove the symbols?

var REACT_ASYNC_MODE_TYPE = hasSymbol ? Symbol.for('react.async_mode') : 0xeacf;
var REACT_CONCURRENT_MODE_TYPE = hasSymbol ? Symbol.for('react.concurrent_mode') : 0xeacf;
var REACT_FORWARD_REF_TYPE = hasSymbol ? Symbol.for('react.forward_ref') : 0xead0;
var REACT_SUSPENSE_TYPE = hasSymbol ? Symbol.for('react.suspense') : 0xead1;
var REACT_SUSPENSE_LIST_TYPE = hasSymbol ? Symbol.for('react.suspense_list') : 0xead8;
var REACT_MEMO_TYPE = hasSymbol ? Symbol.for('react.memo') : 0xead3;
var REACT_LAZY_TYPE = hasSymbol ? Symbol.for('react.lazy') : 0xead4;
var REACT_BLOCK_TYPE = hasSymbol ? Symbol.for('react.block') : 0xead9;
var REACT_FUNDAMENTAL_TYPE = hasSymbol ? Symbol.for('react.fundamental') : 0xead5;
var REACT_RESPONDER_TYPE = hasSymbol ? Symbol.for('react.responder') : 0xead6;
var REACT_SCOPE_TYPE = hasSymbol ? Symbol.for('react.scope') : 0xead7;

function isValidElementType(type) {
  return typeof type === 'string' || typeof type === 'function' || // Note: its typeof might be other than 'symbol' or 'number' if it's a polyfill.
  type === REACT_FRAGMENT_TYPE || type === REACT_CONCURRENT_MODE_TYPE || type === REACT_PROFILER_TYPE || type === REACT_STRICT_MODE_TYPE || type === REACT_SUSPENSE_TYPE || type === REACT_SUSPENSE_LIST_TYPE || typeof type === 'object' && type !== null && (type.$$typeof === REACT_LAZY_TYPE || type.$$typeof === REACT_MEMO_TYPE || type.$$typeof === REACT_PROVIDER_TYPE || type.$$typeof === REACT_CONTEXT_TYPE || type.$$typeof === REACT_FORWARD_REF_TYPE || type.$$typeof === REACT_FUNDAMENTAL_TYPE || type.$$typeof === REACT_RESPONDER_TYPE || type.$$typeof === REACT_SCOPE_TYPE || type.$$typeof === REACT_BLOCK_TYPE);
}

function typeOf(object) {
  if (typeof object === 'object' && object !== null) {
    var $$typeof = object.$$typeof;

    switch ($$typeof) {
      case REACT_ELEMENT_TYPE:
        var type = object.type;

        switch (type) {
          case REACT_ASYNC_MODE_TYPE:
          case REACT_CONCURRENT_MODE_TYPE:
          case REACT_FRAGMENT_TYPE:
          case REACT_PROFILER_TYPE:
          case REACT_STRICT_MODE_TYPE:
          case REACT_SUSPENSE_TYPE:
            return type;

          default:
            var $$typeofType = type && type.$$typeof;

            switch ($$typeofType) {
              case REACT_CONTEXT_TYPE:
              case REACT_FORWARD_REF_TYPE:
              case REACT_LAZY_TYPE:
              case REACT_MEMO_TYPE:
              case REACT_PROVIDER_TYPE:
                return $$typeofType;

              default:
                return $$typeof;
            }

        }

      case REACT_PORTAL_TYPE:
        return $$typeof;
    }
  }

  return undefined;
} // AsyncMode is deprecated along with isAsyncMode

var AsyncMode = REACT_ASYNC_MODE_TYPE;
var ConcurrentMode = REACT_CONCURRENT_MODE_TYPE;
var ContextConsumer = REACT_CONTEXT_TYPE;
var ContextProvider = REACT_PROVIDER_TYPE;
var Element = REACT_ELEMENT_TYPE;
var ForwardRef = REACT_FORWARD_REF_TYPE;
var Fragment = REACT_FRAGMENT_TYPE;
var Lazy = REACT_LAZY_TYPE;
var Memo = REACT_MEMO_TYPE;
var Portal = REACT_PORTAL_TYPE;
var Profiler = REACT_PROFILER_TYPE;
var StrictMode = REACT_STRICT_MODE_TYPE;
var Suspense = REACT_SUSPENSE_TYPE;
var hasWarnedAboutDeprecatedIsAsyncMode = false; // AsyncMode should be deprecated

function isAsyncMode(object) {
  {
    if (!hasWarnedAboutDeprecatedIsAsyncMode) {
      hasWarnedAboutDeprecatedIsAsyncMode = true; // Using console['warn'] to evade Babel and ESLint

      console['warn']('The ReactIs.isAsyncMode() alias has been deprecated, ' + 'and will be removed in React 17+. Update your code to use ' + 'ReactIs.isConcurrentMode() instead. It has the exact same API.');
    }
  }

  return isConcurrentMode(object) || typeOf(object) === REACT_ASYNC_MODE_TYPE;
}
function isConcurrentMode(object) {
  return typeOf(object) === REACT_CONCURRENT_MODE_TYPE;
}
function isContextConsumer(object) {
  return typeOf(object) === REACT_CONTEXT_TYPE;
}
function isContextProvider(object) {
  return typeOf(object) === REACT_PROVIDER_TYPE;
}
function isElement(object) {
  return typeof object === 'object' && object !== null && object.$$typeof === REACT_ELEMENT_TYPE;
}
function isForwardRef(object) {
  return typeOf(object) === REACT_FORWARD_REF_TYPE;
}
function isFragment(object) {
  return typeOf(object) === REACT_FRAGMENT_TYPE;
}
function isLazy(object) {
  return typeOf(object) === REACT_LAZY_TYPE;
}
function isMemo(object) {
  return typeOf(object) === REACT_MEMO_TYPE;
}
function isPortal(object) {
  return typeOf(object) === REACT_PORTAL_TYPE;
}
function isProfiler(object) {
  return typeOf(object) === REACT_PROFILER_TYPE;
}
function isStrictMode(object) {
  return typeOf(object) === REACT_STRICT_MODE_TYPE;
}
function isSuspense(object) {
  return typeOf(object) === REACT_SUSPENSE_TYPE;
}

exports.AsyncMode = AsyncMode;
exports.ConcurrentMode = ConcurrentMode;
exports.ContextConsumer = ContextConsumer;
exports.ContextProvider = ContextProvider;
exports.Element = Element;
exports.ForwardRef = ForwardRef;
exports.Fragment = Fragment;
exports.Lazy = Lazy;
exports.Memo = Memo;
exports.Portal = Portal;
exports.Profiler = Profiler;
exports.StrictMode = StrictMode;
exports.Suspense = Suspense;
exports.isAsyncMode = isAsyncMode;
exports.isConcurrentMode = isConcurrentMode;
exports.isContextConsumer = isContextConsumer;
exports.isContextProvider = isContextProvider;
exports.isElement = isElement;
exports.isForwardRef = isForwardRef;
exports.isFragment = isFragment;
exports.isLazy = isLazy;
exports.isMemo = isMemo;
exports.isPortal = isPortal;
exports.isProfiler = isProfiler;
exports.isStrictMode = isStrictMode;
exports.isSuspense = isSuspense;
exports.isValidElementType = isValidElementType;
exports.typeOf = typeOf;
  })();
}


/***/ }),

/***/ "../node_modules/prop-types/node_modules/react-is/index.js":
/*!*****************************************************************!*\
  !*** ../node_modules/prop-types/node_modules/react-is/index.js ***!
  \*****************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


if (false) {} else {
  module.exports = __webpack_require__(/*! ./cjs/react-is.development.js */ "../node_modules/prop-types/node_modules/react-is/cjs/react-is.development.js");
}


/***/ }),

/***/ "../node_modules/reach-router-hash-history/index.js":
/*!**********************************************************!*\
  !*** ../node_modules/reach-router-hash-history/index.js ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   createHashSource: () => (/* binding */ createHashSource)
/* harmony export */ });
// take some code from
// https://github.com/ReactTraining/history/blob/master/modules/createHashHistory.js

function getHashPath() {
  // We can't use window.location.hash here because it's not
  // consistent across browsers - Firefox will pre-decode it!
  const href = window.location.href;
  const hashIndex = href.indexOf('#');
  return hashIndex === -1 ? '' : href.substring(hashIndex + 1);
}

function pushHashPath(path) {
  window.location.hash = '#' + path;
}

function replaceHashPath(path) {
  const hashIndex = window.location.href.indexOf('#');
  window.location.replace(
    window.location.href.slice(0, hashIndex >= 0 ? hashIndex : 0) + '#' + path
  );
}

let createHashSource = (initialPathname = '/') => {
  let index = 0;
  // let stack = [{ pathname: initialPathname, search: '' }];
  // let states = [];

  return {
    get location() {
      return { pathname: getHashPath(), search: '' };
      // return stack[index];
    },
    addEventListener(name, fn) {
      if (name === 'popstate') {
        window.addEventListener('hashchange', fn);
      }
    },
    removeEventListener(name, fn) {
      if (name === 'popstate') {
        window.addEventListener('hashchange', fn);
      }
    },
    history: {
      get entries() {
        return [{ pathname: getHashPath(), search: '' }];
        // return stack;
      },
      get index() {
        return index;
      },
      get state() {
        return undefined;
        // return states[index];
      },
      pushState(state, _, uri) {
        pushHashPath(uri);
        // let [pathname, search = ''] = uri.split('?');
        // index++;
        // stack.push({ pathname, search });
        // states.push(state);
      },
      replaceState(state, _, uri) {
        replaceHashPath(uri);
        // let [pathname, search = ''] = uri.split('?');
        // stack[index] = { pathname, search };
        // states[index] = state;
      }
    }
  };
};




/***/ }),

/***/ "../node_modules/react-is/cjs/react-is.development.js":
/*!************************************************************!*\
  !*** ../node_modules/react-is/cjs/react-is.development.js ***!
  \************************************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";
/**
 * @license React
 * react-is.development.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



if (true) {
  (function() {
'use strict';

// ATTENTION
// When adding new symbols to this file,
// Please consider also adding to 'react-devtools-shared/src/backend/ReactSymbols'
// The Symbol used to tag the ReactElement-like types.
var REACT_ELEMENT_TYPE = Symbol.for('react.element');
var REACT_PORTAL_TYPE = Symbol.for('react.portal');
var REACT_FRAGMENT_TYPE = Symbol.for('react.fragment');
var REACT_STRICT_MODE_TYPE = Symbol.for('react.strict_mode');
var REACT_PROFILER_TYPE = Symbol.for('react.profiler');
var REACT_PROVIDER_TYPE = Symbol.for('react.provider');
var REACT_CONTEXT_TYPE = Symbol.for('react.context');
var REACT_SERVER_CONTEXT_TYPE = Symbol.for('react.server_context');
var REACT_FORWARD_REF_TYPE = Symbol.for('react.forward_ref');
var REACT_SUSPENSE_TYPE = Symbol.for('react.suspense');
var REACT_SUSPENSE_LIST_TYPE = Symbol.for('react.suspense_list');
var REACT_MEMO_TYPE = Symbol.for('react.memo');
var REACT_LAZY_TYPE = Symbol.for('react.lazy');
var REACT_OFFSCREEN_TYPE = Symbol.for('react.offscreen');

// -----------------------------------------------------------------------------

var enableScopeAPI = false; // Experimental Create Event Handle API.
var enableCacheElement = false;
var enableTransitionTracing = false; // No known bugs, but needs performance testing

var enableLegacyHidden = false; // Enables unstable_avoidThisFallback feature in Fiber
// stuff. Intended to enable React core members to more easily debug scheduling
// issues in DEV builds.

var enableDebugTracing = false; // Track which Fiber(s) schedule render work.

var REACT_MODULE_REFERENCE;

{
  REACT_MODULE_REFERENCE = Symbol.for('react.module.reference');
}

function isValidElementType(type) {
  if (typeof type === 'string' || typeof type === 'function') {
    return true;
  } // Note: typeof might be other than 'symbol' or 'number' (e.g. if it's a polyfill).


  if (type === REACT_FRAGMENT_TYPE || type === REACT_PROFILER_TYPE || enableDebugTracing  || type === REACT_STRICT_MODE_TYPE || type === REACT_SUSPENSE_TYPE || type === REACT_SUSPENSE_LIST_TYPE || enableLegacyHidden  || type === REACT_OFFSCREEN_TYPE || enableScopeAPI  || enableCacheElement  || enableTransitionTracing ) {
    return true;
  }

  if (typeof type === 'object' && type !== null) {
    if (type.$$typeof === REACT_LAZY_TYPE || type.$$typeof === REACT_MEMO_TYPE || type.$$typeof === REACT_PROVIDER_TYPE || type.$$typeof === REACT_CONTEXT_TYPE || type.$$typeof === REACT_FORWARD_REF_TYPE || // This needs to include all possible module reference object
    // types supported by any Flight configuration anywhere since
    // we don't know which Flight build this will end up being used
    // with.
    type.$$typeof === REACT_MODULE_REFERENCE || type.getModuleId !== undefined) {
      return true;
    }
  }

  return false;
}

function typeOf(object) {
  if (typeof object === 'object' && object !== null) {
    var $$typeof = object.$$typeof;

    switch ($$typeof) {
      case REACT_ELEMENT_TYPE:
        var type = object.type;

        switch (type) {
          case REACT_FRAGMENT_TYPE:
          case REACT_PROFILER_TYPE:
          case REACT_STRICT_MODE_TYPE:
          case REACT_SUSPENSE_TYPE:
          case REACT_SUSPENSE_LIST_TYPE:
            return type;

          default:
            var $$typeofType = type && type.$$typeof;

            switch ($$typeofType) {
              case REACT_SERVER_CONTEXT_TYPE:
              case REACT_CONTEXT_TYPE:
              case REACT_FORWARD_REF_TYPE:
              case REACT_LAZY_TYPE:
              case REACT_MEMO_TYPE:
              case REACT_PROVIDER_TYPE:
                return $$typeofType;

              default:
                return $$typeof;
            }

        }

      case REACT_PORTAL_TYPE:
        return $$typeof;
    }
  }

  return undefined;
}
var ContextConsumer = REACT_CONTEXT_TYPE;
var ContextProvider = REACT_PROVIDER_TYPE;
var Element = REACT_ELEMENT_TYPE;
var ForwardRef = REACT_FORWARD_REF_TYPE;
var Fragment = REACT_FRAGMENT_TYPE;
var Lazy = REACT_LAZY_TYPE;
var Memo = REACT_MEMO_TYPE;
var Portal = REACT_PORTAL_TYPE;
var Profiler = REACT_PROFILER_TYPE;
var StrictMode = REACT_STRICT_MODE_TYPE;
var Suspense = REACT_SUSPENSE_TYPE;
var SuspenseList = REACT_SUSPENSE_LIST_TYPE;
var hasWarnedAboutDeprecatedIsAsyncMode = false;
var hasWarnedAboutDeprecatedIsConcurrentMode = false; // AsyncMode should be deprecated

function isAsyncMode(object) {
  {
    if (!hasWarnedAboutDeprecatedIsAsyncMode) {
      hasWarnedAboutDeprecatedIsAsyncMode = true; // Using console['warn'] to evade Babel and ESLint

      console['warn']('The ReactIs.isAsyncMode() alias has been deprecated, ' + 'and will be removed in React 18+.');
    }
  }

  return false;
}
function isConcurrentMode(object) {
  {
    if (!hasWarnedAboutDeprecatedIsConcurrentMode) {
      hasWarnedAboutDeprecatedIsConcurrentMode = true; // Using console['warn'] to evade Babel and ESLint

      console['warn']('The ReactIs.isConcurrentMode() alias has been deprecated, ' + 'and will be removed in React 18+.');
    }
  }

  return false;
}
function isContextConsumer(object) {
  return typeOf(object) === REACT_CONTEXT_TYPE;
}
function isContextProvider(object) {
  return typeOf(object) === REACT_PROVIDER_TYPE;
}
function isElement(object) {
  return typeof object === 'object' && object !== null && object.$$typeof === REACT_ELEMENT_TYPE;
}
function isForwardRef(object) {
  return typeOf(object) === REACT_FORWARD_REF_TYPE;
}
function isFragment(object) {
  return typeOf(object) === REACT_FRAGMENT_TYPE;
}
function isLazy(object) {
  return typeOf(object) === REACT_LAZY_TYPE;
}
function isMemo(object) {
  return typeOf(object) === REACT_MEMO_TYPE;
}
function isPortal(object) {
  return typeOf(object) === REACT_PORTAL_TYPE;
}
function isProfiler(object) {
  return typeOf(object) === REACT_PROFILER_TYPE;
}
function isStrictMode(object) {
  return typeOf(object) === REACT_STRICT_MODE_TYPE;
}
function isSuspense(object) {
  return typeOf(object) === REACT_SUSPENSE_TYPE;
}
function isSuspenseList(object) {
  return typeOf(object) === REACT_SUSPENSE_LIST_TYPE;
}

exports.ContextConsumer = ContextConsumer;
exports.ContextProvider = ContextProvider;
exports.Element = Element;
exports.ForwardRef = ForwardRef;
exports.Fragment = Fragment;
exports.Lazy = Lazy;
exports.Memo = Memo;
exports.Portal = Portal;
exports.Profiler = Profiler;
exports.StrictMode = StrictMode;
exports.Suspense = Suspense;
exports.SuspenseList = SuspenseList;
exports.isAsyncMode = isAsyncMode;
exports.isConcurrentMode = isConcurrentMode;
exports.isContextConsumer = isContextConsumer;
exports.isContextProvider = isContextProvider;
exports.isElement = isElement;
exports.isForwardRef = isForwardRef;
exports.isFragment = isFragment;
exports.isLazy = isLazy;
exports.isMemo = isMemo;
exports.isPortal = isPortal;
exports.isProfiler = isProfiler;
exports.isStrictMode = isStrictMode;
exports.isSuspense = isSuspense;
exports.isSuspenseList = isSuspenseList;
exports.isValidElementType = isValidElementType;
exports.typeOf = typeOf;
  })();
}


/***/ }),

/***/ "../node_modules/react-is/index.js":
/*!*****************************************!*\
  !*** ../node_modules/react-is/index.js ***!
  \*****************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


if (false) {} else {
  module.exports = __webpack_require__(/*! ./cjs/react-is.development.js */ "../node_modules/react-is/cjs/react-is.development.js");
}


/***/ }),

/***/ "../node_modules/react-lifecycles-compat/react-lifecycles-compat.es.js":
/*!*****************************************************************************!*\
  !*** ../node_modules/react-lifecycles-compat/react-lifecycles-compat.es.js ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   polyfill: () => (/* binding */ polyfill)
/* harmony export */ });
/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

function componentWillMount() {
  // Call this.constructor.gDSFP to support sub-classes.
  var state = this.constructor.getDerivedStateFromProps(this.props, this.state);
  if (state !== null && state !== undefined) {
    this.setState(state);
  }
}

function componentWillReceiveProps(nextProps) {
  // Call this.constructor.gDSFP to support sub-classes.
  // Use the setState() updater to ensure state isn't stale in certain edge cases.
  function updater(prevState) {
    var state = this.constructor.getDerivedStateFromProps(nextProps, prevState);
    return state !== null && state !== undefined ? state : null;
  }
  // Binding "this" is important for shallow renderer support.
  this.setState(updater.bind(this));
}

function componentWillUpdate(nextProps, nextState) {
  try {
    var prevProps = this.props;
    var prevState = this.state;
    this.props = nextProps;
    this.state = nextState;
    this.__reactInternalSnapshotFlag = true;
    this.__reactInternalSnapshot = this.getSnapshotBeforeUpdate(
      prevProps,
      prevState
    );
  } finally {
    this.props = prevProps;
    this.state = prevState;
  }
}

// React may warn about cWM/cWRP/cWU methods being deprecated.
// Add a flag to suppress these warnings for this special case.
componentWillMount.__suppressDeprecationWarning = true;
componentWillReceiveProps.__suppressDeprecationWarning = true;
componentWillUpdate.__suppressDeprecationWarning = true;

function polyfill(Component) {
  var prototype = Component.prototype;

  if (!prototype || !prototype.isReactComponent) {
    throw new Error('Can only polyfill class components');
  }

  if (
    typeof Component.getDerivedStateFromProps !== 'function' &&
    typeof prototype.getSnapshotBeforeUpdate !== 'function'
  ) {
    return Component;
  }

  // If new component APIs are defined, "unsafe" lifecycles won't be called.
  // Error if any of these lifecycles are present,
  // Because they would work differently between older and newer (16.3+) versions of React.
  var foundWillMountName = null;
  var foundWillReceivePropsName = null;
  var foundWillUpdateName = null;
  if (typeof prototype.componentWillMount === 'function') {
    foundWillMountName = 'componentWillMount';
  } else if (typeof prototype.UNSAFE_componentWillMount === 'function') {
    foundWillMountName = 'UNSAFE_componentWillMount';
  }
  if (typeof prototype.componentWillReceiveProps === 'function') {
    foundWillReceivePropsName = 'componentWillReceiveProps';
  } else if (typeof prototype.UNSAFE_componentWillReceiveProps === 'function') {
    foundWillReceivePropsName = 'UNSAFE_componentWillReceiveProps';
  }
  if (typeof prototype.componentWillUpdate === 'function') {
    foundWillUpdateName = 'componentWillUpdate';
  } else if (typeof prototype.UNSAFE_componentWillUpdate === 'function') {
    foundWillUpdateName = 'UNSAFE_componentWillUpdate';
  }
  if (
    foundWillMountName !== null ||
    foundWillReceivePropsName !== null ||
    foundWillUpdateName !== null
  ) {
    var componentName = Component.displayName || Component.name;
    var newApiName =
      typeof Component.getDerivedStateFromProps === 'function'
        ? 'getDerivedStateFromProps()'
        : 'getSnapshotBeforeUpdate()';

    throw Error(
      'Unsafe legacy lifecycles will not be called for components using new component APIs.\n\n' +
        componentName +
        ' uses ' +
        newApiName +
        ' but also contains the following legacy lifecycles:' +
        (foundWillMountName !== null ? '\n  ' + foundWillMountName : '') +
        (foundWillReceivePropsName !== null
          ? '\n  ' + foundWillReceivePropsName
          : '') +
        (foundWillUpdateName !== null ? '\n  ' + foundWillUpdateName : '') +
        '\n\nThe above lifecycles should be removed. Learn more about this warning here:\n' +
        'https://fb.me/react-async-component-lifecycle-hooks'
    );
  }

  // React <= 16.2 does not support static getDerivedStateFromProps.
  // As a workaround, use cWM and cWRP to invoke the new static lifecycle.
  // Newer versions of React will ignore these lifecycles if gDSFP exists.
  if (typeof Component.getDerivedStateFromProps === 'function') {
    prototype.componentWillMount = componentWillMount;
    prototype.componentWillReceiveProps = componentWillReceiveProps;
  }

  // React <= 16.2 does not support getSnapshotBeforeUpdate.
  // As a workaround, use cWU to invoke the new lifecycle.
  // Newer versions of React will ignore that lifecycle if gSBU exists.
  if (typeof prototype.getSnapshotBeforeUpdate === 'function') {
    if (typeof prototype.componentDidUpdate !== 'function') {
      throw new Error(
        'Cannot polyfill getSnapshotBeforeUpdate() for components that do not define componentDidUpdate() on the prototype'
      );
    }

    prototype.componentWillUpdate = componentWillUpdate;

    var componentDidUpdate = prototype.componentDidUpdate;

    prototype.componentDidUpdate = function componentDidUpdatePolyfill(
      prevProps,
      prevState,
      maybeSnapshot
    ) {
      // 16.3+ will not execute our will-update method;
      // It will pass a snapshot value to did-update though.
      // Older versions will require our polyfilled will-update value.
      // We need to handle both cases, but can't just check for the presence of "maybeSnapshot",
      // Because for <= 15.x versions this might be a "prevContext" object.
      // We also can't just check "__reactInternalSnapshot",
      // Because get-snapshot might return a falsy value.
      // So check for the explicit __reactInternalSnapshotFlag flag to determine behavior.
      var snapshot = this.__reactInternalSnapshotFlag
        ? this.__reactInternalSnapshot
        : maybeSnapshot;

      componentDidUpdate.call(this, prevProps, prevState, snapshot);
    };
  }

  return Component;
}




/***/ }),

/***/ "../node_modules/shallowequal/index.js":
/*!*********************************************!*\
  !*** ../node_modules/shallowequal/index.js ***!
  \*********************************************/
/***/ ((module) => {

//

module.exports = function shallowEqual(objA, objB, compare, compareContext) {
  var ret = compare ? compare.call(compareContext, objA, objB) : void 0;

  if (ret !== void 0) {
    return !!ret;
  }

  if (objA === objB) {
    return true;
  }

  if (typeof objA !== "object" || !objA || typeof objB !== "object" || !objB) {
    return false;
  }

  var keysA = Object.keys(objA);
  var keysB = Object.keys(objB);

  if (keysA.length !== keysB.length) {
    return false;
  }

  var bHasOwnProperty = Object.prototype.hasOwnProperty.bind(objB);

  // Test for A's keys different from B.
  for (var idx = 0; idx < keysA.length; idx++) {
    var key = keysA[idx];

    if (!bHasOwnProperty(key)) {
      return false;
    }

    var valueA = objA[key];
    var valueB = objB[key];

    ret = compare ? compare.call(compareContext, valueA, valueB, key) : void 0;

    if (ret === false || (ret === void 0 && valueA !== valueB)) {
      return false;
    }
  }

  return true;
};


/***/ }),

/***/ "../node_modules/styled-components/dist/styled-components.browser.esm.js":
/*!*******************************************************************************!*\
  !*** ../node_modules/styled-components/dist/styled-components.browser.esm.js ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ServerStyleSheet: () => (/* binding */ Ue),
/* harmony export */   StyleSheetConsumer: () => (/* binding */ ue),
/* harmony export */   StyleSheetContext: () => (/* binding */ ce),
/* harmony export */   StyleSheetManager: () => (/* binding */ me),
/* harmony export */   ThemeConsumer: () => (/* binding */ Ge),
/* harmony export */   ThemeContext: () => (/* binding */ Me),
/* harmony export */   ThemeProvider: () => (/* binding */ Le),
/* harmony export */   __PRIVATE__: () => (/* binding */ Ze),
/* harmony export */   createGlobalStyle: () => (/* binding */ $e),
/* harmony export */   css: () => (/* binding */ Ae),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   isStyledComponent: () => (/* binding */ _),
/* harmony export */   keyframes: () => (/* binding */ We),
/* harmony export */   useTheme: () => (/* binding */ Xe),
/* harmony export */   version: () => (/* binding */ A),
/* harmony export */   withTheme: () => (/* binding */ Je)
/* harmony export */ });
/* harmony import */ var react_is__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react-is */ "../node_modules/react-is/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var shallowequal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! shallowequal */ "../node_modules/shallowequal/index.js");
/* harmony import */ var shallowequal__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(shallowequal__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _emotion_stylis__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @emotion/stylis */ "../node_modules/@emotion/stylis/dist/stylis.browser.esm.js");
/* harmony import */ var _emotion_unitless__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @emotion/unitless */ "../node_modules/styled-components/node_modules/@emotion/unitless/dist/unitless.browser.esm.js");
/* harmony import */ var _emotion_is_prop_valid__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @emotion/is-prop-valid */ "../node_modules/@emotion/is-prop-valid/dist/emotion-is-prop-valid.esm.js");
/* harmony import */ var hoist_non_react_statics__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! hoist-non-react-statics */ "../node_modules/hoist-non-react-statics/dist/hoist-non-react-statics.cjs.js");
/* harmony import */ var hoist_non_react_statics__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(hoist_non_react_statics__WEBPACK_IMPORTED_MODULE_6__);
function y(){return(y=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e}).apply(this,arguments)}var v=function(e,t){for(var n=[e[0]],r=0,o=t.length;r<o;r+=1)n.push(t[r],e[r+1]);return n},g=function(t){return null!==t&&"object"==typeof t&&"[object Object]"===(t.toString?t.toString():Object.prototype.toString.call(t))&&!(0,react_is__WEBPACK_IMPORTED_MODULE_0__.typeOf)(t)},S=Object.freeze([]),w=Object.freeze({});function E(e){return"function"==typeof e}function b(e){return true&&"string"==typeof e&&e||e.displayName||e.name||"Component"}function _(e){return e&&"string"==typeof e.styledComponentId}var N="undefined"!=typeof process&&void 0!==process.env&&(process.env.REACT_APP_SC_ATTR||process.env.SC_ATTR)||"data-styled",A="5.3.11",C="undefined"!=typeof window&&"HTMLElement"in window,I=Boolean("boolean"==typeof SC_DISABLE_SPEEDY?SC_DISABLE_SPEEDY:"undefined"!=typeof process&&void 0!==process.env&&(void 0!==process.env.REACT_APP_SC_DISABLE_SPEEDY&&""!==process.env.REACT_APP_SC_DISABLE_SPEEDY?"false"!==process.env.REACT_APP_SC_DISABLE_SPEEDY&&process.env.REACT_APP_SC_DISABLE_SPEEDY:void 0!==process.env.SC_DISABLE_SPEEDY&&""!==process.env.SC_DISABLE_SPEEDY?"false"!==process.env.SC_DISABLE_SPEEDY&&process.env.SC_DISABLE_SPEEDY:"production"!=="development")),P={},O= true?{1:"Cannot create styled-component for component: %s.\n\n",2:"Can't collect styles once you've consumed a `ServerStyleSheet`'s styles! `ServerStyleSheet` is a one off instance for each server-side render cycle.\n\n- Are you trying to reuse it across renders?\n- Are you accidentally calling collectStyles twice?\n\n",3:"Streaming SSR is only supported in a Node.js environment; Please do not try to call this method in the browser.\n\n",4:"The `StyleSheetManager` expects a valid target or sheet prop!\n\n- Does this error occur on the client and is your target falsy?\n- Does this error occur on the server and is the sheet falsy?\n\n",5:"The clone method cannot be used on the client!\n\n- Are you running in a client-like environment on the server?\n- Are you trying to run SSR on the client?\n\n",6:"Trying to insert a new style tag, but the given Node is unmounted!\n\n- Are you using a custom target that isn't mounted?\n- Does your document not have a valid head element?\n- Have you accidentally removed a style tag manually?\n\n",7:'ThemeProvider: Please return an object from your "theme" prop function, e.g.\n\n```js\ntheme={() => ({})}\n```\n\n',8:'ThemeProvider: Please make your "theme" prop an object.\n\n',9:"Missing document `<head>`\n\n",10:"Cannot find a StyleSheet instance. Usually this happens if there are multiple copies of styled-components loaded at once. Check out this issue for how to troubleshoot and fix the common cases where this situation can happen: https://github.com/styled-components/styled-components/issues/1941#issuecomment-417862021\n\n",11:"_This error was replaced with a dev-time warning, it will be deleted for v4 final._ [createGlobalStyle] received children which will not be rendered. Please use the component without passing children elements.\n\n",12:"It seems you are interpolating a keyframe declaration (%s) into an untagged string. This was supported in styled-components v3, but is not longer supported in v4 as keyframes are now injected on-demand. Please wrap your string in the css\\`\\` helper which ensures the styles are injected correctly. See https://www.styled-components.com/docs/api#css\n\n",13:"%s is not a styled component and cannot be referred to via component selector. See https://www.styled-components.com/docs/advanced#referring-to-other-components for more details.\n\n",14:'ThemeProvider: "theme" prop is required.\n\n',15:"A stylis plugin has been supplied that is not named. We need a name for each plugin to be able to prevent styling collisions between different stylis configurations within the same app. Before you pass your plugin to `<StyleSheetManager stylisPlugins={[]}>`, please make sure each plugin is uniquely-named, e.g.\n\n```js\nObject.defineProperty(importedPlugin, 'name', { value: 'some-unique-name' });\n```\n\n",16:"Reached the limit of how many styled components may be created at group %s.\nYou may only create up to 1,073,741,824 components. If you're creating components dynamically,\nas for instance in your render method then you may be running into this limitation.\n\n",17:"CSSStyleSheet could not be found on HTMLStyleElement.\nHas styled-components' style tag been unmounted or altered by another script?\n"}:0;function R(){for(var e=arguments.length<=0?void 0:arguments[0],t=[],n=1,r=arguments.length;n<r;n+=1)t.push(n<0||arguments.length<=n?void 0:arguments[n]);return t.forEach((function(t){e=e.replace(/%[a-z]/,t)})),e}function D(e){for(var t=arguments.length,n=new Array(t>1?t-1:0),r=1;r<t;r++)n[r-1]=arguments[r];throw false?0:new Error(R.apply(void 0,[O[e]].concat(n)).trim())}var j=function(){function e(e){this.groupSizes=new Uint32Array(512),this.length=512,this.tag=e}var t=e.prototype;return t.indexOfGroup=function(e){for(var t=0,n=0;n<e;n++)t+=this.groupSizes[n];return t},t.insertRules=function(e,t){if(e>=this.groupSizes.length){for(var n=this.groupSizes,r=n.length,o=r;e>=o;)(o<<=1)<0&&D(16,""+e);this.groupSizes=new Uint32Array(o),this.groupSizes.set(n),this.length=o;for(var s=r;s<o;s++)this.groupSizes[s]=0}for(var i=this.indexOfGroup(e+1),a=0,c=t.length;a<c;a++)this.tag.insertRule(i,t[a])&&(this.groupSizes[e]++,i++)},t.clearGroup=function(e){if(e<this.length){var t=this.groupSizes[e],n=this.indexOfGroup(e),r=n+t;this.groupSizes[e]=0;for(var o=n;o<r;o++)this.tag.deleteRule(n)}},t.getGroup=function(e){var t="";if(e>=this.length||0===this.groupSizes[e])return t;for(var n=this.groupSizes[e],r=this.indexOfGroup(e),o=r+n,s=r;s<o;s++)t+=this.tag.getRule(s)+"/*!sc*/\n";return t},e}(),T=new Map,x=new Map,k=1,V=function(e){if(T.has(e))return T.get(e);for(;x.has(k);)k++;var t=k++;return true&&((0|t)<0||t>1<<30)&&D(16,""+t),T.set(e,t),x.set(t,e),t},B=function(e){return x.get(e)},z=function(e,t){t>=k&&(k=t+1),T.set(e,t),x.set(t,e)},M="style["+N+'][data-styled-version="5.3.11"]',G=new RegExp("^"+N+'\\.g(\\d+)\\[id="([\\w\\d-]+)"\\].*?"([^"]*)'),L=function(e,t,n){for(var r,o=n.split(","),s=0,i=o.length;s<i;s++)(r=o[s])&&e.registerName(t,r)},F=function(e,t){for(var n=(t.textContent||"").split("/*!sc*/\n"),r=[],o=0,s=n.length;o<s;o++){var i=n[o].trim();if(i){var a=i.match(G);if(a){var c=0|parseInt(a[1],10),u=a[2];0!==c&&(z(u,c),L(e,u,a[3]),e.getTag().insertRules(c,r)),r.length=0}else r.push(i)}}},Y=function(){return true?__webpack_require__.nc:0},q=function(e){var t=document.head,n=e||t,r=document.createElement("style"),o=function(e){for(var t=e.childNodes,n=t.length;n>=0;n--){var r=t[n];if(r&&1===r.nodeType&&r.hasAttribute(N))return r}}(n),s=void 0!==o?o.nextSibling:null;r.setAttribute(N,"active"),r.setAttribute("data-styled-version","5.3.11");var i=Y();return i&&r.setAttribute("nonce",i),n.insertBefore(r,s),r},H=function(){function e(e){var t=this.element=q(e);t.appendChild(document.createTextNode("")),this.sheet=function(e){if(e.sheet)return e.sheet;for(var t=document.styleSheets,n=0,r=t.length;n<r;n++){var o=t[n];if(o.ownerNode===e)return o}D(17)}(t),this.length=0}var t=e.prototype;return t.insertRule=function(e,t){try{return this.sheet.insertRule(t,e),this.length++,!0}catch(e){return!1}},t.deleteRule=function(e){this.sheet.deleteRule(e),this.length--},t.getRule=function(e){var t=this.sheet.cssRules[e];return void 0!==t&&"string"==typeof t.cssText?t.cssText:""},e}(),$=function(){function e(e){var t=this.element=q(e);this.nodes=t.childNodes,this.length=0}var t=e.prototype;return t.insertRule=function(e,t){if(e<=this.length&&e>=0){var n=document.createTextNode(t),r=this.nodes[e];return this.element.insertBefore(n,r||null),this.length++,!0}return!1},t.deleteRule=function(e){this.element.removeChild(this.nodes[e]),this.length--},t.getRule=function(e){return e<this.length?this.nodes[e].textContent:""},e}(),W=function(){function e(e){this.rules=[],this.length=0}var t=e.prototype;return t.insertRule=function(e,t){return e<=this.length&&(this.rules.splice(e,0,t),this.length++,!0)},t.deleteRule=function(e){this.rules.splice(e,1),this.length--},t.getRule=function(e){return e<this.length?this.rules[e]:""},e}(),U=C,J={isServer:!C,useCSSOMInjection:!I},X=function(){function e(e,t,n){void 0===e&&(e=w),void 0===t&&(t={}),this.options=y({},J,{},e),this.gs=t,this.names=new Map(n),this.server=!!e.isServer,!this.server&&C&&U&&(U=!1,function(e){for(var t=document.querySelectorAll(M),n=0,r=t.length;n<r;n++){var o=t[n];o&&"active"!==o.getAttribute(N)&&(F(e,o),o.parentNode&&o.parentNode.removeChild(o))}}(this))}e.registerId=function(e){return V(e)};var t=e.prototype;return t.reconstructWithOptions=function(t,n){return void 0===n&&(n=!0),new e(y({},this.options,{},t),this.gs,n&&this.names||void 0)},t.allocateGSInstance=function(e){return this.gs[e]=(this.gs[e]||0)+1},t.getTag=function(){return this.tag||(this.tag=(n=(t=this.options).isServer,r=t.useCSSOMInjection,o=t.target,e=n?new W(o):r?new H(o):new $(o),new j(e)));var e,t,n,r,o},t.hasNameForId=function(e,t){return this.names.has(e)&&this.names.get(e).has(t)},t.registerName=function(e,t){if(V(e),this.names.has(e))this.names.get(e).add(t);else{var n=new Set;n.add(t),this.names.set(e,n)}},t.insertRules=function(e,t,n){this.registerName(e,t),this.getTag().insertRules(V(e),n)},t.clearNames=function(e){this.names.has(e)&&this.names.get(e).clear()},t.clearRules=function(e){this.getTag().clearGroup(V(e)),this.clearNames(e)},t.clearTag=function(){this.tag=void 0},t.toString=function(){return function(e){for(var t=e.getTag(),n=t.length,r="",o=0;o<n;o++){var s=B(o);if(void 0!==s){var i=e.names.get(s),a=t.getGroup(o);if(i&&a&&i.size){var c=N+".g"+o+'[id="'+s+'"]',u="";void 0!==i&&i.forEach((function(e){e.length>0&&(u+=e+",")})),r+=""+a+c+'{content:"'+u+'"}/*!sc*/\n'}}}return r}(this)},e}(),Z=/(a)(d)/gi,K=function(e){return String.fromCharCode(e+(e>25?39:97))};function Q(e){var t,n="";for(t=Math.abs(e);t>52;t=t/52|0)n=K(t%52)+n;return(K(t%52)+n).replace(Z,"$1-$2")}var ee=function(e,t){for(var n=t.length;n;)e=33*e^t.charCodeAt(--n);return e},te=function(e){return ee(5381,e)};function ne(e){for(var t=0;t<e.length;t+=1){var n=e[t];if(E(n)&&!_(n))return!1}return!0}var re=te("5.3.11"),oe=function(){function e(e,t,n){this.rules=e,this.staticRulesId="",this.isStatic= false&&0,this.componentId=t,this.baseHash=ee(re,t),this.baseStyle=n,X.registerId(t)}return e.prototype.generateAndInjectStyles=function(e,t,n){var r=this.componentId,o=[];if(this.baseStyle&&o.push(this.baseStyle.generateAndInjectStyles(e,t,n)),this.isStatic&&!n.hash)if(this.staticRulesId&&t.hasNameForId(r,this.staticRulesId))o.push(this.staticRulesId);else{var s=_e(this.rules,e,t,n).join(""),i=Q(ee(this.baseHash,s)>>>0);if(!t.hasNameForId(r,i)){var a=n(s,"."+i,void 0,r);t.insertRules(r,i,a)}o.push(i),this.staticRulesId=i}else{for(var c=this.rules.length,u=ee(this.baseHash,n.hash),l="",d=0;d<c;d++){var h=this.rules[d];if("string"==typeof h)l+=h, true&&(u=ee(u,h+d));else if(h){var p=_e(h,e,t,n),f=Array.isArray(p)?p.join(""):p;u=ee(u,f+d),l+=f}}if(l){var m=Q(u>>>0);if(!t.hasNameForId(r,m)){var y=n(l,"."+m,void 0,r);t.insertRules(r,m,y)}o.push(m)}}return o.join(" ")},e}(),se=/^\s*\/\/.*$/gm,ie=[":","[",".","#"];function ae(e){var t,n,r,o,s=void 0===e?w:e,i=s.options,a=void 0===i?w:i,c=s.plugins,u=void 0===c?S:c,l=new _emotion_stylis__WEBPACK_IMPORTED_MODULE_3__["default"](a),d=[],p=function(e){function t(t){if(t)try{e(t+"}")}catch(e){}}return function(n,r,o,s,i,a,c,u,l,d){switch(n){case 1:if(0===l&&64===r.charCodeAt(0))return e(r+";"),"";break;case 2:if(0===u)return r+"/*|*/";break;case 3:switch(u){case 102:case 112:return e(o[0]+r),"";default:return r+(0===d?"/*|*/":"")}case-2:r.split("/*|*/}").forEach(t)}}}((function(e){d.push(e)})),f=function(e,r,s){return 0===r&&-1!==ie.indexOf(s[n.length])||s.match(o)?e:"."+t};function m(e,s,i,a){void 0===a&&(a="&");var c=e.replace(se,""),u=s&&i?i+" "+s+" { "+c+" }":c;return t=a,n=s,r=new RegExp("\\"+n+"\\b","g"),o=new RegExp("(\\"+n+"\\b){2,}"),l(i||!s?"":s,u)}return l.use([].concat(u,[function(e,t,o){2===e&&o.length&&o[0].lastIndexOf(n)>0&&(o[0]=o[0].replace(r,f))},p,function(e){if(-2===e){var t=d;return d=[],t}}])),m.hash=u.length?u.reduce((function(e,t){return t.name||D(15),ee(e,t.name)}),5381).toString():"",m}var ce=react__WEBPACK_IMPORTED_MODULE_1___default().createContext(),ue=ce.Consumer,le=react__WEBPACK_IMPORTED_MODULE_1___default().createContext(),de=(le.Consumer,new X),he=ae();function pe(){return (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(ce)||de}function fe(){return (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(le)||he}function me(e){var t=(0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(e.stylisPlugins),n=t[0],s=t[1],c=pe(),u=(0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)((function(){var t=c;return e.sheet?t=e.sheet:e.target&&(t=t.reconstructWithOptions({target:e.target},!1)),e.disableCSSOMInjection&&(t=t.reconstructWithOptions({useCSSOMInjection:!1})),t}),[e.disableCSSOMInjection,e.sheet,e.target]),l=(0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)((function(){return ae({options:{prefix:!e.disableVendorPrefixes},plugins:n})}),[e.disableVendorPrefixes,n]);return (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)((function(){shallowequal__WEBPACK_IMPORTED_MODULE_2___default()(n,e.stylisPlugins)||s(e.stylisPlugins)}),[e.stylisPlugins]),react__WEBPACK_IMPORTED_MODULE_1___default().createElement(ce.Provider,{value:u},react__WEBPACK_IMPORTED_MODULE_1___default().createElement(le.Provider,{value:l}, true?react__WEBPACK_IMPORTED_MODULE_1___default().Children.only(e.children):0))}var ye=function(){function e(e,t){var n=this;this.inject=function(e,t){void 0===t&&(t=he);var r=n.name+t.hash;e.hasNameForId(n.id,r)||e.insertRules(n.id,r,t(n.rules,r,"@keyframes"))},this.toString=function(){return D(12,String(n.name))},this.name=e,this.id="sc-keyframes-"+e,this.rules=t}return e.prototype.getName=function(e){return void 0===e&&(e=he),this.name+e.hash},e}(),ve=/([A-Z])/,ge=/([A-Z])/g,Se=/^ms-/,we=function(e){return"-"+e.toLowerCase()};function Ee(e){return ve.test(e)?e.replace(ge,we).replace(Se,"-ms-"):e}var be=function(e){return null==e||!1===e||""===e};function _e(e,n,r,o){if(Array.isArray(e)){for(var s,i=[],a=0,c=e.length;a<c;a+=1)""!==(s=_e(e[a],n,r,o))&&(Array.isArray(s)?i.push.apply(i,s):i.push(s));return i}if(be(e))return"";if(_(e))return"."+e.styledComponentId;if(E(e)){if("function"!=typeof(l=e)||l.prototype&&l.prototype.isReactComponent||!n)return e;var u=e(n);return true&&(0,react_is__WEBPACK_IMPORTED_MODULE_0__.isElement)(u)&&console.warn(b(e)+" is not a styled component and cannot be referred to via component selector. See https://www.styled-components.com/docs/advanced#referring-to-other-components for more details."),_e(u,n,r,o)}var l;return e instanceof ye?r?(e.inject(r,o),e.getName(o)):e:g(e)?function e(t,n){var r,o,s=[];for(var i in t)t.hasOwnProperty(i)&&!be(t[i])&&(Array.isArray(t[i])&&t[i].isCss||E(t[i])?s.push(Ee(i)+":",t[i],";"):g(t[i])?s.push.apply(s,e(t[i],i)):s.push(Ee(i)+": "+(r=i,null==(o=t[i])||"boolean"==typeof o||""===o?"":"number"!=typeof o||0===o||r in _emotion_unitless__WEBPACK_IMPORTED_MODULE_4__["default"]||r.startsWith("--")?String(o).trim():o+"px")+";"));return n?[n+" {"].concat(s,["}"]):s}(e):e.toString()}var Ne=function(e){return Array.isArray(e)&&(e.isCss=!0),e};function Ae(e){for(var t=arguments.length,n=new Array(t>1?t-1:0),r=1;r<t;r++)n[r-1]=arguments[r];return E(e)||g(e)?Ne(_e(v(S,[e].concat(n)))):0===n.length&&1===e.length&&"string"==typeof e[0]?e:Ne(_e(v(e,n)))}var Ce=/invalid hook call/i,Ie=new Set,Pe=function(e,t){if(true){var n="The component "+e+(t?' with the id of "'+t+'"':"")+" has been created dynamically.\nYou may see this warning because you've called styled inside another component.\nTo resolve this only create new StyledComponents outside of any render method and function component.",r=console.error;try{var o=!0;console.error=function(e){if(Ce.test(e))o=!1,Ie.delete(n);else{for(var t=arguments.length,s=new Array(t>1?t-1:0),i=1;i<t;i++)s[i-1]=arguments[i];r.apply(void 0,[e].concat(s))}},(0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(),o&&!Ie.has(n)&&(console.warn(n),Ie.add(n))}catch(e){Ce.test(e.message)&&Ie.delete(n)}finally{console.error=r}}},Oe=function(e,t,n){return void 0===n&&(n=w),e.theme!==n.theme&&e.theme||t||n.theme},Re=/[!"#$%&'()*+,./:;<=>?@[\\\]^`{|}~-]+/g,De=/(^-|-$)/g;function je(e){return e.replace(Re,"-").replace(De,"")}var Te=function(e){return Q(te(e)>>>0)};function xe(e){return"string"==typeof e&&( false||e.charAt(0)===e.charAt(0).toLowerCase())}var ke=function(e){return"function"==typeof e||"object"==typeof e&&null!==e&&!Array.isArray(e)},Ve=function(e){return"__proto__"!==e&&"constructor"!==e&&"prototype"!==e};function Be(e,t,n){var r=e[n];ke(t)&&ke(r)?ze(r,t):e[n]=t}function ze(e){for(var t=arguments.length,n=new Array(t>1?t-1:0),r=1;r<t;r++)n[r-1]=arguments[r];for(var o=0,s=n;o<s.length;o++){var i=s[o];if(ke(i))for(var a in i)Ve(a)&&Be(e,i[a],a)}return e}var Me=react__WEBPACK_IMPORTED_MODULE_1___default().createContext(),Ge=Me.Consumer;function Le(e){var t=(0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(Me),n=(0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)((function(){return function(e,t){if(!e)return D(14);if(E(e)){var n=e(t);return false||null!==n&&!Array.isArray(n)&&"object"==typeof n?n:D(7)}return Array.isArray(e)||"object"!=typeof e?D(8):t?y({},t,{},e):e}(e.theme,t)}),[e.theme,t]);return e.children?react__WEBPACK_IMPORTED_MODULE_1___default().createElement(Me.Provider,{value:n},e.children):null}var Fe={};function Ye(e,t,n){var o=_(e),i=!xe(e),a=t.attrs,c=void 0===a?S:a,l=t.componentId,d=void 0===l?function(e,t){var n="string"!=typeof e?"sc":je(e);Fe[n]=(Fe[n]||0)+1;var r=n+"-"+Te("5.3.11"+n+Fe[n]);return t?t+"-"+r:r}(t.displayName,t.parentComponentId):l,h=t.displayName,p=void 0===h?function(e){return xe(e)?"styled."+e:"Styled("+b(e)+")"}(e):h,v=t.displayName&&t.componentId?je(t.displayName)+"-"+t.componentId:t.componentId||d,g=o&&e.attrs?Array.prototype.concat(e.attrs,c).filter(Boolean):c,N=t.shouldForwardProp;o&&e.shouldForwardProp&&(N=t.shouldForwardProp?function(n,r,o){return e.shouldForwardProp(n,r,o)&&t.shouldForwardProp(n,r,o)}:e.shouldForwardProp);var A,C=new oe(n,v,o?e.componentStyle:void 0),I=C.isStatic&&0===c.length,P=function(e,t){return function(e,t,n,r){var o=e.attrs,i=e.componentStyle,a=e.defaultProps,c=e.foldedComponentIds,l=e.shouldForwardProp,d=e.styledComponentId,h=e.target,p=function(e,t,n){void 0===e&&(e=w);var r=y({},t,{theme:e}),o={};return n.forEach((function(e){var t,n,s,i=e;for(t in E(i)&&(i=i(r)),i)r[t]=o[t]="className"===t?(n=o[t],s=i[t],n&&s?n+" "+s:n||s):i[t]})),[r,o]}(Oe(t,(0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(Me),a)||w,t,o),m=p[0],v=p[1],g=function(e,t,n,r){var o=pe(),s=fe(),i=t?e.generateAndInjectStyles(w,o,s):e.generateAndInjectStyles(n,o,s);return true&&!t&&r&&r(i),i}(i,r,m, true?e.warnTooManyClasses:0),S=n,b=v.$as||t.$as||v.as||t.as||h,_=xe(b),N=v!==t?y({},t,{},v):t,A={};for(var C in N)"$"!==C[0]&&"as"!==C&&("forwardedAs"===C?A.as=N[C]:(l?l(C,_emotion_is_prop_valid__WEBPACK_IMPORTED_MODULE_5__["default"],b):!_||(0,_emotion_is_prop_valid__WEBPACK_IMPORTED_MODULE_5__["default"])(C))&&(A[C]=N[C]));return t.style&&v.style!==t.style&&(A.style=y({},t.style,{},v.style)),A.className=Array.prototype.concat(c,d,g!==d?g:null,t.className,v.className).filter(Boolean).join(" "),A.ref=S,(0,react__WEBPACK_IMPORTED_MODULE_1__.createElement)(b,A)}(A,e,t,I)};return P.displayName=p,(A=react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(P)).attrs=g,A.componentStyle=C,A.displayName=p,A.shouldForwardProp=N,A.foldedComponentIds=o?Array.prototype.concat(e.foldedComponentIds,e.styledComponentId):S,A.styledComponentId=v,A.target=o?e.target:e,A.withComponent=function(e){var r=t.componentId,o=function(e,t){if(null==e)return{};var n,r,o={},s=Object.keys(e);for(r=0;r<s.length;r++)n=s[r],t.indexOf(n)>=0||(o[n]=e[n]);return o}(t,["componentId"]),s=r&&r+"-"+(xe(e)?e:je(b(e)));return Ye(e,y({},o,{attrs:g,componentId:s}),n)},Object.defineProperty(A,"defaultProps",{get:function(){return this._foldedDefaultProps},set:function(t){this._foldedDefaultProps=o?ze({},e.defaultProps,t):t}}), true&&(Pe(p,v),A.warnTooManyClasses=function(e,t){var n={},r=!1;return function(o){if(!r&&(n[o]=!0,Object.keys(n).length>=200)){var s=t?' with the id of "'+t+'"':"";console.warn("Over 200 classes were generated for component "+e+s+".\nConsider using the attrs method, together with a style object for frequently changed styles.\nExample:\n  const Component = styled.div.attrs(props => ({\n    style: {\n      background: props.background,\n    },\n  }))`width: 100%;`\n\n  <Component />"),r=!0,n={}}}}(p,v)),Object.defineProperty(A,"toString",{value:function(){return"."+A.styledComponentId}}),i&&hoist_non_react_statics__WEBPACK_IMPORTED_MODULE_6___default()(A,e,{attrs:!0,componentStyle:!0,displayName:!0,foldedComponentIds:!0,shouldForwardProp:!0,styledComponentId:!0,target:!0,withComponent:!0}),A}var qe=function(e){return function e(t,r,o){if(void 0===o&&(o=w),!(0,react_is__WEBPACK_IMPORTED_MODULE_0__.isValidElementType)(r))return D(1,String(r));var s=function(){return t(r,o,Ae.apply(void 0,arguments))};return s.withConfig=function(n){return e(t,r,y({},o,{},n))},s.attrs=function(n){return e(t,r,y({},o,{attrs:Array.prototype.concat(o.attrs,n).filter(Boolean)}))},s}(Ye,e)};["a","abbr","address","area","article","aside","audio","b","base","bdi","bdo","big","blockquote","body","br","button","canvas","caption","cite","code","col","colgroup","data","datalist","dd","del","details","dfn","dialog","div","dl","dt","em","embed","fieldset","figcaption","figure","footer","form","h1","h2","h3","h4","h5","h6","head","header","hgroup","hr","html","i","iframe","img","input","ins","kbd","keygen","label","legend","li","link","main","map","mark","marquee","menu","menuitem","meta","meter","nav","noscript","object","ol","optgroup","option","output","p","param","picture","pre","progress","q","rp","rt","ruby","s","samp","script","section","select","small","source","span","strong","style","sub","summary","sup","table","tbody","td","textarea","tfoot","th","thead","time","title","tr","track","u","ul","var","video","wbr","circle","clipPath","defs","ellipse","foreignObject","g","image","line","linearGradient","marker","mask","path","pattern","polygon","polyline","radialGradient","rect","stop","svg","text","textPath","tspan"].forEach((function(e){qe[e]=qe(e)}));var He=function(){function e(e,t){this.rules=e,this.componentId=t,this.isStatic=ne(e),X.registerId(this.componentId+1)}var t=e.prototype;return t.createStyles=function(e,t,n,r){var o=r(_e(this.rules,t,n,r).join(""),""),s=this.componentId+e;n.insertRules(s,s,o)},t.removeStyles=function(e,t){t.clearRules(this.componentId+e)},t.renderStyles=function(e,t,n,r){e>2&&X.registerId(this.componentId+e),this.removeStyles(e,n),this.createStyles(e,t,n,r)},e}();function $e(e){for(var t=arguments.length,n=new Array(t>1?t-1:0),o=1;o<t;o++)n[o-1]=arguments[o];var i=Ae.apply(void 0,[e].concat(n)),a="sc-global-"+Te(JSON.stringify(i)),u=new He(i,a);function d(e){var t=pe(),n=fe(),o=(0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(Me),d=(0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(t.allocateGSInstance(a)).current;return true&&react__WEBPACK_IMPORTED_MODULE_1___default().Children.count(e.children)&&console.warn("The global style component "+a+" was given child JSX. createGlobalStyle does not render children."), true&&i.some((function(e){return"string"==typeof e&&-1!==e.indexOf("@import")}))&&console.warn("Please do not use @import CSS syntax in createGlobalStyle at this time, as the CSSOM APIs we use in production do not handle it well. Instead, we recommend using a library such as react-helmet to inject a typical <link> meta tag to the stylesheet, or simply embedding it manually in your index.html <head> section for a simpler app."),t.server&&h(d,e,t,o,n),(0,react__WEBPACK_IMPORTED_MODULE_1__.useLayoutEffect)((function(){if(!t.server)return h(d,e,t,o,n),function(){return u.removeStyles(d,t)}}),[d,e,t,o,n]),null}function h(e,t,n,r,o){if(u.isStatic)u.renderStyles(e,P,n,o);else{var s=y({},t,{theme:Oe(t,r,d.defaultProps)});u.renderStyles(e,s,n,o)}}return true&&Pe(a),react__WEBPACK_IMPORTED_MODULE_1___default().memo(d)}function We(e){ true&&"undefined"!=typeof navigator&&"ReactNative"===navigator.product&&console.warn("`keyframes` cannot be used on ReactNative, only on the web. To do animation in ReactNative please use Animated.");for(var t=arguments.length,n=new Array(t>1?t-1:0),r=1;r<t;r++)n[r-1]=arguments[r];var o=Ae.apply(void 0,[e].concat(n)).join(""),s=Te(o);return new ye(s,o)}var Ue=function(){function e(){var e=this;this._emitSheetCSS=function(){var t=e.instance.toString();if(!t)return"";var n=Y();return"<style "+[n&&'nonce="'+n+'"',N+'="true"','data-styled-version="5.3.11"'].filter(Boolean).join(" ")+">"+t+"</style>"},this.getStyleTags=function(){return e.sealed?D(2):e._emitSheetCSS()},this.getStyleElement=function(){var t;if(e.sealed)return D(2);var n=((t={})[N]="",t["data-styled-version"]="5.3.11",t.dangerouslySetInnerHTML={__html:e.instance.toString()},t),o=Y();return o&&(n.nonce=o),[react__WEBPACK_IMPORTED_MODULE_1___default().createElement("style",y({},n,{key:"sc-0-0"}))]},this.seal=function(){e.sealed=!0},this.instance=new X({isServer:!0}),this.sealed=!1}var t=e.prototype;return t.collectStyles=function(e){return this.sealed?D(2):react__WEBPACK_IMPORTED_MODULE_1___default().createElement(me,{sheet:this.instance},e)},t.interleaveWithNodeStream=function(e){return D(3)},e}(),Je=function(e){var t=react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef((function(t,n){var o=(0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(Me),i=e.defaultProps,a=Oe(t,o,i);return true&&void 0===a&&console.warn('[withTheme] You are not using a ThemeProvider nor passing a theme prop or a theme in defaultProps in component class "'+b(e)+'"'),react__WEBPACK_IMPORTED_MODULE_1___default().createElement(e,y({},t,{theme:a,ref:n}))}));return hoist_non_react_statics__WEBPACK_IMPORTED_MODULE_6___default()(t,e),t.displayName="WithTheme("+b(e)+")",t},Xe=function(){return (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(Me)},Ze={StyleSheet:X,masterSheet:de}; true&&"undefined"!=typeof navigator&&"ReactNative"===navigator.product&&console.warn("It looks like you've imported 'styled-components' on React Native.\nPerhaps you're looking to import 'styled-components/native'?\nRead more about this at https://www.styled-components.com/docs/basics#react-native"), true&&"undefined"!=typeof window&&(window["__styled-components-init__"]=window["__styled-components-init__"]||0,1===window["__styled-components-init__"]&&console.warn("It looks like there are several instances of 'styled-components' initialized in this application. This may cause dynamic styles to not render properly, errors during the rehydration process, a missing theme prop, and makes your application bigger without good reason.\n\nSee https://s-c.sh/2BAXzed for more info."),window["__styled-components-init__"]+=1);/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (qe);
//# sourceMappingURL=styled-components.browser.esm.js.map


/***/ }),

/***/ "../node_modules/styled-components/node_modules/@emotion/unitless/dist/unitless.browser.esm.js":
/*!*****************************************************************************************************!*\
  !*** ../node_modules/styled-components/node_modules/@emotion/unitless/dist/unitless.browser.esm.js ***!
  \*****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
var unitlessKeys = {
  animationIterationCount: 1,
  borderImageOutset: 1,
  borderImageSlice: 1,
  borderImageWidth: 1,
  boxFlex: 1,
  boxFlexGroup: 1,
  boxOrdinalGroup: 1,
  columnCount: 1,
  columns: 1,
  flex: 1,
  flexGrow: 1,
  flexPositive: 1,
  flexShrink: 1,
  flexNegative: 1,
  flexOrder: 1,
  gridRow: 1,
  gridRowEnd: 1,
  gridRowSpan: 1,
  gridRowStart: 1,
  gridColumn: 1,
  gridColumnEnd: 1,
  gridColumnSpan: 1,
  gridColumnStart: 1,
  msGridRow: 1,
  msGridRowSpan: 1,
  msGridColumn: 1,
  msGridColumnSpan: 1,
  fontWeight: 1,
  lineHeight: 1,
  opacity: 1,
  order: 1,
  orphans: 1,
  tabSize: 1,
  widows: 1,
  zIndex: 1,
  zoom: 1,
  WebkitLineClamp: 1,
  // SVG-related properties
  fillOpacity: 1,
  floodOpacity: 1,
  stopOpacity: 1,
  strokeDasharray: 1,
  strokeDashoffset: 1,
  strokeMiterlimit: 1,
  strokeOpacity: 1,
  strokeWidth: 1
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (unitlessKeys);


/***/ }),

/***/ "../node_modules/warning/warning.js":
/*!******************************************!*\
  !*** ../node_modules/warning/warning.js ***!
  \******************************************/
/***/ ((module) => {

"use strict";
/**
 * Copyright (c) 2014-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



/**
 * Similar to invariant but only logs a warning if the condition is not met.
 * This can be used to log issues in development environments in critical
 * paths. Removing the logging code for production environments will keep the
 * same logic and follow the same code paths.
 */

var __DEV__ = "development" !== 'production';

var warning = function() {};

if (__DEV__) {
  var printWarning = function printWarning(format, args) {
    var len = arguments.length;
    args = new Array(len > 1 ? len - 1 : 0);
    for (var key = 1; key < len; key++) {
      args[key - 1] = arguments[key];
    }
    var argIndex = 0;
    var message = 'Warning: ' +
      format.replace(/%s/g, function() {
        return args[argIndex++];
      });
    if (typeof console !== 'undefined') {
      console.error(message);
    }
    try {
      // --- Welcome to debugging React ---
      // This error was thrown as a convenience so that you can use this stack
      // to find the callsite that caused this warning to fire.
      throw new Error(message);
    } catch (x) {}
  }

  warning = function(condition, format, args) {
    var len = arguments.length;
    args = new Array(len > 2 ? len - 2 : 0);
    for (var key = 2; key < len; key++) {
      args[key - 2] = arguments[key];
    }
    if (format === undefined) {
      throw new Error(
          '`warning(condition, format, ...args)` requires a warning ' +
          'message argument'
      );
    }
    if (!condition) {
      printWarning.apply(null, [format].concat(args));
    }
  };
}

module.exports = warning;


/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "React" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = React;

/***/ }),

/***/ "react-dom":
/*!***************************!*\
  !*** external "ReactDOM" ***!
  \***************************/
/***/ ((module) => {

"use strict";
module.exports = ReactDOM;

/***/ }),

/***/ "@elementor/app-ui":
/*!*********************************************!*\
  !*** external "elementorAppPackages.appUi" ***!
  \*********************************************/
/***/ ((module) => {

"use strict";
module.exports = elementorAppPackages.appUi;

/***/ }),

/***/ "@elementor/hooks":
/*!*********************************************!*\
  !*** external "elementorAppPackages.hooks" ***!
  \*********************************************/
/***/ ((module) => {

"use strict";
module.exports = elementorAppPackages.hooks;

/***/ }),

/***/ "@elementor/router":
/*!**********************************************!*\
  !*** external "elementorAppPackages.router" ***!
  \**********************************************/
/***/ ((module) => {

"use strict";
module.exports = elementorAppPackages.router;

/***/ }),

/***/ "@elementor/site-editor":
/*!**************************************************!*\
  !*** external "elementorAppPackages.siteEditor" ***!
  \**************************************************/
/***/ ((module) => {

"use strict";
module.exports = elementorAppPackages.siteEditor;

/***/ }),

/***/ "@wordpress/i18n":
/*!**************************!*\
  !*** external "wp.i18n" ***!
  \**************************/
/***/ ((module) => {

"use strict";
module.exports = wp.i18n;

/***/ }),

/***/ "../node_modules/@babel/runtime/helpers/arrayLikeToArray.js":
/*!******************************************************************!*\
  !*** ../node_modules/@babel/runtime/helpers/arrayLikeToArray.js ***!
  \******************************************************************/
/***/ ((module) => {

function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length) len = arr.length;
  for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
  return arr2;
}
module.exports = _arrayLikeToArray, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "../node_modules/@babel/runtime/helpers/arrayWithHoles.js":
/*!****************************************************************!*\
  !*** ../node_modules/@babel/runtime/helpers/arrayWithHoles.js ***!
  \****************************************************************/
/***/ ((module) => {

function _arrayWithHoles(arr) {
  if (Array.isArray(arr)) return arr;
}
module.exports = _arrayWithHoles, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "../node_modules/@babel/runtime/helpers/arrayWithoutHoles.js":
/*!*******************************************************************!*\
  !*** ../node_modules/@babel/runtime/helpers/arrayWithoutHoles.js ***!
  \*******************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var arrayLikeToArray = __webpack_require__(/*! ./arrayLikeToArray.js */ "../node_modules/@babel/runtime/helpers/arrayLikeToArray.js");
function _arrayWithoutHoles(arr) {
  if (Array.isArray(arr)) return arrayLikeToArray(arr);
}
module.exports = _arrayWithoutHoles, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "../node_modules/@babel/runtime/helpers/assertThisInitialized.js":
/*!***********************************************************************!*\
  !*** ../node_modules/@babel/runtime/helpers/assertThisInitialized.js ***!
  \***********************************************************************/
/***/ ((module) => {

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return self;
}
module.exports = _assertThisInitialized, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "../node_modules/@babel/runtime/helpers/asyncToGenerator.js":
/*!******************************************************************!*\
  !*** ../node_modules/@babel/runtime/helpers/asyncToGenerator.js ***!
  \******************************************************************/
/***/ ((module) => {

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }
  if (info.done) {
    resolve(value);
  } else {
    Promise.resolve(value).then(_next, _throw);
  }
}
function _asyncToGenerator(fn) {
  return function () {
    var self = this,
      args = arguments;
    return new Promise(function (resolve, reject) {
      var gen = fn.apply(self, args);
      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }
      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }
      _next(undefined);
    });
  };
}
module.exports = _asyncToGenerator, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "../node_modules/@babel/runtime/helpers/classCallCheck.js":
/*!****************************************************************!*\
  !*** ../node_modules/@babel/runtime/helpers/classCallCheck.js ***!
  \****************************************************************/
/***/ ((module) => {

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
module.exports = _classCallCheck, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "../node_modules/@babel/runtime/helpers/createClass.js":
/*!*************************************************************!*\
  !*** ../node_modules/@babel/runtime/helpers/createClass.js ***!
  \*************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var toPropertyKey = __webpack_require__(/*! ./toPropertyKey.js */ "../node_modules/@babel/runtime/helpers/toPropertyKey.js");
function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, toPropertyKey(descriptor.key), descriptor);
  }
}
function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  Object.defineProperty(Constructor, "prototype", {
    writable: false
  });
  return Constructor;
}
module.exports = _createClass, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "../node_modules/@babel/runtime/helpers/defineProperty.js":
/*!****************************************************************!*\
  !*** ../node_modules/@babel/runtime/helpers/defineProperty.js ***!
  \****************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var toPropertyKey = __webpack_require__(/*! ./toPropertyKey.js */ "../node_modules/@babel/runtime/helpers/toPropertyKey.js");
function _defineProperty(obj, key, value) {
  key = toPropertyKey(key);
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }
  return obj;
}
module.exports = _defineProperty, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "../node_modules/@babel/runtime/helpers/extends.js":
/*!*********************************************************!*\
  !*** ../node_modules/@babel/runtime/helpers/extends.js ***!
  \*********************************************************/
/***/ ((module) => {

function _extends() {
  module.exports = _extends = Object.assign ? Object.assign.bind() : function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  }, module.exports.__esModule = true, module.exports["default"] = module.exports;
  return _extends.apply(this, arguments);
}
module.exports = _extends, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "../node_modules/@babel/runtime/helpers/get.js":
/*!*****************************************************!*\
  !*** ../node_modules/@babel/runtime/helpers/get.js ***!
  \*****************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var superPropBase = __webpack_require__(/*! ./superPropBase.js */ "../node_modules/@babel/runtime/helpers/superPropBase.js");
function _get() {
  if (typeof Reflect !== "undefined" && Reflect.get) {
    module.exports = _get = Reflect.get.bind(), module.exports.__esModule = true, module.exports["default"] = module.exports;
  } else {
    module.exports = _get = function _get(target, property, receiver) {
      var base = superPropBase(target, property);
      if (!base) return;
      var desc = Object.getOwnPropertyDescriptor(base, property);
      if (desc.get) {
        return desc.get.call(arguments.length < 3 ? target : receiver);
      }
      return desc.value;
    }, module.exports.__esModule = true, module.exports["default"] = module.exports;
  }
  return _get.apply(this, arguments);
}
module.exports = _get, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "../node_modules/@babel/runtime/helpers/getPrototypeOf.js":
/*!****************************************************************!*\
  !*** ../node_modules/@babel/runtime/helpers/getPrototypeOf.js ***!
  \****************************************************************/
/***/ ((module) => {

function _getPrototypeOf(o) {
  module.exports = _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  }, module.exports.__esModule = true, module.exports["default"] = module.exports;
  return _getPrototypeOf(o);
}
module.exports = _getPrototypeOf, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "../node_modules/@babel/runtime/helpers/inherits.js":
/*!**********************************************************!*\
  !*** ../node_modules/@babel/runtime/helpers/inherits.js ***!
  \**********************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var setPrototypeOf = __webpack_require__(/*! ./setPrototypeOf.js */ "../node_modules/@babel/runtime/helpers/setPrototypeOf.js");
function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  Object.defineProperty(subClass, "prototype", {
    writable: false
  });
  if (superClass) setPrototypeOf(subClass, superClass);
}
module.exports = _inherits, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js":
/*!***********************************************************************!*\
  !*** ../node_modules/@babel/runtime/helpers/interopRequireDefault.js ***!
  \***********************************************************************/
/***/ ((module) => {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}
module.exports = _interopRequireDefault, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "../node_modules/@babel/runtime/helpers/iterableToArray.js":
/*!*****************************************************************!*\
  !*** ../node_modules/@babel/runtime/helpers/iterableToArray.js ***!
  \*****************************************************************/
/***/ ((module) => {

function _iterableToArray(iter) {
  if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
module.exports = _iterableToArray, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "../node_modules/@babel/runtime/helpers/iterableToArrayLimit.js":
/*!**********************************************************************!*\
  !*** ../node_modules/@babel/runtime/helpers/iterableToArrayLimit.js ***!
  \**********************************************************************/
/***/ ((module) => {

function _iterableToArrayLimit(arr, i) {
  var _i = null == arr ? null : "undefined" != typeof Symbol && arr[Symbol.iterator] || arr["@@iterator"];
  if (null != _i) {
    var _s,
      _e,
      _x,
      _r,
      _arr = [],
      _n = !0,
      _d = !1;
    try {
      if (_x = (_i = _i.call(arr)).next, 0 === i) {
        if (Object(_i) !== _i) return;
        _n = !1;
      } else for (; !(_n = (_s = _x.call(_i)).done) && (_arr.push(_s.value), _arr.length !== i); _n = !0);
    } catch (err) {
      _d = !0, _e = err;
    } finally {
      try {
        if (!_n && null != _i["return"] && (_r = _i["return"](), Object(_r) !== _r)) return;
      } finally {
        if (_d) throw _e;
      }
    }
    return _arr;
  }
}
module.exports = _iterableToArrayLimit, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "../node_modules/@babel/runtime/helpers/nonIterableRest.js":
/*!*****************************************************************!*\
  !*** ../node_modules/@babel/runtime/helpers/nonIterableRest.js ***!
  \*****************************************************************/
/***/ ((module) => {

function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
module.exports = _nonIterableRest, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "../node_modules/@babel/runtime/helpers/nonIterableSpread.js":
/*!*******************************************************************!*\
  !*** ../node_modules/@babel/runtime/helpers/nonIterableSpread.js ***!
  \*******************************************************************/
/***/ ((module) => {

function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
module.exports = _nonIterableSpread, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "../node_modules/@babel/runtime/helpers/possibleConstructorReturn.js":
/*!***************************************************************************!*\
  !*** ../node_modules/@babel/runtime/helpers/possibleConstructorReturn.js ***!
  \***************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var _typeof = (__webpack_require__(/*! ./typeof.js */ "../node_modules/@babel/runtime/helpers/typeof.js")["default"]);
var assertThisInitialized = __webpack_require__(/*! ./assertThisInitialized.js */ "../node_modules/@babel/runtime/helpers/assertThisInitialized.js");
function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  } else if (call !== void 0) {
    throw new TypeError("Derived constructors may only return object or undefined");
  }
  return assertThisInitialized(self);
}
module.exports = _possibleConstructorReturn, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "../node_modules/@babel/runtime/helpers/regeneratorRuntime.js":
/*!********************************************************************!*\
  !*** ../node_modules/@babel/runtime/helpers/regeneratorRuntime.js ***!
  \********************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var _typeof = (__webpack_require__(/*! ./typeof.js */ "../node_modules/@babel/runtime/helpers/typeof.js")["default"]);
function _regeneratorRuntime() {
  "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */
  module.exports = _regeneratorRuntime = function _regeneratorRuntime() {
    return exports;
  }, module.exports.__esModule = true, module.exports["default"] = module.exports;
  var exports = {},
    Op = Object.prototype,
    hasOwn = Op.hasOwnProperty,
    defineProperty = Object.defineProperty || function (obj, key, desc) {
      obj[key] = desc.value;
    },
    $Symbol = "function" == typeof Symbol ? Symbol : {},
    iteratorSymbol = $Symbol.iterator || "@@iterator",
    asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator",
    toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";
  function define(obj, key, value) {
    return Object.defineProperty(obj, key, {
      value: value,
      enumerable: !0,
      configurable: !0,
      writable: !0
    }), obj[key];
  }
  try {
    define({}, "");
  } catch (err) {
    define = function define(obj, key, value) {
      return obj[key] = value;
    };
  }
  function wrap(innerFn, outerFn, self, tryLocsList) {
    var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator,
      generator = Object.create(protoGenerator.prototype),
      context = new Context(tryLocsList || []);
    return defineProperty(generator, "_invoke", {
      value: makeInvokeMethod(innerFn, self, context)
    }), generator;
  }
  function tryCatch(fn, obj, arg) {
    try {
      return {
        type: "normal",
        arg: fn.call(obj, arg)
      };
    } catch (err) {
      return {
        type: "throw",
        arg: err
      };
    }
  }
  exports.wrap = wrap;
  var ContinueSentinel = {};
  function Generator() {}
  function GeneratorFunction() {}
  function GeneratorFunctionPrototype() {}
  var IteratorPrototype = {};
  define(IteratorPrototype, iteratorSymbol, function () {
    return this;
  });
  var getProto = Object.getPrototypeOf,
    NativeIteratorPrototype = getProto && getProto(getProto(values([])));
  NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype);
  var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype);
  function defineIteratorMethods(prototype) {
    ["next", "throw", "return"].forEach(function (method) {
      define(prototype, method, function (arg) {
        return this._invoke(method, arg);
      });
    });
  }
  function AsyncIterator(generator, PromiseImpl) {
    function invoke(method, arg, resolve, reject) {
      var record = tryCatch(generator[method], generator, arg);
      if ("throw" !== record.type) {
        var result = record.arg,
          value = result.value;
        return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) {
          invoke("next", value, resolve, reject);
        }, function (err) {
          invoke("throw", err, resolve, reject);
        }) : PromiseImpl.resolve(value).then(function (unwrapped) {
          result.value = unwrapped, resolve(result);
        }, function (error) {
          return invoke("throw", error, resolve, reject);
        });
      }
      reject(record.arg);
    }
    var previousPromise;
    defineProperty(this, "_invoke", {
      value: function value(method, arg) {
        function callInvokeWithMethodAndArg() {
          return new PromiseImpl(function (resolve, reject) {
            invoke(method, arg, resolve, reject);
          });
        }
        return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg();
      }
    });
  }
  function makeInvokeMethod(innerFn, self, context) {
    var state = "suspendedStart";
    return function (method, arg) {
      if ("executing" === state) throw new Error("Generator is already running");
      if ("completed" === state) {
        if ("throw" === method) throw arg;
        return doneResult();
      }
      for (context.method = method, context.arg = arg;;) {
        var delegate = context.delegate;
        if (delegate) {
          var delegateResult = maybeInvokeDelegate(delegate, context);
          if (delegateResult) {
            if (delegateResult === ContinueSentinel) continue;
            return delegateResult;
          }
        }
        if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) {
          if ("suspendedStart" === state) throw state = "completed", context.arg;
          context.dispatchException(context.arg);
        } else "return" === context.method && context.abrupt("return", context.arg);
        state = "executing";
        var record = tryCatch(innerFn, self, context);
        if ("normal" === record.type) {
          if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue;
          return {
            value: record.arg,
            done: context.done
          };
        }
        "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg);
      }
    };
  }
  function maybeInvokeDelegate(delegate, context) {
    var methodName = context.method,
      method = delegate.iterator[methodName];
    if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel;
    var record = tryCatch(method, delegate.iterator, context.arg);
    if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel;
    var info = record.arg;
    return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel);
  }
  function pushTryEntry(locs) {
    var entry = {
      tryLoc: locs[0]
    };
    1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry);
  }
  function resetTryEntry(entry) {
    var record = entry.completion || {};
    record.type = "normal", delete record.arg, entry.completion = record;
  }
  function Context(tryLocsList) {
    this.tryEntries = [{
      tryLoc: "root"
    }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0);
  }
  function values(iterable) {
    if (iterable) {
      var iteratorMethod = iterable[iteratorSymbol];
      if (iteratorMethod) return iteratorMethod.call(iterable);
      if ("function" == typeof iterable.next) return iterable;
      if (!isNaN(iterable.length)) {
        var i = -1,
          next = function next() {
            for (; ++i < iterable.length;) if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next;
            return next.value = undefined, next.done = !0, next;
          };
        return next.next = next;
      }
    }
    return {
      next: doneResult
    };
  }
  function doneResult() {
    return {
      value: undefined,
      done: !0
    };
  }
  return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", {
    value: GeneratorFunctionPrototype,
    configurable: !0
  }), defineProperty(GeneratorFunctionPrototype, "constructor", {
    value: GeneratorFunction,
    configurable: !0
  }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) {
    var ctor = "function" == typeof genFun && genFun.constructor;
    return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name));
  }, exports.mark = function (genFun) {
    return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun;
  }, exports.awrap = function (arg) {
    return {
      __await: arg
    };
  }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () {
    return this;
  }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) {
    void 0 === PromiseImpl && (PromiseImpl = Promise);
    var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl);
    return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) {
      return result.done ? result.value : iter.next();
    });
  }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () {
    return this;
  }), define(Gp, "toString", function () {
    return "[object Generator]";
  }), exports.keys = function (val) {
    var object = Object(val),
      keys = [];
    for (var key in object) keys.push(key);
    return keys.reverse(), function next() {
      for (; keys.length;) {
        var key = keys.pop();
        if (key in object) return next.value = key, next.done = !1, next;
      }
      return next.done = !0, next;
    };
  }, exports.values = values, Context.prototype = {
    constructor: Context,
    reset: function reset(skipTempReset) {
      if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined);
    },
    stop: function stop() {
      this.done = !0;
      var rootRecord = this.tryEntries[0].completion;
      if ("throw" === rootRecord.type) throw rootRecord.arg;
      return this.rval;
    },
    dispatchException: function dispatchException(exception) {
      if (this.done) throw exception;
      var context = this;
      function handle(loc, caught) {
        return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught;
      }
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i],
          record = entry.completion;
        if ("root" === entry.tryLoc) return handle("end");
        if (entry.tryLoc <= this.prev) {
          var hasCatch = hasOwn.call(entry, "catchLoc"),
            hasFinally = hasOwn.call(entry, "finallyLoc");
          if (hasCatch && hasFinally) {
            if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
            if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
          } else if (hasCatch) {
            if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
          } else {
            if (!hasFinally) throw new Error("try statement without catch or finally");
            if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
          }
        }
      }
    },
    abrupt: function abrupt(type, arg) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) {
          var finallyEntry = entry;
          break;
        }
      }
      finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null);
      var record = finallyEntry ? finallyEntry.completion : {};
      return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record);
    },
    complete: function complete(record, afterLoc) {
      if ("throw" === record.type) throw record.arg;
      return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel;
    },
    finish: function finish(finallyLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel;
      }
    },
    "catch": function _catch(tryLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc === tryLoc) {
          var record = entry.completion;
          if ("throw" === record.type) {
            var thrown = record.arg;
            resetTryEntry(entry);
          }
          return thrown;
        }
      }
      throw new Error("illegal catch attempt");
    },
    delegateYield: function delegateYield(iterable, resultName, nextLoc) {
      return this.delegate = {
        iterator: values(iterable),
        resultName: resultName,
        nextLoc: nextLoc
      }, "next" === this.method && (this.arg = undefined), ContinueSentinel;
    }
  }, exports;
}
module.exports = _regeneratorRuntime, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "../node_modules/@babel/runtime/helpers/setPrototypeOf.js":
/*!****************************************************************!*\
  !*** ../node_modules/@babel/runtime/helpers/setPrototypeOf.js ***!
  \****************************************************************/
/***/ ((module) => {

function _setPrototypeOf(o, p) {
  module.exports = _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  }, module.exports.__esModule = true, module.exports["default"] = module.exports;
  return _setPrototypeOf(o, p);
}
module.exports = _setPrototypeOf, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "../node_modules/@babel/runtime/helpers/slicedToArray.js":
/*!***************************************************************!*\
  !*** ../node_modules/@babel/runtime/helpers/slicedToArray.js ***!
  \***************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var arrayWithHoles = __webpack_require__(/*! ./arrayWithHoles.js */ "../node_modules/@babel/runtime/helpers/arrayWithHoles.js");
var iterableToArrayLimit = __webpack_require__(/*! ./iterableToArrayLimit.js */ "../node_modules/@babel/runtime/helpers/iterableToArrayLimit.js");
var unsupportedIterableToArray = __webpack_require__(/*! ./unsupportedIterableToArray.js */ "../node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js");
var nonIterableRest = __webpack_require__(/*! ./nonIterableRest.js */ "../node_modules/@babel/runtime/helpers/nonIterableRest.js");
function _slicedToArray(arr, i) {
  return arrayWithHoles(arr) || iterableToArrayLimit(arr, i) || unsupportedIterableToArray(arr, i) || nonIterableRest();
}
module.exports = _slicedToArray, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "../node_modules/@babel/runtime/helpers/superPropBase.js":
/*!***************************************************************!*\
  !*** ../node_modules/@babel/runtime/helpers/superPropBase.js ***!
  \***************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var getPrototypeOf = __webpack_require__(/*! ./getPrototypeOf.js */ "../node_modules/@babel/runtime/helpers/getPrototypeOf.js");
function _superPropBase(object, property) {
  while (!Object.prototype.hasOwnProperty.call(object, property)) {
    object = getPrototypeOf(object);
    if (object === null) break;
  }
  return object;
}
module.exports = _superPropBase, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "../node_modules/@babel/runtime/helpers/toConsumableArray.js":
/*!*******************************************************************!*\
  !*** ../node_modules/@babel/runtime/helpers/toConsumableArray.js ***!
  \*******************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var arrayWithoutHoles = __webpack_require__(/*! ./arrayWithoutHoles.js */ "../node_modules/@babel/runtime/helpers/arrayWithoutHoles.js");
var iterableToArray = __webpack_require__(/*! ./iterableToArray.js */ "../node_modules/@babel/runtime/helpers/iterableToArray.js");
var unsupportedIterableToArray = __webpack_require__(/*! ./unsupportedIterableToArray.js */ "../node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js");
var nonIterableSpread = __webpack_require__(/*! ./nonIterableSpread.js */ "../node_modules/@babel/runtime/helpers/nonIterableSpread.js");
function _toConsumableArray(arr) {
  return arrayWithoutHoles(arr) || iterableToArray(arr) || unsupportedIterableToArray(arr) || nonIterableSpread();
}
module.exports = _toConsumableArray, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "../node_modules/@babel/runtime/helpers/toPrimitive.js":
/*!*************************************************************!*\
  !*** ../node_modules/@babel/runtime/helpers/toPrimitive.js ***!
  \*************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var _typeof = (__webpack_require__(/*! ./typeof.js */ "../node_modules/@babel/runtime/helpers/typeof.js")["default"]);
function _toPrimitive(input, hint) {
  if (_typeof(input) !== "object" || input === null) return input;
  var prim = input[Symbol.toPrimitive];
  if (prim !== undefined) {
    var res = prim.call(input, hint || "default");
    if (_typeof(res) !== "object") return res;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (hint === "string" ? String : Number)(input);
}
module.exports = _toPrimitive, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "../node_modules/@babel/runtime/helpers/toPropertyKey.js":
/*!***************************************************************!*\
  !*** ../node_modules/@babel/runtime/helpers/toPropertyKey.js ***!
  \***************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var _typeof = (__webpack_require__(/*! ./typeof.js */ "../node_modules/@babel/runtime/helpers/typeof.js")["default"]);
var toPrimitive = __webpack_require__(/*! ./toPrimitive.js */ "../node_modules/@babel/runtime/helpers/toPrimitive.js");
function _toPropertyKey(arg) {
  var key = toPrimitive(arg, "string");
  return _typeof(key) === "symbol" ? key : String(key);
}
module.exports = _toPropertyKey, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "../node_modules/@babel/runtime/helpers/typeof.js":
/*!********************************************************!*\
  !*** ../node_modules/@babel/runtime/helpers/typeof.js ***!
  \********************************************************/
/***/ ((module) => {

function _typeof(obj) {
  "@babel/helpers - typeof";

  return (module.exports = _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) {
    return typeof obj;
  } : function (obj) {
    return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
  }, module.exports.__esModule = true, module.exports["default"] = module.exports), _typeof(obj);
}
module.exports = _typeof, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "../node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js":
/*!****************************************************************************!*\
  !*** ../node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js ***!
  \****************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var arrayLikeToArray = __webpack_require__(/*! ./arrayLikeToArray.js */ "../node_modules/@babel/runtime/helpers/arrayLikeToArray.js");
function _unsupportedIterableToArray(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return arrayLikeToArray(o, minLen);
}
module.exports = _unsupportedIterableToArray, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "../node_modules/@babel/runtime/regenerator/index.js":
/*!***********************************************************!*\
  !*** ../node_modules/@babel/runtime/regenerator/index.js ***!
  \***********************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// TODO(Babel 8): Remove this file.

var runtime = __webpack_require__(/*! ../helpers/regeneratorRuntime */ "../node_modules/@babel/runtime/helpers/regeneratorRuntime.js")();
module.exports = runtime;

// Copied from https://github.com/facebook/regenerator/blob/main/packages/runtime/runtime.js#L736=
try {
  regeneratorRuntime = runtime;
} catch (accidentalStrictMode) {
  if (typeof globalThis === "object") {
    globalThis.regeneratorRuntime = runtime;
  } else {
    Function("r", "regeneratorRuntime = r")(runtime);
  }
}


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/ensure chunk */
/******/ 	(() => {
/******/ 		__webpack_require__.f = {};
/******/ 		// This file contains only the entry chunk.
/******/ 		// The chunk loading function for additional chunks
/******/ 		__webpack_require__.e = (chunkId) => {
/******/ 			return Promise.all(Object.keys(__webpack_require__.f).reduce((promises, key) => {
/******/ 				__webpack_require__.f[key](chunkId, promises);
/******/ 				return promises;
/******/ 			}, []));
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/get javascript chunk filename */
/******/ 	(() => {
/******/ 		// This function allow to reference async chunks
/******/ 		__webpack_require__.u = (chunkId) => {
/******/ 			// return url for filenames not based on template
/******/ 			if (chunkId === "vendors-node_modules_react-query_devtools_index_js") return "a730ee9caa710006b307.bundle.js";
/******/ 			if (chunkId === "kit-library") return "" + chunkId + ".b4cf9f541e44f7bbc972.bundle.js";
/******/ 			if (chunkId === "onboarding") return "" + chunkId + ".d1f3b86a6e269191f707.bundle.js";
/******/ 			// return url for filenames based on template
/******/ 			return undefined;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/load script */
/******/ 	(() => {
/******/ 		var inProgress = {};
/******/ 		var dataWebpackPrefix = "elementor:";
/******/ 		// loadScript function to load a script via script tag
/******/ 		__webpack_require__.l = (url, done, key, chunkId) => {
/******/ 			if(inProgress[url]) { inProgress[url].push(done); return; }
/******/ 			var script, needAttach;
/******/ 			if(key !== undefined) {
/******/ 				var scripts = document.getElementsByTagName("script");
/******/ 				for(var i = 0; i < scripts.length; i++) {
/******/ 					var s = scripts[i];
/******/ 					if(s.getAttribute("src") == url || s.getAttribute("data-webpack") == dataWebpackPrefix + key) { script = s; break; }
/******/ 				}
/******/ 			}
/******/ 			if(!script) {
/******/ 				needAttach = true;
/******/ 				script = document.createElement('script');
/******/ 		
/******/ 				script.charset = 'utf-8';
/******/ 				script.timeout = 120;
/******/ 				if (__webpack_require__.nc) {
/******/ 					script.setAttribute("nonce", __webpack_require__.nc);
/******/ 				}
/******/ 				script.setAttribute("data-webpack", dataWebpackPrefix + key);
/******/ 		
/******/ 				script.src = url;
/******/ 			}
/******/ 			inProgress[url] = [done];
/******/ 			var onScriptComplete = (prev, event) => {
/******/ 				// avoid mem leaks in IE.
/******/ 				script.onerror = script.onload = null;
/******/ 				clearTimeout(timeout);
/******/ 				var doneFns = inProgress[url];
/******/ 				delete inProgress[url];
/******/ 				script.parentNode && script.parentNode.removeChild(script);
/******/ 				doneFns && doneFns.forEach((fn) => (fn(event)));
/******/ 				if(prev) return prev(event);
/******/ 			}
/******/ 			var timeout = setTimeout(onScriptComplete.bind(null, undefined, { type: 'timeout', target: script }), 120000);
/******/ 			script.onerror = onScriptComplete.bind(null, script.onerror);
/******/ 			script.onload = onScriptComplete.bind(null, script.onload);
/******/ 			needAttach && document.head.appendChild(script);
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/publicPath */
/******/ 	(() => {
/******/ 		var scriptUrl;
/******/ 		if (__webpack_require__.g.importScripts) scriptUrl = __webpack_require__.g.location + "";
/******/ 		var document = __webpack_require__.g.document;
/******/ 		if (!scriptUrl && document) {
/******/ 			if (document.currentScript)
/******/ 				scriptUrl = document.currentScript.src;
/******/ 			if (!scriptUrl) {
/******/ 				var scripts = document.getElementsByTagName("script");
/******/ 				if(scripts.length) {
/******/ 					var i = scripts.length - 1;
/******/ 					while (i > -1 && !scriptUrl) scriptUrl = scripts[i--].src;
/******/ 				}
/******/ 			}
/******/ 		}
/******/ 		// When supporting browsers where an automatic publicPath is not supported you must specify an output.publicPath manually via configuration
/******/ 		// or pass an empty string ("") and set the __webpack_public_path__ variable from your code to use your own logic.
/******/ 		if (!scriptUrl) throw new Error("Automatic publicPath is not supported in this browser");
/******/ 		scriptUrl = scriptUrl.replace(/#.*$/, "").replace(/\?.*$/, "").replace(/\/[^\/]+$/, "/");
/******/ 		__webpack_require__.p = scriptUrl;
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			"app": 0
/******/ 		};
/******/ 		
/******/ 		__webpack_require__.f.j = (chunkId, promises) => {
/******/ 				// JSONP chunk loading for javascript
/******/ 				var installedChunkData = __webpack_require__.o(installedChunks, chunkId) ? installedChunks[chunkId] : undefined;
/******/ 				if(installedChunkData !== 0) { // 0 means "already installed".
/******/ 		
/******/ 					// a Promise means "currently loading".
/******/ 					if(installedChunkData) {
/******/ 						promises.push(installedChunkData[2]);
/******/ 					} else {
/******/ 						if(true) { // all chunks have JS
/******/ 							// setup Promise in chunk cache
/******/ 							var promise = new Promise((resolve, reject) => (installedChunkData = installedChunks[chunkId] = [resolve, reject]));
/******/ 							promises.push(installedChunkData[2] = promise);
/******/ 		
/******/ 							// start chunk loading
/******/ 							var url = __webpack_require__.p + __webpack_require__.u(chunkId);
/******/ 							// create error before stack unwound to get useful stacktrace later
/******/ 							var error = new Error();
/******/ 							var loadingEnded = (event) => {
/******/ 								if(__webpack_require__.o(installedChunks, chunkId)) {
/******/ 									installedChunkData = installedChunks[chunkId];
/******/ 									if(installedChunkData !== 0) installedChunks[chunkId] = undefined;
/******/ 									if(installedChunkData) {
/******/ 										var errorType = event && (event.type === 'load' ? 'missing' : event.type);
/******/ 										var realSrc = event && event.target && event.target.src;
/******/ 										error.message = 'Loading chunk ' + chunkId + ' failed.\n(' + errorType + ': ' + realSrc + ')';
/******/ 										error.name = 'ChunkLoadError';
/******/ 										error.type = errorType;
/******/ 										error.request = realSrc;
/******/ 										installedChunkData[1](error);
/******/ 									}
/******/ 								}
/******/ 							};
/******/ 							__webpack_require__.l(url, loadingEnded, "chunk-" + chunkId, chunkId);
/******/ 						}
/******/ 					}
/******/ 				}
/******/ 		};
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		// no on chunks loaded
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some((id) => (installedChunks[id] !== 0))) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkId] = 0;
/******/ 			}
/******/ 		
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunkelementor"] = self["webpackChunkelementor"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/nonce */
/******/ 	(() => {
/******/ 		__webpack_require__.nc = undefined;
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";
/*!*********************************!*\
  !*** ../app/assets/js/index.js ***!
  \*********************************/
/* provided dependency */ var ReactDOM = __webpack_require__(/*! react-dom */ "react-dom");


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/@babel/runtime/helpers/interopRequireDefault.js");
var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));
var _app = _interopRequireDefault(__webpack_require__(/*! ./app */ "../app/assets/js/app.js"));
var _module = _interopRequireDefault(__webpack_require__(/*! ../../modules/import-export/assets/js/module */ "../app/modules/import-export/assets/js/module.js"));
var _module2 = _interopRequireDefault(__webpack_require__(/*! ../../modules/kit-library/assets/js/module */ "../app/modules/kit-library/assets/js/module.js"));
var _module3 = _interopRequireDefault(__webpack_require__(/*! ../../modules/onboarding/assets/js/module */ "../app/modules/onboarding/assets/js/module.js"));
var _siteEditor = __webpack_require__(/*! @elementor/site-editor */ "@elementor/site-editor");
var _appContext = _interopRequireDefault(__webpack_require__(/*! ./app-context */ "../app/assets/js/app-context.js"));
new _module.default();
new _module2.default();
new _siteEditor.Module();
new _module3.default();
var AppWrapper = _react.default.Fragment;
ReactDOM.render( /*#__PURE__*/_react.default.createElement(AppWrapper, null, /*#__PURE__*/_react.default.createElement(_appContext.default, null, /*#__PURE__*/_react.default.createElement(_app.default, null))), document.getElementById('e-app'));
})();

/******/ })()
;
//# sourceMappingURL=app.js.map